package com.example.lokerku

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator
import com.example.lokerku.AppFont.regular
import com.example.lokerku.AppFont.semibold
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Scattered letters assemble in deliberate steps; no flashing effects.  */
class LokerKuSplashView(c: Context) : View(c) {
    fun interface AnimationListener {
        fun onAnimationFinished()
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG)
    private val regular = regular(c)
    private val semibold = semibold(c)
    private var animator: ValueAnimator? = null
    private var listener: AnimationListener? = null
    private var background: Shader? = null
    private var progress = 0f
    private var started = false
    private var finished = false
    private val xs = floatArrayOf(.13f, .75f, .29f, .85f, .14f, .72f, .50f)
    private val ys = floatArrayOf(.22f, .17f, .62f, .59f, .45f, .73f, .10f)

    init {
        contentDescription = "LokerKu, temukan peluang kariermu"
    }

    fun setAnimationListener(l: AnimationListener?) {
        listener = l
    }

    private fun dp(n: Float): Float {
        return n * resources.displayMetrics.density
    }

    private fun sp(n: Float): Float {
        return n * resources.displayMetrics.scaledDensity
    }

    private fun ramp(start: Float, duration: Float): Float {
        return max(
            0.0,
            min(1.0, ((progress - start) / duration).toDouble())
        ).toFloat()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (w <= 0 || h <= 0) return
        background = LinearGradient(
            0f,
            0f,
            w.toFloat(),
            h.toFloat(),
            intArrayOf(-0xf7e7bc, -0xe8d07e, -0xccc35f),
            null,
            Shader.TileMode.CLAMP
        )
        if (started) return
        started = true
        animator = ValueAnimator.ofFloat(0f, 1f)
        animator!!.setDuration(7200)
        animator!!.setInterpolator(LinearInterpolator())
        animator!!.addUpdateListener(ValueAnimator.AnimatorUpdateListener { a: ValueAnimator ->
            progress = a.animatedValue as Float
            invalidate()
        })
        animator!!.addListener(object : AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(a: Animator) {
                cancelled = true
            }

            override fun onAnimationEnd(a: Animator) {
                if (!cancelled && !finished) {
                    finished = true
                    if (listener != null) listener!!.onAnimationFinished()
                }
            }
        })
        animator!!.start()
    }

    private fun glow(c: Canvas, x: Float, y: Float, r: Float, color: Int) {
        paint.setShader(
            RadialGradient(
                x,
                y,
                r,
                intArrayOf(color, 0x00000000),
                null,
                Shader.TileMode.CLAMP
            )
        )
        paint.style = Paint.Style.FILL
        c.drawCircle(x, y, r, paint)
        paint.setShader(null)
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0 || h <= 0) return
        val cx = w / 2
        val cy = h * .46f
        paint.setShader(background)
        paint.style = Paint.Style.FILL
        c.drawPaint(paint)
        paint.setShader(null)
        glow(
            c,
            w * .8f + dp(15f) * sin((progress * 6.28f).toDouble()).toFloat(),
            h * .22f,
            w * .68f,
            -0x748a5501
        )
        glow(c, w * .17f, h * .72f, w * .58f, 0x75499fff)
        glow(c, cx, cy, w * .48f, 0x4c9cc9ff)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = dp(1f)
        for (i in 0..4) {
            paint.color = Color.argb(35 + i * 6, 196, 218, 255)
            val path = Path()
            val wave = dp(8f) * sin((progress * 6.28f + i).toDouble()).toFloat()
            path.moveTo(-w * .2f, h * (.22f + .11f * i) + wave)
            path.cubicTo(
                w * .25f,
                h * (.10f + .10f * i),
                w * .7f,
                h * (.37f + .08f * i),
                w * 1.2f,
                h * (.2f + .10f * i) - wave
            )
            c.drawPath(path, paint)
        }
        paint.style = Paint.Style.FILL
        for (i in 0..27) {
            val x = w * (.04f + .91f * ((i * 37 % 101) / 100f))
            val y =
                h * (.07f + .82f * ((i * 61 % 103) / 102f)) + dp(6f) * sin((progress * 6.28f + i).toDouble()).toFloat()
            paint.color = Color.argb(75 + (i % 4) * 22, 218, 234, 255)
            c.drawCircle(x, y, dp((if (i % 7 == 0) 2 else 1).toFloat()), paint)
        }
        val word = "LokerKu"
        text.setTypeface(semibold)
        text.textSize = min(sp(41f).toDouble(), (w * .105f).toDouble()).toFloat()
        text.textAlign = Paint.Align.LEFT
        val width = text.measureText(word)
        var target = cx - width / 2
        val baseline = cy - (text.ascent() + text.descent()) / 2
        for (i in 0 until word.length) {
            val letter = word.substring(i, i + 1)
            val size = text.measureText(letter)
            val tx = target + size / 2
            val t = ramp(.16f + i * .025f, .62f)
            val stepped = if (t >= 1f) 1f else floor((t * 6).toDouble()).toFloat() / 6f
            val x = xs[i] * w + (tx - xs[i] * w) * stepped
            val y = ys[i] * h + (baseline - ys[i] * h) * stepped
            c.save()
            c.translate(x, y)
            c.rotate((if (i % 2 == 0) -20 else 20) * (1 - stepped))
            text.color =
                Color.argb(
                    (255 * ramp(.01f + i * .012f, .10f)).toInt(),
                    245,
                    249,
                    255
                )
            c.drawText(letter, -size / 2, 0f, text)
            c.restore()
            target += size
        }
        val sub = ramp(.82f, .12f)
        text.textAlign = Paint.Align.CENTER
        text.setTypeface(regular)
        text.textSize = min(sp(13f).toDouble(), (w * .034f).toDouble()).toFloat()
        text.color = Color.argb((235 * sub).toInt(), 220, 235, 255)
        c.drawText("Temukan peluang kariermu", cx, cy + dp(48f), text)
        val lineY = h * .84f
        val lineW = min(dp(130f).toDouble(), (w * .32f).toDouble()).toFloat()
        paint.color = 0x50d9eaff
        c.drawRoundRect(
            cx - lineW / 2,
            lineY,
            cx + lineW / 2,
            lineY + dp(3f),
            dp(2f),
            dp(2f),
            paint
        )
        val fill = min(1.0, (progress / .94f).toDouble()).toFloat()
        paint.color = -0x190c01
        if (fill > 0f) c.drawRoundRect(
            cx - lineW / 2,
            lineY,
            cx - lineW / 2 + lineW * fill,
            lineY + dp(3f),
            dp(2f),
            dp(2f),
            paint
        )
        text.setTypeface(semibold)
        text.textSize = min(sp(9f).toDouble(), (w * .025f).toDouble()).toFloat()
        text.color = -0x42231601
        c.drawText("MEMULAI LOKERKU", cx, h * .90f, text)
    }

    fun pauseAnimations() {
        if (animator != null && animator!!.isRunning) animator!!.pause()
    }

    fun resumeAnimations() {
        if (animator != null && animator!!.isPaused) animator!!.resume()
    }

    fun stopAnimations() {
        if (animator != null) {
            animator!!.cancel()
            animator = null
        }
    }
}
