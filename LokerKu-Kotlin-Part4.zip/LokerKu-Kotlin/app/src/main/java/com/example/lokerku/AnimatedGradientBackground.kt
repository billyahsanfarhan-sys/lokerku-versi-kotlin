package com.example.lokerku

import android.animation.ValueAnimator
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.min

object AnimatedGradientBackground {
    fun apply(view: View) {
        val palettes = arrayOf(
            intArrayOf(
                Color.rgb(13, 24, 55),
                Color.rgb(36, 76, 170),
                Color.rgb(23, 145, 160)
            ),
            intArrayOf(
                Color.rgb(35, 24, 85),
                Color.rgb(77, 64, 190),
                Color.rgb(28, 128, 155)
            ),
            intArrayOf(
                Color.rgb(10, 47, 75),
                Color.rgb(20, 111, 155),
                Color.rgb(48, 76, 170)
            )
        )

        val gradient = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            palettes[0]
        )

        view.background = gradient

        val animator = ValueAnimator.ofFloat(0f, 3f)
        animator.setDuration(18000)
        animator.repeatCount = ValueAnimator.INFINITE
        animator.interpolator = LinearInterpolator()

        animator.addUpdateListener { animation: ValueAnimator ->
            val position = animation.animatedValue as Float
            val current =
                min(position.toInt().toDouble(), (palettes.size - 1).toDouble()).toInt()
            val next = (current + 1) % palettes.size
            val fraction = position - current

            val colors = IntArray(3)

            for (i in colors.indices) {
                colors[i] = blend(
                    palettes[current][i],
                    palettes[next][i],
                    fraction
                )
            }
            gradient.colors = colors
        }

        animator.start()

        view.setTag(R.id.animated_gradient_animator, animator)
    }

    private fun blend(from: Int, to: Int, fraction: Float): Int {
        return Color.rgb(
            (Color.red(from) +
                    (Color.red(to) - Color.red(from)) * fraction).toInt(),
            (Color.green(from) +
                    (Color.green(to) - Color.green(from)) * fraction).toInt(),
            (Color.blue(from) +
                    (Color.blue(to) - Color.blue(from)) * fraction).toInt()
        )
    }
}
