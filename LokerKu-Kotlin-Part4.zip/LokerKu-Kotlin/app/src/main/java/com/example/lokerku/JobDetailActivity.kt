package com.example.lokerku

import android.content.DialogInterface
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Bundle
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ImageSpan
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.lokerku.ApiClient.post
import com.example.lokerku.AppFont.semibold
import com.example.lokerku.FavoritesStore.name
import com.example.lokerku.FontEnforcer.apply
import org.json.JSONException
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

class JobDetailActivity : AppCompatActivity() {
    private var job: JSONObject? = null

    private var tvTitle: TextView? = null
    private var tvCompany: TextView? = null
    private var tvLocation: TextView? = null
    private var tvCategory: TextView? = null
    private var tvType: TextView? = null
    private var tvSalary: TextView? = null
    private var tvDescription: TextView? = null
    private var tvRequirements: TextView? = null
    private var tvAddress: TextView? = null
    private var btnMap: Button? = null

    private var btnApply: Button? = null
    private var btnFavorite: Button? = null

    private var jobId = -1
    private var isFavorite = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val jobJson = intent.getStringExtra("job_json")

        if (jobJson == null || jobJson.trim { it <= ' ' }.isEmpty()) {
            Toast.makeText(
                this,
                "Data pekerjaan tidak ditemukan.",
                Toast.LENGTH_LONG
            ).show()

            finish()
            return
        }

        try {
            job = JSONObject(jobJson)
            jobId = job!!.optInt("id", -1)
        } catch (e: JSONException) {
            Toast.makeText(
                this,
                "Data pekerjaan tidak valid.",
                Toast.LENGTH_LONG
            ).show()

            finish()
            return
        }

        buatTampilan()
        tampilkanDataPekerjaan()
    }

    private fun buatTampilan() {
        val scrollView = ScrollView(this)
        scrollView.isFillViewport = true
        scrollView.setBackgroundColor(BG)
        scrollView.clipToPadding = false

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)
        root.clipChildren = false
        root.clipToPadding = false

        scrollView.addView(root)

        val header = LinearLayout(this)
        header.orientation = LinearLayout.VERTICAL
        header.setPadding(dp(20f), dp(16f), dp(20f), dp(28f))
        header.background = buatGradient(
            NAVY,
            Color.rgb(0, 0, 204),
            dp(24f)
        )

        val topBar = LinearLayout(this)
        topBar.orientation = LinearLayout.HORIZONTAL
        topBar.gravity = Gravity.CENTER_VERTICAL

        val btnBack = TextView(this)
        btnBack.text = "‹"
        btnBack.textSize = 38f
        btnBack.setTextColor(WHITE)
        btnBack.gravity = Gravity.CENTER
        btnBack.contentDescription = "Kembali"
        btnBack.background = buatBackground(
            Color.argb(35, 255, 255, 255),
            dp(14f)
        )

        val backParams =
            LinearLayout.LayoutParams(dp(46f), dp(46f))

        topBar.addView(btnBack, backParams)

        val tvHeader = TextView(this)
        tvHeader.text = "Detail Pekerjaan"
        tvHeader.setTextColor(WHITE)
        tvHeader.textSize = 18f
        tvHeader.typeface = semibold(this)
        tvHeader.gravity = Gravity.CENTER

        val headerTitleParams =
            LinearLayout.LayoutParams(
                0,
                dp(46f),
                1f
            )

        headerTitleParams.leftMargin = dp(12f)
        topBar.addView(tvHeader, headerTitleParams)

        val spacer = TextView(this)
        topBar.addView(
            spacer,
            LinearLayout.LayoutParams(dp(46f), dp(46f))
        )

        btnBack.setOnClickListener { v: View? -> finish() }

        header.addView(topBar)

        val tvHeaderCaption = TextView(this)
        tvHeaderCaption.text = "Temukan pekerjaan yang sesuai denganmu"
        tvHeaderCaption.textSize = 13f
        tvHeaderCaption.setTextColor(Color.rgb(218, 231, 239))
        tvHeaderCaption.setPadding(0, dp(20f), 0, 0)

        header.addView(tvHeaderCaption)
        root.addView(header)

        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(18f), dp(18f), dp(18f), dp(40f))
        content.clipChildren = false
        content.clipToPadding = false

        root.addView(content)

        val jobCard = LinearLayout(this)
        jobCard.orientation = LinearLayout.VERTICAL
        jobCard.setPadding(dp(22f), dp(24f), dp(22f), dp(24f))
        jobCard.background = buatBackground(WHITE, dp(26f))
        jobCard.elevation = dp(3f).toFloat()

        content.addView(
            jobCard,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )

        val tvLabel = TextView(this)
        tvLabel.text = "INFORMASI LOWONGAN"
        tvLabel.textSize = 11f
        tvLabel.letterSpacing = 0.08f
        tvLabel.setTextColor(TEAL)
        tvLabel.typeface = semibold(this)

        jobCard.addView(tvLabel)

        tvTitle = TextView(this)
        tvTitle!!.textSize = 24f
        tvTitle!!.setTextColor(NAVY)
        tvTitle!!.typeface = semibold(this)
        tvTitle!!.setPadding(0, dp(14f), 0, dp(8f))

        jobCard.addView(tvTitle)

        tvCompany = TextView(this)
        tvCompany!!.textSize = 15f
        tvCompany!!.setTextColor(TEXT)
        tvCompany!!.typeface = semibold(this)

        jobCard.addView(tvCompany)

        tvLocation = buatTextView(14, MUTED)
        tvLocation!!.setPadding(0, dp(8f), 0, 0)
        jobCard.addView(tvLocation)

        val tags = LinearLayout(this)
        tags.orientation = LinearLayout.HORIZONTAL
        tags.gravity = Gravity.CENTER_VERTICAL
        tags.setPadding(0, dp(18f), 0, 0)

        tvCategory = buatTag()
        tvType = buatTag()

        val tagParams =
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )

        tagParams.rightMargin = dp(8f)

        tags.addView(tvCategory, tagParams)
        tags.addView(tvType)

        val tagScroll = HorizontalScrollView(this)
        tagScroll.isHorizontalScrollBarEnabled = false
        tagScroll.addView(tags)
        jobCard.addView(tagScroll)

        val salaryLabel = buatSectionTitle("Kisaran Gaji")
        salaryLabel.setPadding(0, dp(24f), 0, dp(8f))
        jobCard.addView(salaryLabel)

        tvSalary = buatTextView(17, TEAL)
        tvSalary!!.typeface = semibold(this)
        jobCard.addView(tvSalary)

        val descriptionCard = buatSectionCard(content)

        val descriptionTitle = buatSectionTitle("Deskripsi Pekerjaan")
        descriptionCard.addView(descriptionTitle)

        tvDescription = buatTextView(14, TEXT)
        tvDescription!!.setPadding(0, dp(12f), 0, 0)
        tvDescription!!.setLineSpacing(dp(4f).toFloat(), 1.0f)
        descriptionCard.addView(tvDescription)

        val requirementCard = buatSectionCard(content)

        val requirementTitle = buatSectionTitle("Persyaratan")
        requirementCard.addView(requirementTitle)

        tvRequirements = buatTextView(14, TEXT)
        tvRequirements!!.setPadding(0, dp(12f), 0, 0)
        tvRequirements!!.setLineSpacing(dp(4f).toFloat(), 1.0f)
        requirementCard.addView(tvRequirements)

        val locationCard = buatSectionCard(content)
        locationCard.addView(buatSectionTitle("Alamat & Lokasi"))

        tvAddress = buatTextView(14, TEXT)
        tvAddress!!.setPadding(0, dp(12f), 0, dp(14f))
        tvAddress!!.setLineSpacing(dp(3f).toFloat(), 1.0f)
        locationCard.addView(tvAddress)

        btnMap = Button(this)
        btnMap!!.text = "Lihat lokasi di Google Maps"
        btnMap!!.setTextColor(WHITE)
        btnMap!!.textSize = 14f
        btnMap!!.isAllCaps = false
        btnMap!!.typeface = semibold(this)
        btnMap!!.background = buatBackground(TEAL, dp(16f))
        btnMap!!.minHeight = dp(48f)
        locationCard.addView(btnMap, LinearLayout.LayoutParams(-1, -2))
        btnMap!!.setOnClickListener { v: View? -> bukaGoogleMaps() }

        val actionCard = LinearLayout(this)
        actionCard.orientation = LinearLayout.VERTICAL
        actionCard.setPadding(dp(20f), dp(20f), dp(20f), dp(20f))
        val actionSurface = buatBackground(WHITE, dp(24f))
        actionSurface.setStroke(dp(1f), Color.rgb(221, 224, 255))
        actionCard.background = actionSurface
        actionCard.elevation = dp(3f).toFloat()

        val actionParams =
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )

        actionParams.topMargin = dp(16f)
        content.addView(actionCard, actionParams)

        val actionsHeading = buatSectionTitle("Langkah berikutnya")
        actionCard.addView(actionsHeading)
        val actionsHint = buatTextView(12, MUTED)
        actionsHint.text = "Simpan lowongan pilihanmu agar mudah ditemukan kembali."
        actionsHint.setLineSpacing(dp(3f).toFloat(), 1f)
        val hintParams = LinearLayout.LayoutParams(-1, -2)
        hintParams.topMargin = dp(6f)
        hintParams.bottomMargin = dp(16f)
        actionCard.addView(actionsHint, hintParams)

        btnApply = Button(this)
        btnApply!!.text = "Catat Lamaran"
        btnApply!!.setTextColor(WHITE)
        btnApply!!.textSize = 15f
        btnApply!!.isAllCaps = false
        btnApply!!.backgroundTintList = null
        btnApply!!.elevation = 0f
        btnApply!!.stateListAnimator = null
        btnApply!!.typeface = semibold(this)
        btnApply!!.background = buatGradient(Color.rgb(0, 0, 204), Color.rgb(62, 68, 255), dp(16f))
        btnApply!!.minHeight = dp(54f)

        actionCard.addView(
            btnApply,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )
        val applyStatus = buatTextView(11, MUTED)
        applyStatus.text = "Dicatat di LokerKu, tidak dikirim otomatis ke perusahaan."
        applyStatus.gravity = Gravity.CENTER
        val asp = LinearLayout.LayoutParams(-1, -2)
        asp.topMargin = dp(7f)
        actionCard.addView(applyStatus, asp)

        btnFavorite = Button(this)
        btnFavorite!!.text = "Simpan Lowongan"
        btnFavorite!!.setTextColor(NAVY)
        btnFavorite!!.textSize = 14f
        btnFavorite!!.isAllCaps = false
        btnFavorite!!.elevation = 0f
        btnFavorite!!.stateListAnimator = null
        btnFavorite!!.typeface = semibold(this)
        btnFavorite!!.background = buatBackground(
            Color.rgb(232, 232, 255),
            dp(14f)
        )

        val favoriteParams =
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        btnFavorite!!.minHeight = dp(54f)

        favoriteParams.topMargin = dp(10f)

        actionCard.addView(btnFavorite, favoriteParams)

        btnApply!!.setOnClickListener { v: View? ->
            PremiumDialog.Builder(this)
                .setTitle("Catat lamaran ini?")
                .setMessage("Lamaran akan tercatat di LokerKu untuk pemantauan. Data ini tidak otomatis dikirim ke perusahaan.")
                .setNegativeButton("Batal", null)
                .setPositiveButton("Catat") { dialog: DialogInterface?, which: Int ->
                    if (jobId <= 0) {
                        Toast.makeText(
                            this,
                            "Lowongan tidak valid.",
                            Toast.LENGTH_LONG
                        ).show()
                        return@setPositiveButton
                    }
                    btnApply!!.isEnabled = false
                    val p: MutableMap<String, String> =
                        HashMap()
                    p["action"] = "create"
                    p["job_id"] = jobId.toString()
                    post(
                        this,
                        "profile/applications.php",
                        p,
                        object : ApiClient.Result {
                            override fun success(json: JSONObject) {
                                btnApply!!.isEnabled = true
                                Toast.makeText(
                                    this@JobDetailActivity,
                                    json.optString("message", "Tercatat"),
                                    Toast.LENGTH_LONG
                                ).show()
                            }

                            override fun fail(message: String) {
                                btnApply!!.isEnabled = true
                                Toast.makeText(
                                    this@JobDetailActivity,
                                    message,
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        })
                }.show()
        }

        isFavorite = isJobFavorite
        updateFavoriteButton()
        btnFavorite!!.setOnClickListener { v: View? ->
            isFavorite = !isFavorite
            simpanStatusFavorit()
            updateFavoriteButton()
            Toast.makeText(
                this@JobDetailActivity,
                if (isFavorite) "Lowongan disimpan ke favorit" else "Lowongan dihapus dari favorit",
                Toast.LENGTH_SHORT
            ).show()
        }

        setContentView(scrollView)
        apply(scrollView, this)
        UiMotion.styleButtons(scrollView)
        UiMotion.bindActions(scrollView)
        UiMotion.bindPress(btnBack)
        UiMotion.reveal(header, 40)
        UiMotion.revealChildren(content, 120, 80, 7)
    }

    override fun onPause() {
        UiMotion.finishReveals(window.decorView)
        super.onPause()
    }

    private fun tampilkanDataPekerjaan() {
        val title = ambilString(
            "judul",
            "title",
            "nama_pekerjaan"
        )

        val company = ambilString(
            "perusahaan",
            "company",
            "nama_perusahaan"
        )

        val location = ambilString(
            "lokasi",
            "location",
            "kota"
        )

        val category = ambilString(
            "kategori_nama",
            "kategori",
            "category"
        )

        val type = ambilString(
            "tipe",
            "jenis_pekerjaan",
            "type"
        )

        val description = ambilString(
            "deskripsi",
            "description"
        )

        val requirements = ambilString(
            "persyaratan",
            "requirements",
            "kualifikasi"
        )

        val salaryMin = ambilAngka(
            "gaji_min",
            "salary_min",
            "gaji_minimum"
        )

        val salaryMax = ambilAngka(
            "gaji_max",
            "salary_max",
            "gaji_maksimum"
        )

        tvTitle!!.text = title
        tvCompany!!.text = company
        tvLocation!!.text = "⌖  $location"
        var address = ambilString(
            "alamat_lengkap", "alamat", "full_address",
            "address", "alamat_perusahaan", "address_company"
        )
        if ("Informasi belum tersedia." == address) {
            address = location
        }
        tvAddress!!.text = address
        tvCategory!!.text = category
        tvType!!.text = type
        tvDescription!!.text = description
        tvRequirements!!.text = requirements
        tvSalary!!.text = formatGaji(salaryMin, salaryMax)
    }

    private fun isCoordinate(value: String?): Boolean {
        if (value == null || value.trim { it <= ' ' }.isEmpty()
            || "Informasi belum tersedia." == value
        ) return false
        try {
            value.trim { it <= ' ' }.toDouble()
            return true
        } catch (ignored: NumberFormatException) {
            return false
        }
    }

    private val isJobFavorite: Boolean
        get() {
            if (jobId < 0) return false
            val prefs = getSharedPreferences(
                name(this),
                MODE_PRIVATE
            )
            val saved = prefs.getStringSet(
                KEY_FAVORITES,
                HashSet()
            )
            return saved != null && saved.contains(jobId.toString())
        }

    private fun simpanStatusFavorit() {
        if (jobId < 0) return
        val prefs = getSharedPreferences(name(this), MODE_PRIVATE)
        val current =
            prefs.getStringSet(KEY_FAVORITES, HashSet())
        val saved: MutableSet<String> = if (current == null)
            HashSet()
        else
            HashSet(current)
        val id = jobId.toString()
        if (isFavorite) saved.add(id) else saved.remove(id)
        prefs.edit().putStringSet(KEY_FAVORITES, saved).apply()
    }

    private fun updateFavoriteButton() {
        if (btnFavorite == null) return
        val label = if (isFavorite) "Tersimpan di Favorit" else "Simpan ke Favorit"
        btnFavorite!!.setTextColor(if (isFavorite) TEAL else NAVY)
        btnFavorite!!.contentDescription = label
        btnFavorite!!.gravity = Gravity.CENTER
        btnFavorite!!.setCompoundDrawablesWithIntrinsicBounds(null, null, null, null)
        val caption = SpannableString("\uFFFC  $label")
        var heartIcon = getDrawable(R.drawable.ic_favorite)
        if (heartIcon != null) {
            heartIcon = heartIcon.mutate()
            heartIcon.setTint(if (isFavorite) TEAL else NAVY)
            heartIcon.setBounds(0, 0, dp(20f), dp(20f))
            caption.setSpan(
                ImageSpan(heartIcon, ImageSpan.ALIGN_BOTTOM),
                0,
                1,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
        btnFavorite!!.text = caption
        val state = buatBackground(
            if (isFavorite) Color.rgb(232, 232, 255) else Color.WHITE, dp(16f)
        )
        state.setStroke(
            dp(1f),
            if (isFavorite) Color.rgb(110, 120, 255) else Color.rgb(207, 216, 247)
        )
        btnFavorite!!.backgroundTintList = null
        btnFavorite!!.background = RippleDrawable(
            ColorStateList.valueOf(0x330000ff), state, null
        )
        btnFavorite!!.minHeight = dp(50f)
    }

    private fun bukaGoogleMaps() {
        val address = if (tvAddress == null) "" else tvAddress!!.text.toString().trim { it <= ' ' }
        val company = ambilString("perusahaan", "company", "nama_perusahaan")
        var query = address
        if (query.isEmpty() || "Informasi belum tersedia." == query) {
            query = ambilString("lokasi", "location", "kota")
        }
        if (!company.isEmpty() && !query.lowercase().contains(company.lowercase())) {
            query = "$query $company"
        }
        if (query.trim { it <= ' ' }.isEmpty() || "Lokasi tidak dicantumkan" == query) {
            Toast.makeText(this, "Alamat lowongan belum tersedia dari server.", Toast.LENGTH_LONG)
                .show()
            return
        }
        val latitude = ambilString("latitude", "lat", "koordinat_latitude")
        val longitude = ambilString("longitude", "lng", "lon", "koordinat_longitude")
        var mapQuery = query
        if (isCoordinate(latitude) && isCoordinate(longitude)) {
            mapQuery = "$latitude,$longitude"
        }
        val mapsUri =
            Uri.parse("https://www.google.com/maps/search/?api=1&query=" + Uri.encode(mapQuery))
        val mapsIntent = Intent(Intent.ACTION_VIEW, mapsUri)
        try {
            startActivity(mapsIntent)
        } catch (e: Exception) {
            Toast.makeText(this, "Tidak dapat membuka Google Maps.", Toast.LENGTH_LONG).show()
        }
    }

    private fun ambilString(vararg keys: String): String {
        for (key in keys) {
            if (job!!.has(key) && !job!!.isNull(key)) {
                val value = job!!.optString(key, "").trim { it <= ' ' }

                if (!value.isEmpty()
                    && !"null".equals(value, ignoreCase = true)
                ) {
                    return value
                }
            }
        }

        if (keys.size > 0) {
            if ("judul" == keys[0]
                || "title" == keys[0]
                || "nama_pekerjaan" == keys[0]
            ) {
                return "Lowongan Pekerjaan"
            }

            if ("perusahaan" == keys[0]
                || "company" == keys[0]
                || "nama_perusahaan" == keys[0]
            ) {
                return "Nama perusahaan tidak tersedia"
            }

            if ("lokasi" == keys[0]
                || "location" == keys[0]
                || "kota" == keys[0]
            ) {
                return "Lokasi tidak dicantumkan"
            }

            if ("tipe" == keys[0]
                || "jenis_pekerjaan" == keys[0]
                || "type" == keys[0]
            ) {
                return "Tipe tidak dicantumkan"
            }

            if ("kategori_nama" == keys[0]
                || "kategori" == keys[0]
                || "category" == keys[0]
            ) {
                return "Umum"
            }
        }

        return "Informasi belum tersedia."
    }

    private fun ambilAngka(vararg keys: String): Int {
        for (key in keys) {
            if (!job!!.has(key) || job!!.isNull(key)) {
                continue
            }

            val value = job!!.opt(key)

            if (value is Number) {
                return value.toInt()
            }

            if (value is String) {
                try {
                    return value.trim { it <= ' ' }.toInt()
                } catch (ignored: NumberFormatException) {
                    // Coba nama kolom berikutnya.
                }
            }
        }

        return 0
    }

    private fun formatGaji(minimum: Int, maksimum: Int): String {
        if (minimum <= 0 && maksimum <= 0) {
            return "Gaji tidak dicantumkan"
        }

        val formatter = NumberFormat.getNumberInstance(
            Locale("id", "ID")
        )

        if (minimum > 0 && maksimum > 0) {
            return ("Rp " + formatter.format(minimum.toLong())
                    + " – Rp " + formatter.format(maksimum.toLong()))
        }

        if (minimum > 0) {
            return "Mulai Rp " + formatter.format(minimum.toLong())
        }

        return "Hingga Rp " + formatter.format(maksimum.toLong())
    }

    private fun buatSectionCard(parent: LinearLayout): LinearLayout {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(20f), dp(20f), dp(20f), dp(20f))
        card.background = buatBackground(WHITE, dp(24f))
        card.elevation = dp(2f).toFloat()

        val params =
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )

        params.topMargin = dp(16f)

        parent.addView(card, params)

        return card
    }

    private fun buatSectionTitle(text: String): TextView {
        val view = TextView(this)
        view.text = text
        view.textSize = 17f
        view.setTextColor(NAVY)
        view.typeface = semibold(this)

        return view
    }

    private fun buatTextView(size: Int, color: Int): TextView {
        val view = TextView(this)
        view.textSize = size.toFloat()
        view.setTextColor(color)
        view.gravity = Gravity.START
        view.includeFontPadding = true

        return view
    }

    private fun buatTag(): TextView {
        val view = TextView(this)
        view.textSize = 12f
        view.setTextColor(TEAL)
        view.setPadding(dp(12f), dp(8f), dp(12f), dp(8f))
        view.background = buatBackground(
            Color.rgb(232, 232, 255),
            dp(10f)
        )

        return view
    }

    private fun buatBackground(color: Int, radius: Int): GradientDrawable {
        val drawable = GradientDrawable()
        drawable.setColor(color)
        if (color == WHITE) drawable.setStroke(dp(1f), Color.rgb(221, 224, 255))
        drawable.cornerRadius = radius.toFloat()

        return drawable
    }

    private fun buatGradient(
        startColor: Int,
        endColor: Int,
        radius: Int
    ): GradientDrawable {
        val drawable = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(startColor, endColor)
        )

        drawable.cornerRadius = radius.toFloat()

        return drawable
    }

    private fun dp(value: Float): Int {
        return (value * resources
            .displayMetrics.density + 0.5f).toInt()
    }

    companion object {
        private val NAVY = Color.rgb(21, 26, 61)
        private val TEAL = Color.rgb(0, 0, 255)
        private val BG = Color.rgb(247, 248, 255)
        private val TEXT = Color.rgb(21, 26, 61)
        private val MUTED = Color.rgb(104, 112, 143)
        private const val WHITE = Color.WHITE

        private const val PREF_FAVORITES = "lokerku_favorites"
        private const val KEY_FAVORITES = "job_ids"
    }
}
