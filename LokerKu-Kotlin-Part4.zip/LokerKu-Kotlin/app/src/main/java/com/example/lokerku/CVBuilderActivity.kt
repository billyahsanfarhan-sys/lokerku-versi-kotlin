package com.example.lokerku

import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.text.TextUtils
import android.util.Patterns
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.lokerku.AppFont.regular
import com.example.lokerku.AppFont.semibold
import java.util.Locale

class CVBuilderActivity : AppCompatActivity() {
    private val BLUE = Color.rgb(0, 82, 255)
    private val DARK_BLUE = Color.rgb(18, 35, 88)
    private val BG = Color.rgb(246, 248, 255)
    private val TEXT = Color.rgb(28, 39, 66)
    private val MUTED = Color.rgb(105, 117, 148)
    private val BORDER = Color.rgb(222, 229, 245)
    private val WHITE = Color.WHITE

    private var name: EditText? = null
    private var email: EditText? = null
    private var phone: EditText? = null
    private var address: EditText? = null
    private var objective: EditText? = null
    private var education: EditText? = null
    private var experience: EditText? = null
    private var skills: EditText? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        if (Build.VERSION.SDK_INT >= 23) window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.setBackgroundColor(BG)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20f), dp(14f), dp(20f), dp(28f))
        scroll.addView(root)
        setContentView(scroll)
        FontEnforcer.apply(root, this)

        val back = text("‹   Kembali ke Beranda", 14, BLUE, true)
        back.setPadding(0, dp(8f), 0, dp(20f))
        back.setOnClickListener { v: View? -> finish() }
        back.minHeight = dp(48f)
        root.addView(back)

        val hero = LinearLayout(this)
        hero.orientation = LinearLayout.VERTICAL
        hero.setPadding(dp(20f), dp(22f), dp(20f), dp(22f))
        hero.background = gradient(BLUE, Color.rgb(82, 112, 255), 24)
        val tag = text("✦  CAREER TOOLKIT", 11, Color.WHITE, true)
        hero.addView(tag)
        val title = text("Buat CV profesionalmu", 25, Color.WHITE, true)
        val titleP = LinearLayout.LayoutParams(-1, -2)
        titleP.topMargin = dp(10f)
        hero.addView(title, titleP)
        val sub = text(
            "Isi informasi penting di bawah. Susun pengalamanmu dengan jelas dan tampilkan kelebihan yang relevan.",
            13,
            Color.rgb(238, 242, 255),
            false
        )
        sub.setLineSpacing(dp(3f).toFloat(), 1f)
        val subP = LinearLayout.LayoutParams(-1, -2)
        subP.topMargin = dp(8f)
        hero.addView(sub, subP)
        root.addView(hero)

        val progress = card()
        progress.orientation = LinearLayout.HORIZONTAL
        progress.gravity = Gravity.CENTER_VERTICAL
        val circle = text("1", 14, Color.WHITE, true)
        circle.gravity = Gravity.CENTER
        circle.background = gradient(BLUE, BLUE, 50)
        progress.addView(circle, LinearLayout.LayoutParams(dp(34f), dp(34f)))
        val progressText = LinearLayout(this)
        progressText.orientation = LinearLayout.VERTICAL
        progressText.setPadding(dp(12f), 0, 0, 0)
        progressText.addView(text("Lengkapi data CV", 14, TEXT, true))
        progressText.addView(text("Bagian bertanda wajib sebaiknya diisi", 11, MUTED, false))
        progress.addView(progressText, LinearLayout.LayoutParams(0, -2, 1f))
        val progressP = LinearLayout.LayoutParams(-1, -2)
        progressP.topMargin = dp(16f)
        root.addView(progress, progressP)

        val personal =
            section(root, "Informasi pribadi", "Gunakan data yang bisa dihubungi perekrut.")
        name = field(personal, "Nama lengkap *", "Contoh: Andi Pratama")
        email = field(personal, "Email *", "nama@email.com")
        email!!.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        phone = field(personal, "Nomor telepon", "Contoh: 081234567890")
        phone!!.inputType = InputType.TYPE_CLASS_PHONE
        address = field(personal, "Domisili", "Kota tempat tinggal")

        val objectiveCard = section(
            root,
            "Profil singkat",
            "Tulis 2–3 kalimat tentang kemampuan dan tujuan kariermu."
        )
        objective = multiField(
            objectiveCard,
            "Tentang saya",
            "Contoh: Lulusan Sistem Informasi yang tertarik pada pengembangan aplikasi dan analisis data..."
        )

        val educationCard = section(root, "Pendidikan", "Mulai dari pendidikan terbaru.")
        education = multiField(
            educationCard,
            "Riwayat pendidikan",
            "Nama sekolah/kampus, jurusan, tahun lulus"
        )

        val experienceCard =
            section(root, "Pengalaman", "Bisa berupa pekerjaan, magang, organisasi, atau proyek.")
        experience = multiField(
            experienceCard,
            "Pengalaman kerja / proyek",
            "Posisi atau proyek — tempat — periode\nTuliskan tanggung jawab dan hasil yang relevan."
        )

        val skillsCard = section(root, "Keahlian", "Pisahkan setiap keahlian dengan koma.")
        skills = multiField(
            skillsCard,
            "Keahlian utama",
            "Contoh: Microsoft Excel, Java, komunikasi, kerja tim"
        )

        val tips = card()
        tips.orientation = LinearLayout.VERTICAL
        tips.background = gradient(Color.rgb(235, 243, 255), Color.rgb(246, 248, 255), 18)
        tips.addView(text("✧  Tips CV yang lebih kuat", 14, DARK_BLUE, true))
        val tipsText = text(
            "• Sesuaikan CV dengan posisi yang dilamar.\n• Utamakan informasi yang relevan dan mudah dibaca.\n• Periksa ejaan, tanggal, dan kontak sebelum dibagikan.",
            12,
            MUTED,
            false
        )
        tipsText.setLineSpacing(dp(4f).toFloat(), 1f)
        val tipsTP = LinearLayout.LayoutParams(-1, -2)
        tipsTP.topMargin = dp(8f)
        tips.addView(tipsText, tipsTP)
        val tipsP = LinearLayout.LayoutParams(-1, -2)
        tipsP.topMargin = dp(18f)
        root.addView(tips, tipsP)

        val preview = button("Pratinjau CV  →", BLUE)
        val bp = LinearLayout.LayoutParams(-1, dp(54f))
        bp.topMargin = dp(18f)
        root.addView(preview, bp)
        preview.setOnClickListener { v: View? -> showPreview() }
        val footer = text(
            "Pratinjau ini membantu merapikan isi CV. Pastikan semua informasi sudah benar sebelum kamu menyalinnya ke dokumen akhir.",
            11,
            MUTED,
            false
        )
        footer.gravity = Gravity.CENTER
        footer.setLineSpacing(dp(3f).toFloat(), 1f)
        val fp = LinearLayout.LayoutParams(-1, -2)
        fp.topMargin = dp(12f)
        root.addView(footer, fp)
        FontEnforcer.apply(root, this)
        UiMotion.styleButtons(scroll)
        UiMotion.bindActions(scroll)
        UiMotion.bindPress(back)
        UiMotion.revealChildren(root, 50, 70, 9)
    }

    override fun onPause() {
        UiMotion.finishReveals(window.decorView)
        super.onPause()
    }

    private fun section(root: LinearLayout, title: String, subtitle: String): LinearLayout {
        val t = text(title, 18, TEXT, true)
        val p = LinearLayout.LayoutParams(-1, -2)
        p.topMargin = dp(23f)
        root.addView(t, p)
        val s = text(subtitle, 12, MUTED, false)
        val sp = LinearLayout.LayoutParams(-1, -2)
        sp.topMargin = dp(5f)
        sp.bottomMargin = dp(12f)
        root.addView(s, sp)
        val group = card()
        group.setPadding(dp(18f), dp(18f), dp(18f), dp(8f))
        root.addView(group, LinearLayout.LayoutParams(-1, -2))
        return group
    }

    private fun field(root: LinearLayout, label: String, hint: String): EditText {
        root.addView(text(label, 13, TEXT, true))
        val e = EditText(this)
        e.typeface = regular(this)
        e.isSingleLine = true
        e.textSize = 14f
        e.setTextColor(TEXT)
        e.setHintTextColor(MUTED)
        e.hint = hint
        e.setPadding(dp(14f), 0, dp(14f), 0)
        e.background = outline()
        val p = LinearLayout.LayoutParams(-1, -2)
        e.minHeight = dp(52f)
        p.topMargin = dp(7f)
        p.bottomMargin = dp(14f)
        root.addView(e, p)
        return e
    }

    private fun multiField(root: LinearLayout, label: String, hint: String): EditText {
        root.addView(text(label, 13, TEXT, true))
        val e = EditText(this)
        e.typeface = regular(this)
        e.textSize = 14f
        e.setTextColor(TEXT)
        e.setHintTextColor(MUTED)
        e.hint = hint
        e.gravity = Gravity.TOP or Gravity.START
        e.minLines = 3
        e.setPadding(dp(14f), dp(12f), dp(14f), dp(12f))
        e.background = outline()
        val p = LinearLayout.LayoutParams(-1, -2)
        e.minHeight = dp(112f)
        p.topMargin = dp(7f)
        p.bottomMargin = dp(14f)
        root.addView(e, p)
        return e
    }

    private fun showPreview() {
        val n = value(name)
        val em = value(email)
        if (TextUtils.isEmpty(n)) {
            name!!.error = "Nama lengkap wajib diisi"
            name!!.requestFocus()
            return
        }
        if (TextUtils.isEmpty(em) || !Patterns.EMAIL_ADDRESS.matcher(em).matches()) {
            email!!.error = "Masukkan email yang valid"
            email!!.requestFocus()
            return
        }
        try {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(
                name!!.windowToken, 0
            )
        } catch (ignored: Exception) {
        }
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20f), dp(18f), dp(20f), dp(18f))
        box.background = rounded(WHITE, 18)
        val heading = text(n.uppercase(Locale.getDefault()), 20, DARK_BLUE, true)
        box.addView(heading)
        val contact = text(join(value(email), value(phone), value(address)), 11, MUTED, false)
        val cp = LinearLayout.LayoutParams(-1, -2)
        cp.topMargin = dp(5f)
        box.addView(contact, cp)
        addPreviewSection(box, "PROFIL", value(objective))
        addPreviewSection(box, "PENDIDIKAN", value(education))
        addPreviewSection(box, "PENGALAMAN", value(experience))
        addPreviewSection(box, "KEAHLIAN", value(skills))
        val sc = ScrollView(this)
        sc.addView(box)
        PremiumDialog.Builder(this).setTitle("Pratinjau CV").setView(sc)
            .setPositiveButton("Selesai", null).setNeutralButton(
                "Bagikan isi"
            ) { d: DialogInterface?, w: Int -> shareText(buildCvText()) }.show()
    }

    private fun addPreviewSection(box: LinearLayout, title: String, content: String) {
        if (TextUtils.isEmpty(content)) return
        val h = text(title, 12, BLUE, true)
        val hp = LinearLayout.LayoutParams(-1, -2)
        hp.topMargin = dp(16f)
        box.addView(h, hp)
        val body = text(content, 13, TEXT, false)
        body.setLineSpacing(dp(3f).toFloat(), 1f)
        val bp = LinearLayout.LayoutParams(-1, -2)
        bp.topMargin = dp(5f)
        box.addView(body, bp)
    }

    private fun buildCvText(): String {
        return """
            ${value(name)}
            ${join(value(email), value(phone), value(address))}
            
            PROFIL
            ${value(objective)}
            
            PENDIDIKAN
            ${value(education)}
            
            PENGALAMAN
            ${value(experience)}
            
            KEAHLIAN
            ${value(skills)}
            """.trimIndent()
    }

    private fun shareText(content: String) {
        val i = Intent(Intent.ACTION_SEND)
        i.setType("text/plain")
        i.putExtra(Intent.EXTRA_TEXT, content)
        startActivity(Intent.createChooser(i, "Bagikan CV"))
    }

    private fun value(e: EditText?): String {
        return e?.text?.toString()?.trim { it <= ' ' } ?: ""
    }

    private fun join(vararg values: String): String {
        val b = StringBuilder()
        for (v in values) if (!TextUtils.isEmpty(v)) {
            if (b.length > 0) b.append("  •  ")
            b.append(v)
        }
        return if (b.length == 0) "Kontak belum diisi" else b.toString()
    }

    private fun card(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(dp(15f), dp(15f), dp(15f), dp(15f))
        l.background = rounded(WHITE, 18)
        l.elevation = dp(2f).toFloat()
        return l
    }

    private fun text(s: String, size: Int, color: Int, bold: Boolean): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size.toFloat()
        t.setTextColor(color)
        t.typeface =
            if (bold) semibold(this) else regular(this)
        return t
    }

    private fun button(s: String, color: Int): Button {
        val b = Button(this)
        b.text = s
        b.setTextColor(WHITE)
        b.textSize = 14f
        b.isAllCaps = false
        b.typeface = semibold(this)
        b.background = rounded(color, 16)
        return b
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        if (color == WHITE) d.setStroke(dp(1f), BORDER)
        d.cornerRadius = dp(radius.toFloat()).toFloat()
        return d
    }

    private fun gradient(c1: Int, c2: Int, radius: Int): GradientDrawable {
        val d = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2))
        d.cornerRadius = dp(radius.toFloat()).toFloat()
        return d
    }

    private fun outline(): GradientDrawable {
        val d = rounded(WHITE, 13)
        d.setStroke(dp(1f), BORDER)
        return d
    }

    private fun dp(v: Float): Int {
        return (v * resources.displayMetrics.density + 0.5f).toInt()
    }
}
