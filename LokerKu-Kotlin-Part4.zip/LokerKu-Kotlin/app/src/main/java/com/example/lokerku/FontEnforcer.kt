package com.example.lokerku

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.example.lokerku.AppFont.regular
import com.example.lokerku.AppFont.semibold

object FontEnforcer {
    @JvmStatic
    fun apply(view: View?, context: Context) {
        if (view is TextView) {
            val textView = view
            val current = textView.typeface

            // Apply bundled Poppins even when the device replaces system fonts.
            val regular = regular(context)
            val semibold = semibold(context)
            val bold = current != null && (current == semibold || current.isBold)
            textView.typeface = if (bold) semibold else regular
        }

        if (view is ViewGroup) {
            val group = view
            for (i in 0 until group.childCount) {
                apply(group.getChildAt(i), context)
            }
        }
    }
}
