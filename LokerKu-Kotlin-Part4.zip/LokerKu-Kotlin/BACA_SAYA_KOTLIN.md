# LokerKu versi Kotlin

Proyek aplikasi ini dikonversi dari proyek Java yang diberikan. Seluruh 28 file sumber aplikasi utama dan dua file contoh pengujian sudah berbentuk Kotlin. Manifest dan 91 file aset/resource lainnya pada `app/src/main` dipertahankan sama dengan proyek asal. Plugin Kotlin Android dan dependensi untuk pengujian contoh ditambahkan ke konfigurasi Gradle.

## Membuka dan menjalankan

1. Ekstrak ZIP, lalu pilih folder proyek yang berisi `settings.gradle` melalui **File > Open** di Android Studio.
2. Pasang Android SDK Platform 34 dan build tools yang diminta Android Studio. Gunakan **JDK 11 sebagai Gradle JDK** di Settings > Build, Execution, Deployment > Build Tools > Gradle. Gradle Wrapper proyek ini adalah 7.2; JDK bawaan Android Studio versi baru mungkin terlalu baru untuk wrapper tersebut.
3. Sinkronkan Gradle. Koneksi internet diperlukan untuk mengunduh Gradle dan dependensi bila belum tersedia.
4. Pilih perangkat Android atau emulator (minimal API 25), lalu jalankan konfigurasi `app`. Untuk membuat APK debug, gunakan **Build > Build APK(s)** atau `./gradlew :app:assembleDebug`.

## Hasil verifikasi

- `:app:assembleDebug`, `:app:testDebugUnitTest` dan `:app:assembleDebugAndroidTest` berhasil di lingkungan konversi menggunakan JDK 11 dan Android SDK 34. Tes unit yang ada hanya contoh penjumlahan; tes instrumentasi berhasil dikompilasi tetapi belum dijalankan.
- Tidak ada perangkat/emulator tersedia untuk menguji tampilan, navigasi, jaringan, unggah, atau login. Kesamaan perilaku seluruh fitur dengan versi Java perlu diuji pada perangkat dan backend yang digunakan.
- API dan konfigurasi Google Sign-In tetap mengikuti proyek asal. Login Google membutuhkan konfigurasi OAuth dan sertifikat penandatangan APK yang sesuai pada proyek Google yang digunakan. APK debug menggunakan sertifikat debug mesin pembuatnya; tidak cocok otomatis dengan semua konfigurasi OAuth.
- `local.properties` dan cache Gradle sengaja tidak disertakan karena berisi konfigurasi lokal mesin pembuat. Android Studio akan mengatur SDK untuk komputer Anda.
