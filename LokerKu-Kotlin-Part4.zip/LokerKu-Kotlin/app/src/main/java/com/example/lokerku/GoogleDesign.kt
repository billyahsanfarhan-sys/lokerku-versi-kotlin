package com.example.lokerku

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.example.lokerku.AppFont.semibold

/** Google sign-in button.  */
internal object GoogleDesign {
    @JvmStatic
    fun addTo(parent: LinearLayout, context: Context, title: String?) {
        val density = context.resources.displayMetrics.density
        val height = Math.round(52 * density)
        val group = LinearLayout(context)
        group.gravity = Gravity.CENTER
        group.orientation = LinearLayout.HORIZONTAL
        val outline = GradientDrawable()
        outline.setColor(Color.WHITE)
        outline.cornerRadius = 18 * density
        outline.setStroke(Math.round(density), -0x8b888b)
        group.background = outline
        val logo = ImageView(context)
        logo.setImageResource(R.drawable.google_g_official)
        logo.scaleType = ImageView.ScaleType.FIT_CENTER
        group.addView(
            logo,
            LinearLayout.LayoutParams(Math.round(25 * density), Math.round(25 * density))
        )
        val label = TextView(context)
        label.text = title
        label.textSize = 14f
        label.setTextColor(-0xe0e0e1)
        label.typeface = semibold(context)
        val lp = LinearLayout.LayoutParams(-2, -2)
        lp.leftMargin = Math.round(12 * density)
        group.addView(label, lp)
        group.contentDescription = title
        group.setOnClickListener { v: View? ->
            if (!group.isEnabled) return@setOnClickListener
            group.isEnabled = false
            label.text = "Menghubungkan ke Google…"
            GoogleSignInFlow.signIn(context as Activity, context is RegisterActivity) {
                group.isEnabled = true
                label.text = title
            }
        }
        val params = LinearLayout.LayoutParams(-1, height)
        params.topMargin = Math.round(16 * density)
        parent.addView(group, params)
    }
}
