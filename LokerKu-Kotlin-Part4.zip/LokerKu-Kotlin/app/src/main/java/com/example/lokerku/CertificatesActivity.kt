package com.example.lokerku

import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult
import androidx.activity.result.ActivityResultLauncher
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.DefaultRetryPolicy
import com.android.volley.NetworkResponse
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.Volley
import com.example.lokerku.ApiClient.post
import com.example.lokerku.AppFont.regular
import com.example.lokerku.AppFont.semibold
import com.example.lokerku.ProfileActivity.VolleyMultipartRequest
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.nio.charset.StandardCharsets

class CertificatesActivity : AppCompatActivity() {
    private var list: LinearLayout? = null
    private var picker: ActivityResultLauncher<Intent>? = null
    private var pending: Uri? = null
    private var uploading = false
    private fun dp(n: Float): Int {
        return (n * resources.displayMetrics.density + .5f).toInt()
    }

    private fun text(s: String, size: Int, color: Int, bold: Boolean): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size.toFloat()
        t.setTextColor(color)
        t.typeface =
            if (bold) semibold(this) else regular(this)
        return t
    }

    private fun bg(color: Int, radius: Int): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = dp(radius.toFloat()).toFloat()
        return d
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        picker = registerForActivityResult<Intent, ActivityResult>(
            StartActivityForResult()
        ) { result: ActivityResult ->
            if (result.resultCode != RESULT_OK || result.data == null) return@registerForActivityResult
            pending = result.data!!.data
            if (pending == null) return@registerForActivityResult
            val label = EditText(this)
            label.isSingleLine = true
            label.hint = "Contoh: Sertifikat pelatihan"
            PremiumDialog.Builder(this).setTitle("Judul sertifikat")
                .setMessage("Sertifikat akan dapat dilihat dan diunduh siapa saja. Pastikan data di dalamnya aman untuk dipublikasikan.")
                .setView(label).setNegativeButton("Batal", null)
                .setPositiveButton("Publikasikan") { d: DialogInterface?, w: Int ->
                    val name = label.text.toString().trim { it <= ' ' }
                    if (name.isEmpty()) {
                        toast("Judul sertifikat wajib diisi.")
                        return@setPositiveButton
                    }
                    upload(pending!!, name)
                }.show()
        }
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(-0x80701)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20f), dp(26f), dp(20f), dp(30f))
        scroll.addView(root)
        val back = text("‹  Kembali", 15, -0xffff34, true)
        back.setPadding(0, 0, 0, dp(22f))
        back.setOnClickListener { v: View? -> finish() }
        root.addView(back)
        val label = text("PORTOFOLIO  /  LOKERKU", 10, -0xffff34, true)
        label.letterSpacing = .08f
        root.addView(label)
        root.addView(text("Sertifikat publik", 26, -0xe4d8c3, true))
        val desc = text(
            "Unggah PDF, JPG, atau PNG hingga 5 MB. Siapa saja yang memiliki tautan profil dapat melihat dan mengunduhnya.",
            13,
            -0x978f71,
            false
        )
        desc.setPadding(0, dp(8f), 0, dp(18f))
        root.addView(desc)
        val add = text("+  Tambah sertifikat", 14, Color.WHITE, true)
        add.gravity = Gravity.CENTER
        add.background = bg(-0xffff34, 18)
        root.addView(add, LinearLayout.LayoutParams(-1, dp(52f)))
        add.setOnClickListener { v: View? ->
            if (uploading) {
                toast("Unggahan masih berlangsung.")
                return@setOnClickListener
            }
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.setType("*/*")
            i.putExtra(
                Intent.EXTRA_MIME_TYPES,
                arrayOf("application/pdf", "image/jpeg", "image/png")
            )
            picker!!.launch(i)
        }
        val share = text("Bagikan profil publik  ↗", 13, -0xffff34, true)
        share.gravity = Gravity.CENTER
        share.setPadding(dp(12f), dp(16f), dp(12f), dp(14f))
        root.addView(share)
        share.setOnClickListener { v: View? ->
            val id = getSharedPreferences(
                "lokerku_user",
                MODE_PRIVATE
            ).getInt("id", 0)
            if (id <= 0) {
                toast("Masuk kembali.")
                return@setOnClickListener
            }
            val send = Intent(Intent.ACTION_SEND)
            send.setType("text/plain")
            send.putExtra(
                Intent.EXTRA_TEXT,
                ApiClient.BASE + "profile/public.php?id=" + id
            )
            startActivity(Intent.createChooser(send, "Bagikan profil"))
        }
        list = LinearLayout(this)
        list!!.orientation = LinearLayout.VERTICAL
        root.addView(list)
        setContentView(scroll)
        FontEnforcer.apply(root, this)
        UiMotion.bindActions(root)
        UiMotion.revealChildren(root, 80, 65, 6)
        refresh()
    }

    private fun refresh() {
        list!!.removeAllViews()
        val loading = text("Memuat sertifikat…", 12, -0x978f71, false)
        list!!.addView(loading)
        val p: MutableMap<String, String> = HashMap()
        p["action"] = "list"
        post(this, "profile/certificates.php", p, object : ApiClient.Result {
            override fun success(json: JSONObject) {
                list!!.removeAllViews()
                val a = json.optJSONArray("certificates")
                if (a == null || a.length() == 0) {
                    list!!.addView(
                        text(
                            "Belum ada sertifikat. Tambahkan pencapaian pertamamu.",
                            13,
                            -0x978f71,
                            false
                        )
                    )
                    return
                }
                for (i in 0 until a.length()) {
                    val c = a.optJSONObject(i)
                    if (c != null) addCertificate(c)
                }
            }

            override fun fail(msg: String) {
                list!!.removeAllViews()
                list!!.addView(text(msg, 12, -0x4ad1ba, false))
            }
        })
    }

    private fun addCertificate(cert: JSONObject) {
        val id = cert.optLong("id", 0)
        if (id <= 0) return
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(18f), dp(16f), dp(18f), dp(14f))
        card.background = bg(Color.WHITE, 20)
        card.addView(text(cert.optString("label", "Sertifikat"), 15, -0xe4d8c3, true))
        val date =
            text("Dokumen publik  •  " + cert.optString("created_at", ""), 11, -0x978f71, false)
        date.setPadding(0, dp(5f), 0, dp(10f))
        card.addView(date)
        val row = LinearLayout(this)
        val open = text("Lihat / unduh", 13, -0xffff34, true)
        open.setPadding(0, dp(6f), dp(20f), dp(6f))
        row.addView(open)
        val del = text("Hapus", 13, -0x40cfba, true)
        del.setPadding(dp(10f), dp(6f), dp(10f), dp(6f))
        row.addView(del)
        card.addView(row)
        open.setOnClickListener { v: View? ->
            try {
                startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse(ApiClient.BASE + "profile/certificate_file.php?id=" + id)
                    )
                )
            } catch (e: Exception) {
                toast("Tidak ada aplikasi untuk membuka tautan.")
            }
        }
        del.setOnClickListener { v: View? ->
            PremiumDialog.Builder(this).setTitle("Hapus sertifikat?")
                .setMessage("Dokumen akan dihapus dari profil publik.")
                .setNegativeButton("Batal", null).setPositiveButton(
                    "Hapus"
                ) { d: DialogInterface?, w: Int ->
                    val p: MutableMap<String, String> =
                        HashMap()
                    p["action"] = "delete"
                    p["certificate_id"] = id.toString()
                    post(
                        this,
                        "profile/certificates.php",
                        p,
                        object : ApiClient.Result {
                            override fun success(j: JSONObject) {
                                toast("Sertifikat dihapus.")
                                refresh()
                            }

                            override fun fail(m: String) {
                                toast(m)
                            }
                        })
                }.show()
        }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(10f)
        list!!.addView(card, lp)
        UiMotion.bindActions(card)
    }

    private fun upload(uri: Uri, label: String) {
        uploading = true
        Thread {
            try {
                contentResolver.openInputStream(uri).use { `in` ->
                    ByteArrayOutputStream().use { out ->
                        if (`in` == null) throw Exception()
                        val chunk = ByteArray(8192)
                        var n: Int
                        var total = 0
                        while ((`in`.read(chunk).also { n = it }) != -1) {
                            total += n
                            require(total <= 5 * 1024 * 1024)
                            out.write(chunk, 0, n)
                        }
                        val bytes = out.toByteArray()
                        runOnUiThread { send(bytes, label) }
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    uploading = false
                    toast("Gagal membaca file atau ukuran melebihi 5 MB.")
                }
            }
        }.start()
    }

    private fun send(bytes: ByteArray, label: String) {
        val token = SessionStore.get(this)
        if (token.isEmpty()) {
            uploading = false
            toast("Sesi berakhir. Masuk kembali.")
            return
        }
        val req: VolleyMultipartRequest = object : VolleyMultipartRequest(
            Method.POST, ApiClient.BASE + "profile/certificates.php",
            Response.Listener<NetworkResponse> { response: NetworkResponse ->
                uploading = false
                try {
                    val json = JSONObject(String(response.data, StandardCharsets.UTF_8))
                    toast(json.optString("message", "Selesai"))
                    if (json.optBoolean("success")) refresh()
                } catch (e: Exception) {
                    toast("Respons server tidak valid.")
                }
            },
            Response.ErrorListener { error: VolleyError ->
                uploading = false
                var msg = "Unggahan gagal."
                if (error.networkResponse != null) try {
                    msg = JSONObject(
                        String(
                            error.networkResponse.data,
                            StandardCharsets.UTF_8
                        )
                    ).optString("message", msg)
                } catch (ignored: Exception) {
                }
                toast(msg)
            }) {
            override fun getParams(): Map<String, String>? {
                val p: MutableMap<String, String> = HashMap()
                p["action"] = "upload"
                p["label"] = label
                p["session_token"] = token
                return p
            }

            override val byteData: Map<String, DataPart>
                get() {
                val f: MutableMap<String, DataPart> = HashMap()
                f["certificate"] = DataPart("certificate", bytes, "application/octet-stream")
                return f
            }
        }
        req.setRetryPolicy(DefaultRetryPolicy(30000, 0, 1f))
        Volley.newRequestQueue(applicationContext).add(req)
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    }
}
