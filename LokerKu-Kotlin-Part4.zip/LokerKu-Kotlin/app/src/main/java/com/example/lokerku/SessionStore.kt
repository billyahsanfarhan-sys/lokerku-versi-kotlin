package com.example.lokerku

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** The application session token is encrypted with a non-exportable Android Keystore key.  */
internal object SessionStore {
    private const val ALIAS = "lokerku_session_v1"

    @Throws(Exception::class)
    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore")
        store.load(null)
        if (!store.containsAlias(ALIAS)) {
            val generator =
                KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
            generator.init(
                KeyGenParameterSpec.Builder(
                    ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build()
            )
            generator.generateKey()
        }
        return (store.getEntry(ALIAS, null) as KeyStore.SecretKeyEntry).secretKey
    }

    @Throws(Exception::class)
    fun save(c: Context, token: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encrypted = cipher.doFinal(token.toByteArray(StandardCharsets.UTF_8))
        val p = c.getSharedPreferences("lokerku_secure", Context.MODE_PRIVATE)
        if (!p.edit().putString("iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
                .putString("token", Base64.encodeToString(encrypted, Base64.NO_WRAP)).commit()
        ) throw Exception("save failed")
    }

    fun get(c: Context): String {
        try {
            val p = c.getSharedPreferences("lokerku_secure", Context.MODE_PRIVATE)
            val v = p.getString("token", null)
            val iv = p.getString("iv", null)
            if (v == null || iv == null) return ""
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(
                Cipher.DECRYPT_MODE,
                key(),
                GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP))
            )
            return String(cipher.doFinal(Base64.decode(v, Base64.NO_WRAP)), StandardCharsets.UTF_8)
        } catch (e: Exception) {
            return ""
        }
    }

    fun clear(c: Context) {
        c.getSharedPreferences("lokerku_secure", Context.MODE_PRIVATE).edit().clear().apply()
    }
}
