package com.example.lokerku

import android.content.res.ColorStateList
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.InsetDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.RippleDrawable
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.EditText

/** Shared, short-lived UI motion. No listener consumes a click.  */
object UiMotion {
    private fun dp(view: View, value: Float): Float {
        return value * view.resources.displayMetrics.density
    }

    fun reveal(view: View?, delay: Long) {
        if (view == null || view.visibility != View.VISIBLE) return
        view.animate().cancel()
        view.translationY = dp(view, 14f)
        // Buttons can have their alpha changed by request/loading state.
        if (view !is Button) view.alpha = 0.78f
        view.setTag(R.id.ui_motion_revealing, java.lang.Boolean.TRUE)
        val animation = view.animate().translationY(0f)
        if (view !is Button) animation.alpha(1f)
        animation.setStartDelay(delay).setDuration(560)
            .setInterpolator(DecelerateInterpolator(1.4f))
            .withEndAction { view.setTag(R.id.ui_motion_revealing, null) }.start()
    }

    fun revealChildren(group: ViewGroup, start: Long, step: Long, max: Int) {
        var n = 0
        var i = 0
        while (i < group.childCount && n < max) {
            val child = group.getChildAt(i)
            if (child.visibility != View.VISIBLE) {
                i++
                continue
            }
            reveal(child, start + n * step)
            n++
            i++
        }
    }

    fun bindPress(view: View) {
        if (java.lang.Boolean.TRUE == view.getTag(R.id.ui_motion_bound)) return
        view.setTag(R.id.ui_motion_bound, java.lang.Boolean.TRUE)
        view.setOnTouchListener { v: View, event: MotionEvent ->
            if (!v.isEnabled || java.lang.Boolean.TRUE == v.getTag(R.id.ui_motion_revealing)) return@setOnTouchListener false
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(.97f).scaleY(.97f)
                    .setStartDelay(0)
                    .setDuration(140)
                    .setInterpolator(DecelerateInterpolator()).start()

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate()
                    .scaleX(1f).scaleY(1f).setStartDelay(0)
                    .setDuration(240)
                    .setInterpolator(DecelerateInterpolator()).start()

                else -> {}
            }
            false
        }
    }

    fun styleButtons(view: View) {
        if (view is Button && java.lang.Boolean.TRUE != view.getTag(R.id.ui_motion_bound)) {
            val button = view
            button.isAllCaps = false
            button.minHeight = dp(button, 48f).toInt()
            val bg = button.background
            if (bg != null) {
                roundButtonSurface(bg, dp(button, 16f))
                button.backgroundTintList = null
                button.background = RippleDrawable(
                    ColorStateList.valueOf(0x330000FF), bg.mutate(), null
                )
            }
            bindPress(button)
        }
        if (view is ViewGroup) {
            val group = view
            for (i in 0 until group.childCount) styleButtons(group.getChildAt(i))
        }
    }

    // Preserve each button's color and semantics while unifying its corner radius.
    private fun roundButtonSurface(drawable: Drawable, radius: Float) {
        if (drawable is GradientDrawable) {
            drawable.cornerRadius = radius
        } else if (drawable is InsetDrawable) {
            val child = drawable.drawable
            if (child != null) roundButtonSurface(child, radius)
        } else if (drawable is LayerDrawable) {
            val layers = drawable
            for (i in 0 until layers.numberOfLayers) {
                val child = layers.getDrawable(i)
                if (child != null) roundButtonSurface(child, radius)
            }
        }
    }

    fun bindActions(view: View) {
        if (view.isClickable && view !is EditText && java.lang.Boolean.TRUE != view.getTag(
                R.id.ui_motion_skip_press
            )
        ) {
            bindPress(view)
        }
        if (view is ViewGroup) {
            val group = view
            for (i in 0 until group.childCount) bindActions(group.getChildAt(i))
        }
    }

    fun finishReveals(view: View?) {
        if (view == null) return
        if (java.lang.Boolean.TRUE == view.getTag(R.id.ui_motion_revealing)) {
            view.animate().cancel()
            view.translationY = 0f
            // Preserve a disabled button's loading opacity.
            if (view !is Button) view.alpha = 1f
            view.setTag(R.id.ui_motion_revealing, null)
        }
        if (view is ViewGroup) {
            val group = view
            for (i in 0 until group.childCount) finishReveals(group.getChildAt(i))
        }
    }
}
