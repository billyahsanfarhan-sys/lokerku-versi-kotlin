package com.example.lokerku

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import java.util.Random
import kotlin.math.max
import kotlin.math.sin

class SplashBackgroundView : View {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val random = Random()

    private val px = FloatArray(70)
    private val py = FloatArray(70)
    private val speed = FloatArray(70)
    private val radius = FloatArray(70)

    private var time = 0f
    private var viewWidth = 0
    private var viewHeight = 0

    constructor(context: Context?) : super(context) {
        init()
    }

    constructor(context: Context?, attrs: AttributeSet?) : super(context, attrs) {
        init()
    }

    constructor(
        context: Context?, attrs: AttributeSet?,
        defStyleAttr: Int
    ) : super(context, attrs, defStyleAttr) {
        init()
    }

    private fun init() {
        setLayerType(LAYER_TYPE_SOFTWARE, null)

        for (i in px.indices) {
            px[i] = random.nextFloat()
            py[i] = random.nextFloat()
            speed[i] = 0.0003f + random.nextFloat() * 0.0008f
            radius[i] = 1f + random.nextFloat() * 2.2f
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        viewWidth = w
        viewHeight = h
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        if (viewWidth <= 0 || viewHeight <= 0) {
            return
        }

        canvas.drawColor(Color.rgb(3, 8, 20))

        drawAmbientGlow(canvas)
        drawPortal(canvas)
        drawRoad(canvas)
        drawParticles(canvas)

        time += 0.018f

        postInvalidateDelayed(30)
    }

    private fun drawAmbientGlow(canvas: Canvas) {
        paint.setShader(
            RadialGradient(
                viewWidth * 0.53f,
                viewHeight * 0.48f,
                viewWidth * 0.75f,
                intArrayOf(
                    Color.argb(65, 0, 90, 255),
                    Color.argb(28, 0, 45, 130),
                    Color.TRANSPARENT
                ),
                null,
                Shader.TileMode.CLAMP
            )
        )

        canvas.drawRect(0f, 0f, viewWidth.toFloat(), viewHeight.toFloat(), paint)
        paint.setShader(null)

        val glowX = viewWidth * (0.5f + 0.08f *
                sin((time * 0.7f).toDouble()).toFloat())

        paint.setShader(
            RadialGradient(
                glowX,
                viewHeight * 0.65f,
                viewWidth * 0.45f,
                intArrayOf(
                    Color.argb(70, 0, 119, 255),
                    Color.argb(20, 0, 67, 170),
                    Color.TRANSPARENT
                ),
                null,
                Shader.TileMode.CLAMP
            )
        )

        canvas.drawRect(0f, 0f, viewWidth.toFloat(), viewHeight.toFloat(), paint)
        paint.setShader(null)
    }

    private fun drawPortal(canvas: Canvas) {
        val centerX = viewWidth * 0.72f
        val top = viewHeight * 0.48f
        val bottom = viewHeight * 0.76f
        val portalWidth = viewWidth * 0.28f

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f
        paint.color = Color.argb(45, 35, 145, 255)

        val outer = Path()
        outer.moveTo(centerX - portalWidth, bottom)
        outer.lineTo(centerX - portalWidth * 0.72f, top + 20)
        outer.quadTo(
            centerX, top - 20,
            centerX + portalWidth * 0.35f, top + 25
        )
        outer.lineTo(centerX + portalWidth * 0.7f, bottom)

        paint.setShadowLayer(
            22f, 0f, 0f,
            Color.rgb(0, 91, 255)
        )
        canvas.drawPath(outer, paint)
        paint.clearShadowLayer()

        paint.style = Paint.Style.FILL

        paint.setShader(
            RadialGradient(
                centerX,
                (top + bottom) / 2f,
                portalWidth * 1.5f,
                intArrayOf(
                    Color.argb(48, 0, 132, 255),
                    Color.TRANSPARENT
                ),
                null,
                Shader.TileMode.CLAMP
            )
        )

        canvas.drawRect(
            centerX - portalWidth * 1.5f,
            top,
            centerX + portalWidth * 1.5f,
            bottom,
            paint
        )

        paint.setShader(null)
    }

    private fun drawRoad(canvas: Canvas) {
        val road = Path()

        road.moveTo(-viewWidth * 0.1f, viewHeight * 0.84f)

        road.cubicTo(
            viewWidth * 0.15f, viewHeight * 0.79f,
            viewWidth * 0.95f, viewHeight * 0.80f,
            viewWidth * 0.70f, viewHeight * 0.69f
        )

        road.cubicTo(
            viewWidth * 0.45f, viewHeight * 0.60f,
            viewWidth * 0.35f, viewHeight * 0.56f,
            viewWidth * 0.82f, viewHeight * 0.49f
        )

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2.2f
        paint.color = Color.argb(180, 25, 125, 255)
        paint.setShadowLayer(
            18f, 0f, 0f,
            Color.rgb(0, 103, 255)
        )

        canvas.drawPath(road, paint)

        paint.clearShadowLayer()
        paint.style = Paint.Style.FILL
    }

    private fun drawParticles(canvas: Canvas) {
        for (i in px.indices) {
            py[i] -= speed[i]

            if (py[i] < 0f) {
                py[i] = 1f
                px[i] = random.nextFloat()
            }

            val x = px[i] * viewWidth
            val y = py[i] * viewHeight

            val pulse = sin((time + i).toDouble()).toFloat() * 0.5f
            val r = max(0.5, (radius[i] + pulse).toDouble()).toFloat()

            val alpha = 75 + ((sin((time * 1.4f + i).toDouble()) + 1f) * 65f
                    ).toInt()

            paint.color = Color.argb(
                alpha, 60, 160, 255
            )

            paint.style = Paint.Style.FILL
            paint.setShadowLayer(
                8f, 0f, 0f,
                Color.rgb(0, 100, 255)
            )

            canvas.drawCircle(x, y, r, paint)

            paint.clearShadowLayer()
        }
    }
}