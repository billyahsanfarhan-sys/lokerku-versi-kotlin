package com.example.lokerku

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import java.util.Random
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

class NetworkView : View {
    private val particlePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private val particles: MutableList<Particle> = ArrayList()
    private val random = Random()

    private var width = 0
    private var height = 0

    private val connectionDistance = 210f

    constructor(context: Context?) : super(context) {
        init()
    }

    constructor(context: Context?, attrs: AttributeSet?) : super(context, attrs) {
        init()
    }

    constructor(context: Context?, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {
        init()
    }

    private fun init() {
        particlePaint.style = Paint.Style.FILL

        linePaint.style = Paint.Style.STROKE
        linePaint.strokeWidth = 1.2f

        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        width = w
        height = h

        particles.clear()

        val count = max(28.0, min(55.0, (width / 18).toDouble())).toInt()

        for (i in 0 until count) {
            val particle = Particle()

            particle.x = random.nextFloat() * width
            particle.y = random.nextFloat() * height

            particle.speedX = (random.nextFloat() - 0.5f) * 0.65f
            particle.speedY = (random.nextFloat() - 0.5f) * 0.65f

            particle.radius = 1.5f + random.nextFloat() * 2.8f

            particle.alpha = 80 + random.nextInt(130)

            particles.add(particle)
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        updateParticles()

        drawConnections(canvas)
        drawParticles(canvas)

        postInvalidateDelayed(16)
    }

    private fun updateParticles() {
        for (particle in particles) {
            particle.x += particle.speedX
            particle.y += particle.speedY

            if (particle.x < -20) {
                particle.x = (width + 20).toFloat()
            }

            if (particle.x > width + 20) {
                particle.x = -20f
            }

            if (particle.y < -20) {
                particle.y = (height + 20).toFloat()
            }

            if (particle.y > height + 20) {
                particle.y = -20f
            }

            particle.pulse += 0.035f
        }
    }

    private fun drawConnections(canvas: Canvas) {
        for (i in particles.indices) {
            val first = particles[i]

            for (j in i + 1 until particles.size) {
                val second = particles[j]

                val dx = first.x - second.x
                val dy = first.y - second.y

                val distance = sqrt(
                    (dx * dx + dy * dy).toDouble()
                ).toFloat()

                if (distance < connectionDistance) {
                    val alpha =
                        (1f - distance / connectionDistance) * 85f

                    linePaint.color = Color.argb(
                        alpha.toInt(),
                        65,
                        150,
                        230
                    )

                    canvas.drawLine(
                        first.x,
                        first.y,
                        second.x,
                        second.y,
                        linePaint
                    )
                }
            }
        }
    }

    private fun drawParticles(canvas: Canvas) {
        for (particle in particles) {
            val pulse =
                sin(particle.pulse.toDouble()).toFloat() * 0.8f

            val radius = particle.radius + pulse

            particlePaint.color = Color.argb(
                particle.alpha,
                96,
                165,
                250
            )

            particlePaint.setShadowLayer(
                10f,
                0f,
                0f,
                Color.argb(
                    particle.alpha,
                    37,
                    99,
                    235
                )
            )

            canvas.drawCircle(
                particle.x,
                particle.y,
                max(0.8, radius.toDouble()).toFloat(),
                particlePaint
            )
        }

        particlePaint.clearShadowLayer()
    }

    private class Particle {
        var x: Float = 0f
        var y: Float = 0f

        var speedX: Float = 0f
        var speedY: Float = 0f

        var radius: Float = 0f
        var alpha: Int = 0

        var pulse: Float = 0f
    }
}