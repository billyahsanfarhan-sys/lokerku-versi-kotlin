package com.example.lokerku

import android.R
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.lokerku.AppFont.regular
import com.example.lokerku.AppFont.semibold
import com.example.lokerku.FontEnforcer.apply
import java.util.Locale

class InterviewTipsActivity : AppCompatActivity() {
    private val BLUE = Color.rgb(0, 82, 255)
    private val DARK = Color.rgb(21, 35, 83)
    private val BG = Color.rgb(246, 248, 255)
    private val TEXT = Color.rgb(28, 39, 66)
    private val MUTED = Color.rgb(105, 117, 148)
    private val WHITE = Color.WHITE
    private var list: LinearLayout? = null
    private var activeFilter = "Semua"
    private val tips: MutableList<Tip> = ArrayList()

    private class Tip(
        var category: String,
        var title: String,
        var description: String,
        var time: String,
        var detail: String
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        if (Build.VERSION.SDK_INT >= 23) window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        seed()
        build()
    }

    private fun seed() {
        tips.add(
            Tip(
                "Persiapan",
                "Riset perusahaan sebelum wawancara",
                "Kenali produk, budaya kerja, dan kebutuhan posisi yang dilamar.",
                "4 menit baca",
                "Sebelum wawancara, buka situs resmi perusahaan dan pahami produk atau layanannya. Baca deskripsi pekerjaan lalu cocokkan kebutuhan posisi dengan pengalamanmu. Siapkan dua atau tiga pertanyaan yang relevan untuk perekrut. Hindari mengaku mengetahui hal yang belum kamu pahami."
            )
        )
        tips.add(
            Tip(
                "Pertanyaan",
                "Cara memperkenalkan diri dengan menarik",
                "Buat jawaban singkat yang menyoroti pengalaman dan tujuanmu.",
                "3 menit baca",
                "Gunakan struktur sederhana: siapa kamu, pengalaman atau kemampuan yang relevan, lalu alasan tertarik pada posisi tersebut. Usahakan sekitar 45–90 detik. Hindari mengulang seluruh isi CV; pilih informasi yang paling sesuai dengan pekerjaan."
            )
        )
        tips.add(
            Tip(
                "Pertanyaan",
                "Menjawab pertanyaan kelebihan dan kekurangan",
                "Sampaikan dengan jujur dan sertakan contoh nyata.",
                "4 menit baca",
                "Pilih kelebihan yang berhubungan dengan pekerjaan dan dukung dengan contoh. Untuk kekurangan, sebutkan hal nyata yang sedang kamu perbaiki beserta langkahnya. Hindari jawaban klise tanpa contoh atau mengklaim tidak memiliki kekurangan."
            )
        )
        tips.add(
            Tip(
                "Saat wawancara",
                "Gunakan metode STAR untuk cerita pengalaman",
                "Susun jawaban menjadi Situasi, Tugas, Aksi, dan Hasil.",
                "5 menit baca",
                "Situasi: jelaskan konteksnya. Tugas: apa tanggung jawabmu. Aksi: langkah spesifik yang kamu ambil. Hasil: apa yang berubah atau kamu pelajari. Metode ini membantu jawaban tetap terstruktur, terutama untuk pertanyaan tentang kerja tim dan pemecahan masalah."
            )
        )
        tips.add(
            Tip(
                "Setelah",
                "Bahasa tubuh dan komunikasi profesional",
                "Tunjukkan perhatian, dengarkan sampai selesai, dan jawab dengan jelas.",
                "3 menit baca",
                "Datang atau masuk ke ruang virtual tepat waktu. Dengarkan pertanyaan sampai selesai, berbicara dengan tempo wajar, dan minta klarifikasi jika pertanyaan belum jelas. Tetap sopan kepada semua orang yang ditemui, bukan hanya pewawancara."
            )
        )
        tips.add(
            Tip(
                "Setelah",
                "Apa yang dilakukan setelah wawancara",
                "Kirim ucapan terima kasih singkat dan catat hal yang bisa diperbaiki.",
                "2 menit baca",
                "Setelah wawancara, kamu dapat mengirim pesan terima kasih yang ringkas jika kontak perekrut tersedia. Ulangi ketertarikan pada posisi dan apresiasi waktu mereka. Catat pertanyaan yang sulit agar kamu bisa berlatih untuk kesempatan berikutnya."
            )
        )
    }

    private fun build() {
        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.setBackgroundColor(BG)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20f), dp(14f), dp(20f), dp(28f))
        scroll.addView(root)
        setContentView(scroll)
        apply(root, this)
        val back = text("‹   Kembali ke Beranda", 14, BLUE, true)
        back.setPadding(0, dp(8f), 0, dp(18f))
        back.setOnClickListener { v: View? -> finish() }
        back.minHeight = dp(48f)
        root.addView(back)
        val hero = LinearLayout(this)
        hero.orientation = LinearLayout.VERTICAL
        hero.setPadding(dp(20f), dp(22f), dp(20f), dp(22f))
        hero.background = gradient(BLUE, Color.rgb(94, 113, 255), 24)
        hero.addView(text("CAREER PLAYBOOK  ✦", 11, Color.WHITE, true))
        val title = text("Tampil percaya diri saat wawancara", 24, WHITE, true)
        val tp = LinearLayout.LayoutParams(-1, -2)
        tp.topMargin = dp(10f)
        hero.addView(title, tp)
        val desc = text(
            "Bekali diri dengan strategi praktis, contoh jawaban, dan langkah yang bisa kamu lakukan sebelum sampai setelah wawancara.",
            13,
            Color.rgb(239, 243, 255),
            false
        )
        desc.setLineSpacing(dp(3f).toFloat(), 1f)
        val dp1 = LinearLayout.LayoutParams(-1, -2)
        dp1.topMargin = dp(8f)
        hero.addView(desc, dp1)
        root.addView(hero)
        val highlights = LinearLayout(this)
        highlights.orientation = LinearLayout.HORIZONTAL
        highlights.gravity = Gravity.CENTER_VERTICAL
        highlights.setPadding(dp(10f), dp(15f), dp(10f), dp(15f))
        highlights.background = rounded(WHITE, 18)
        val stats = arrayOf(
            arrayOf("06", "Panduan"),
            arrayOf("15 menit", "Belajar"),
            arrayOf("04", "Tahapan")
        )
        for (i in stats.indices) {
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER
            col.setPadding(dp(4f), dp(3f), dp(4f), dp(3f))
            val number = text(stats[i][0], 16, BLUE, true)
            number.gravity = Gravity.CENTER
            number.isSingleLine = false
            col.addView(number, LinearLayout.LayoutParams(-1, -2))
            val st = text(stats[i][1], 10, MUTED, false)
            st.gravity = Gravity.CENTER
            st.isSingleLine = false
            val stp = LinearLayout.LayoutParams(-1, -2)
            stp.topMargin = dp(5f)
            col.addView(st, stp)
            col.minimumHeight = dp(64f)
            highlights.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            if (i < stats.size - 1) {
                val divider = View(this)
                divider.setBackgroundColor(Color.rgb(231, 236, 248))
                highlights.addView(divider, LinearLayout.LayoutParams(dp(1f), dp(34f)))
            }
        }
        val hp = LinearLayout.LayoutParams(-1, -2)
        hp.topMargin = dp(15f)
        root.addView(highlights, hp)
        val heading = text("Pilih topik yang kamu butuhkan", 18, TEXT, true)
        val hdp = LinearLayout.LayoutParams(-1, -2)
        hdp.topMargin = dp(24f)
        root.addView(heading, hdp)
        val subtitle = text("Panduan singkat untuk setiap tahap wawancara.", 12, MUTED, false)
        val sdp = LinearLayout.LayoutParams(-1, -2)
        sdp.topMargin = dp(5f)
        root.addView(subtitle, sdp)
        val hsv = HorizontalScrollView(this)
        hsv.isHorizontalScrollBarEnabled = false
        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        val filters = arrayOf("Semua", "Persiapan", "Pertanyaan", "Saat wawancara", "Setelah")
        for (f in filters) {
            val chip = text(f, 12, if (f == activeFilter) WHITE else TEXT, true)
            chip.gravity = Gravity.CENTER
            chip.setPadding(dp(15f), dp(10f), dp(15f), dp(10f))
            chip.background = rounded(if (f == activeFilter) BLUE else WHITE, 30)
            val cp = LinearLayout.LayoutParams(-2, -2)
            chip.minHeight = dp(48f)
            cp.rightMargin = dp(8f)
            chips.addView(chip, cp)
            chip.setOnClickListener { v: View? ->
                activeFilter = f
                updateChips(chips, filters)
                populate()
                showCategoryOverview(f)
            }
        }
        hsv.addView(chips)
        val hsvp = LinearLayout.LayoutParams(-1, -2)
        hsvp.topMargin = dp(15f)
        root.addView(hsv, hsvp)
        list = LinearLayout(this)
        list!!.orientation = LinearLayout.VERTICAL
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(8f)
        root.addView(list, lp)
        populate()
        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.VERTICAL
        bottom.setPadding(dp(16f), dp(17f), dp(16f), dp(17f))
        bottom.background = gradient(Color.rgb(232, 240, 255), Color.rgb(246, 248, 255), 18)
        val bt = text("Latihan sedikit, lebih siap saat hari H", 15, DARK, true)
        bottom.addView(bt)
        val bd = text(
            "Pilih satu topik, baca dengan tenang, lalu coba jelaskan jawabanmu dengan kata-katamu sendiri.",
            12,
            MUTED,
            false
        )
        bd.setLineSpacing(dp(3f).toFloat(), 1f)
        val bdp = LinearLayout.LayoutParams(-1, -2)
        bdp.topMargin = dp(6f)
        bottom.addView(bd, bdp)
        val botp = LinearLayout.LayoutParams(-1, -2)
        botp.topMargin = dp(18f)
        root.addView(bottom, botp)
        apply(root, this)
        UiMotion.styleButtons(scroll)
        UiMotion.bindActions(scroll)
        UiMotion.bindPress(back)
        UiMotion.revealChildren(root, 50, 70, 9)
    }

    override fun onPause() {
        UiMotion.finishReveals(window.decorView)
        super.onPause()
    }

    private fun updateChips(chips: LinearLayout, filters: Array<String>) {
        for (i in 0 until chips.childCount) {
            val c = chips.getChildAt(i) as TextView
            val f = filters[i]
            c.background = rounded(if (f == activeFilter) BLUE else WHITE, 30)
            c.setTextColor(if (f == activeFilter) WHITE else TEXT)
        }
    }

    private fun populate() {
        list!!.removeAllViews()
        var count = 0
        for (tip in tips) {
            if (activeFilter != "Semua" && !tip.category.equals(
                    activeFilter,
                    ignoreCase = true
                )
            ) continue
            count++
            val card = LinearLayout(this)
            card.orientation = LinearLayout.HORIZONTAL
            card.gravity = Gravity.CENTER_VERTICAL
            card.setPadding(dp(13f), dp(14f), dp(13f), dp(14f))
            card.background = rounded(WHITE, 18)
            card.elevation = dp(2f).toFloat()
            val icon = text(iconFor(tip.category), 22, BLUE, true)
            icon.gravity = Gravity.CENTER
            icon.background = rounded(tintFor(tip.category), 14)
            card.addView(icon, LinearLayout.LayoutParams(dp(52f), dp(58f)))
            val words = LinearLayout(this)
            words.orientation = LinearLayout.VERTICAL
            words.setPadding(dp(12f), 0, dp(6f), 0)
            val category = text(tip.category.uppercase(Locale.getDefault()), 9, BLUE, true)
            words.addView(category)
            val title = text(tip.title, 14, TEXT, true)
            title.maxLines = 2
            val t = LinearLayout.LayoutParams(-1, -2)
            t.topMargin = dp(4f)
            words.addView(title, t)
            val description = text(tip.description, 11, MUTED, false)
            description.maxLines = 2
            description.setLineSpacing(dp(2f).toFloat(), 1f)
            val d = LinearLayout.LayoutParams(-1, -2)
            d.topMargin = dp(5f)
            words.addView(description, d)
            val time = text("◷  " + tip.time + "     Baca panduan  ›", 10, BLUE, true)
            val tm = LinearLayout.LayoutParams(-1, -2)
            tm.topMargin = dp(8f)
            words.addView(time, tm)
            card.addView(words, LinearLayout.LayoutParams(0, -2, 1f))
            val cardp = LinearLayout.LayoutParams(-1, -2)
            cardp.topMargin = dp(10f)
            list!!.addView(card, cardp)
            card.setOnClickListener { v: View? -> showDetail(tip) }
        }
        if (count == 0) list!!.addView(
            text(
                "Belum ada panduan untuk kategori ini.",
                13,
                MUTED,
                false
            )
        )
    }

    private fun showCategoryOverview(category: String) {
        val dialog = Dialog(this)
        val sheet = dialogSheet()
        addSheetHeader(
            dialog, sheet, if (category == "Semua") "Semua panduan" else "Panduan: $category",
            if (category == "Semua") "Pilih materi yang ingin kamu pelajari." else categoryDescription(
                category
            )
        )
        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(18f), dp(4f), dp(18f), dp(10f))
        var count = 0
        for (tip in tips) {
            if (category != "Semua" && !tip.category.equals(category, ignoreCase = true)) continue
            count++
            val selected = tip
            val item = LinearLayout(this)
            item.orientation = LinearLayout.HORIZONTAL
            item.gravity = Gravity.CENTER_VERTICAL
            item.setPadding(dp(12f), dp(12f), dp(12f), dp(12f))
            item.background = rounded(tintFor(tip.category), 16)
            val num = text(String.format(Locale.getDefault(), "%02d", count), 13, BLUE, true)
            num.gravity = Gravity.CENTER
            num.background = rounded(WHITE, 11)
            item.addView(num, LinearLayout.LayoutParams(dp(38f), dp(38f)))
            val copy = LinearLayout(this)
            copy.orientation = LinearLayout.VERTICAL
            copy.setPadding(dp(11f), 0, dp(5f), 0)
            copy.addView(text(tip.title, 13, TEXT, true))
            val meta = text(tip.time + "  ·  Buka panduan", 11, MUTED, false)
            val mp = LinearLayout.LayoutParams(-1, -2)
            mp.topMargin = dp(4f)
            copy.addView(meta, mp)
            item.addView(copy, LinearLayout.LayoutParams(0, -2, 1f))
            val arrow = text("›", 24, BLUE, true)
            item.addView(arrow)
            val ip = LinearLayout.LayoutParams(-1, -2)
            ip.topMargin = dp(8f)
            content.addView(item, ip)
            item.setOnClickListener { v: View? ->
                dialog.dismiss()
                showDetail(selected)
            }
        }
        if (count == 0) content.addView(
            text(
                "Belum ada panduan pada kategori ini.",
                13,
                MUTED,
                false
            )
        )
        val scroller = ScrollView(this)
        scroller.isFillViewport = false
        scroller.addView(content)
        sheet.addView(scroller, LinearLayout.LayoutParams(-1, 0, 1f))
        val done = primaryButton("Mulai membaca")
        val dp1 = LinearLayout.LayoutParams(-1, dp(50f))
        dp1.setMargins(dp(18f), dp(8f), dp(18f), dp(18f))
        sheet.addView(done, dp1)
        done.setOnClickListener { v: View? ->
            dialog.dismiss()
            for (tip in tips) {
                if (category == "Semua" || tip.category.equals(category, ignoreCase = true)) {
                    showDetail(tip)
                    break
                }
            }
        }
        showDialog(dialog, sheet)
    }

    private fun showDetail(tip: Tip) {
        val dialog = Dialog(this)
        val sheet = dialogSheet()
        addSheetHeader(
            dialog,
            sheet,
            tip.category,
            "Panduan praktis untuk membantu kamu lebih siap."
        )
        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(20f), dp(4f), dp(20f), dp(12f))
        val title = text(tip.title, 22, DARK, true)
        title.setLineSpacing(dp(2f).toFloat(), 1f)
        content.addView(title)
        val meta = LinearLayout(this)
        meta.orientation = LinearLayout.HORIZONTAL
        meta.gravity = Gravity.CENTER_VERTICAL
        meta.setPadding(dp(10f), dp(7f), dp(10f), dp(7f))
        meta.background = rounded(Color.rgb(239, 244, 255), 30)
        val metap = LinearLayout.LayoutParams(-2, -2)
        metap.topMargin = dp(11f)
        content.addView(meta, metap)
        meta.addView(text("◷  " + tip.time, 11, BLUE, true))
        val advice = LinearLayout(this)
        advice.orientation = LinearLayout.VERTICAL
        advice.setPadding(dp(15f), dp(15f), dp(15f), dp(15f))
        advice.background = rounded(Color.rgb(246, 248, 255), 16)
        val adviceTitle = text("Yang perlu kamu lakukan", 13, DARK, true)
        advice.addView(adviceTitle)
        val body = text(tip.detail, 14, TEXT, false)
        body.setLineSpacing(dp(6f).toFloat(), 1.08f)
        val bp = LinearLayout.LayoutParams(-1, -2)
        bp.topMargin = dp(9f)
        advice.addView(body, bp)
        val ap = LinearLayout.LayoutParams(-1, -2)
        ap.topMargin = dp(17f)
        content.addView(advice, ap)
        val note = text(
            "Tips LokerKu  ·  Pelajari, lalu sesuaikan dengan pengalamanmu sendiri.",
            11,
            MUTED,
            false
        )
        note.setLineSpacing(dp(3f).toFloat(), 1f)
        val np = LinearLayout.LayoutParams(-1, -2)
        np.topMargin = dp(13f)
        content.addView(note, np)
        val scroller = ScrollView(this)
        scroller.isFillViewport = false
        scroller.addView(content)
        sheet.addView(scroller, LinearLayout.LayoutParams(-1, 0, 1f))
        val actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        actions.setPadding(dp(18f), dp(8f), dp(18f), dp(18f))
        val close = secondaryButton("Tutup")
        val next = primaryButton("Topik berikutnya  ›")
        val cpar = LinearLayout.LayoutParams(0, dp(48f), 0.85f)
        cpar.rightMargin = dp(9f)
        actions.addView(close, cpar)
        actions.addView(next, LinearLayout.LayoutParams(0, dp(48f), 1.3f))
        sheet.addView(actions)
        close.setOnClickListener { v: View? -> dialog.dismiss() }
        next.setOnClickListener { v: View? ->
            dialog.dismiss()
            val i = tips.indexOf(tip)
            showDetail(tips[(i + 1) % tips.size])
        }
        showDialog(dialog, sheet)
    }

    private fun dialogSheet(): LinearLayout {
        val sheet = LinearLayout(this)
        sheet.orientation = LinearLayout.VERTICAL
        sheet.background = rounded(WHITE, 26)
        sheet.clipToOutline = true
        return sheet
    }

    private fun addSheetHeader(
        dialog: Dialog,
        sheet: LinearLayout,
        titleText: String,
        description: String
    ) {
        val header = LinearLayout(this)
        header.orientation = LinearLayout.VERTICAL
        header.setPadding(dp(20f), dp(20f), dp(20f), dp(18f))
        header.background = gradient(BLUE, Color.rgb(92, 119, 255), 24)
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val eyebrow = text("LOKERKU  ✦  CAREER GUIDE", 10, Color.rgb(230, 238, 255), true)
        top.addView(eyebrow, LinearLayout.LayoutParams(0, -2, 1f))
        val close = text("×", 27, WHITE, true)
        close.gravity = Gravity.CENTER
        top.addView(close, LinearLayout.LayoutParams(dp(48f), dp(48f)))
        close.contentDescription = "Tutup"
        header.addView(top)
        close.setOnClickListener { v: View? -> dialog.dismiss() }
        val title = text(titleText, 22, WHITE, true)
        title.setLineSpacing(dp(2f).toFloat(), 1f)
        val tp = LinearLayout.LayoutParams(-1, -2)
        tp.topMargin = dp(11f)
        header.addView(title, tp)
        val desc = text(description, 12, Color.rgb(239, 243, 255), false)
        desc.setLineSpacing(dp(3f).toFloat(), 1f)
        val dp1 = LinearLayout.LayoutParams(-1, -2)
        dp1.topMargin = dp(6f)
        header.addView(desc, dp1)
        sheet.addView(header)
    }

    private fun showDialog(dialog: Dialog, sheet: LinearLayout) {
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(sheet)
        val window = dialog.window
        if (window != null) {
            window.setBackgroundDrawableResource(R.color.transparent)
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            val params = window.attributes
            params.width = WindowManager.LayoutParams.MATCH_PARENT
            params.height = (resources.displayMetrics.heightPixels * 0.82f).toInt()
            params.gravity = Gravity.BOTTOM
            params.dimAmount = 0.38f
            window.attributes = params
        }
        dialog.show()
        if (window != null) {
            window.setBackgroundDrawableResource(R.color.transparent)
            window.setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                (resources.displayMetrics.heightPixels * 0.82f).toInt()
            )
            window.setGravity(Gravity.BOTTOM)
        }
        apply(sheet, this)
        UiMotion.styleButtons(sheet)
        UiMotion.bindActions(sheet)
        UiMotion.revealChildren(sheet, 40, 70, 5)
    }

    private fun primaryButton(label: String): Button {
        val b = Button(this)
        b.text = label
        b.setTextColor(WHITE)
        b.textSize = 13f
        b.isAllCaps = false
        b.typeface = semibold(this)
        b.background = rounded(BLUE, 16)
        b.elevation = dp(2f).toFloat()
        return b
    }

    private fun secondaryButton(label: String): Button {
        val b = Button(this)
        b.text = label
        b.setTextColor(BLUE)
        b.textSize = 13f
        b.isAllCaps = false
        b.typeface = semibold(this)
        val bg = rounded(Color.rgb(239, 244, 255), 16)
        bg.setStroke(dp(1f), Color.rgb(220, 229, 255))
        b.background = bg
        return b
    }

    private fun categoryDescription(category: String): String {
        if (category == "Persiapan") return "Hal-hal yang bisa kamu siapkan sebelum hari wawancara."
        if (category == "Pertanyaan") return "Latihan menjawab pertanyaan yang sering muncul dari perekrut."
        if (category == "Saat wawancara") return "Cara menyampaikan pengalaman dan berkomunikasi dengan percaya diri."
        if (category == "Setelah") return "Langkah profesional setelah sesi wawancara selesai."
        return "Pilih panduan yang sesuai dengan kebutuhanmu."
    }

    private fun iconFor(c: String): String {
        if (c == "Persiapan") return "◎"
        if (c == "Pertanyaan") return "❝"
        if (c == "Saat wawancara") return "✦"
        return "✓"
    }

    private fun tintFor(c: String): Int {
        if (c == "Persiapan") return Color.rgb(228, 235, 255)
        if (c == "Pertanyaan") return Color.rgb(233, 233, 255)
        if (c == "Saat wawancara") return Color.rgb(225, 234, 255)
        return Color.rgb(235, 239, 255)
    }

    private fun text(s: String, size: Int, color: Int, bold: Boolean): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size.toFloat()
        t.setTextColor(color)
        t.typeface =
            if (bold) semibold(this) else regular(this)
        return t
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        if (color == WHITE) d.setStroke(dp(1f), Color.rgb(221, 224, 255))
        d.cornerRadius = dp(radius.toFloat()).toFloat()
        return d
    }

    private fun gradient(c1: Int, c2: Int, radius: Int): GradientDrawable {
        val d = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2))
        d.cornerRadius = dp(radius.toFloat()).toFloat()
        return d
    }

    private fun dp(v: Float): Int {
        return (v * resources.displayMetrics.density + 0.5f).toInt()
    }
}
