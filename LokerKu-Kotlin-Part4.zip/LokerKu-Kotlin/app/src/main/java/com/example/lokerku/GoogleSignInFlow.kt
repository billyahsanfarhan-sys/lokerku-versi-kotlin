package com.example.lokerku

import android.app.Activity
import android.content.Intent
import android.os.CancellationSignal
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.credentials.CredentialManager
import androidx.credentials.CredentialManagerCallback
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetCredentialResponse
import androidx.credentials.exceptions.GetCredentialException
import com.android.volley.DefaultRetryPolicy
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.lokerku.FavoritesStore.migrate
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import org.json.JSONObject
import java.nio.charset.StandardCharsets

internal object GoogleSignInFlow {
    private const val BASE = "https://ahannaja.cu.ma/lokerku_api/"
    private const val CLIENT =
        "579438749291-sdlee32ci5m8e1rjf0506o3b2gj2asus.apps.googleusercontent.com"

    fun fresh(activity: Activity, callback: FreshCredential) {
        val req = StringRequest(
            Request.Method.POST, BASE + "auth/google_nonce.php",
            Response.Listener<String> { response: String? ->
                try {
                    val json = JSONObject(response)
                    val nonce = json.optString("nonce", "")
                    if (!json.optBoolean("success") || !nonce.matches("[a-f0-9]{64}".toRegex())) {
                        callback.fail("Server belum siap untuk Google.")
                        return@Listener
                    }
                    val option: GetSignInWithGoogleOption = GetSignInWithGoogleOption.Builder(CLIENT).setNonce(nonce).build()
                    val request: GetCredentialRequest =
                        GetCredentialRequest.Builder().addCredentialOption(option).build()
                    CredentialManager.create(activity).getCredentialAsync(activity,
                        request,
                        CancellationSignal(),
                        ContextCompat.getMainExecutor(activity),
                        object :
                            CredentialManagerCallback<GetCredentialResponse, GetCredentialException> {
                            override fun onResult(result: GetCredentialResponse) {
                                try {
                                    val credential = result.credential
                                    if (credential !is CustomCredential || GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL != credential.type) {
                                        callback.fail("Kredensial Google tidak dikenali.")
                                        return
                                    }
                                    val token =
                                        GoogleIdTokenCredential.createFrom(credential.data).idToken
                                    callback.ready(token, nonce)
                                } catch (e: Exception) {
                                    callback.fail("Tidak dapat membaca akun Google.")
                                }
                            }

                            override fun onError(e: GetCredentialException) {
                                callback.fail("Google belum dapat dibuka (" + e.javaClass.simpleName + "). Periksa akun Google dan Play Services.")
                            }
                        })
                } catch (e: Exception) {
                    callback.fail("Respons server tidak valid.")
                }
            }
        ) { error: VolleyError? -> callback.fail("Tidak dapat menghubungi server untuk Google.") }
        req.setRetryPolicy(DefaultRetryPolicy(15000, 0, 1f))
        Volley.newRequestQueue(activity.applicationContext).add(req)
    }

    fun signIn(activity: Activity, register: Boolean, onFinished: Runnable) {
        fresh(activity, object : FreshCredential {
            override fun fail(m: String) {
                onFinished.run()
                Toast.makeText(activity, m, Toast.LENGTH_LONG).show()
            }

            override fun ready(idToken: String, nonce: String) {
                val req: StringRequest = object : StringRequest(
                    Method.POST, BASE + "auth/google.php",
                    Response.Listener { response: String? ->
                        try {
                            val json = JSONObject(response)
                            if (!json.optBoolean("success")) {
                                fail(json.optString("message", "Gagal masuk Google."))
                                return@Listener
                            }
                            val user = json.getJSONObject("user")
                            val token = json.getString("session_token")
                            saveUser(activity, user, token)
                            val intent = Intent(
                                activity,
                                MainActivity::class.java
                            )
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                            activity.startActivity(intent)
                            activity.finish()
                        } catch (e: Exception) {
                            fail("Tidak dapat menyimpan sesi. Silakan coba lagi.")
                        }
                    },
                    Response.ErrorListener { error: VolleyError ->
                        var msg: String = "Tidak dapat menghubungi server."
                        if (error.networkResponse != null && error.networkResponse.data != null) try {
                            msg = JSONObject(
                                String(
                                    error.networkResponse.data,
                                    StandardCharsets.UTF_8
                                )
                            ).optString("message", msg)
                        } catch (ignored: Exception) {
                        }
                        fail(msg)
                    }) {
                    override fun getParams(): Map<String, String>? {
                        val p: MutableMap<String, String> = HashMap()
                        p["mode"] = if (register) "register" else "login"
                        p["id_token"] = idToken
                        p["nonce"] = nonce
                        return p
                    }
                }
                req.setRetryPolicy(DefaultRetryPolicy(20000, 0, 1f))
                Volley.newRequestQueue(activity.applicationContext).add(req)
            }
        })
    }

    @Throws(Exception::class)
    fun saveUser(activity: Activity, user: JSONObject, token: String) {
        if (user.optInt(
                "id",
                0
            ) <= 0 || !token.matches("[a-f0-9]{64}".toRegex())
        ) throw Exception("invalid session")
        SessionStore.save(activity, token)
        val p = activity.getSharedPreferences("lokerku_user", Activity.MODE_PRIVATE)
        migrate(activity, p.getInt("id", 0), user.getInt("id"))
        p.edit().clear().putInt("id", user.getInt("id"))
            .putString("nama", value(user, "nama")).putString("username", value(user, "username"))
            .putString("email", value(user, "email")).putString("phone", value(user, "no_hp"))
            .putString("foto", value(user, "foto")).putString("role", value(user, "role"))
            .putString("profile_headline", value(user, "profile_headline"))
            .putString("profile_lokasi", value(user, "profile_lokasi"))
            .putString("profile_bio", value(user, "profile_bio"))
            .putString("profile_linkedin", value(user, "profile_linkedin"))
            .putString("profile_portfolio", value(user, "profile_portfolio")).apply()
    }

    private fun value(j: JSONObject, key: String): String {
        return if (j.isNull(key)) "" else j.optString(key, "")
    }

    internal interface FreshCredential {
        fun ready(token: String, nonce: String)
        fun fail(message: String)
    }
}
