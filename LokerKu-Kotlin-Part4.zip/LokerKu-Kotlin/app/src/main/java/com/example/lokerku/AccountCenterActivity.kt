package com.example.lokerku

import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.lokerku.GoogleSignInFlow.FreshCredential
import org.json.JSONObject

class AccountCenterActivity : AppCompatActivity() {
    private fun dp(v: Float): Int {
        return (v * resources.displayMetrics.density + .5f).toInt()
    }

    private fun text(s: String, size: Int, color: Int, bold: Boolean): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size.toFloat()
        t.setTextColor(color)
        t.typeface =
            if (bold) AppFont.semibold(this) else AppFont.regular(this)
        return t
    }

    private fun bg(color: Int, radius: Int): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = dp(radius.toFloat()).toFloat()
        return d
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(-0x80701)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20f), dp(26f), dp(20f), dp(30f))
        scroll.addView(root)
        val back = text("‹  Kembali", 15, -0xffff34, true)
        back.setPadding(0, 0, 0, dp(24f))
        back.setOnClickListener { v: View? -> finish() }
        root.addView(back)
        val label = text("LOKERKU  /  PUSAT AKUN", 10, -0xffff34, true)
        label.letterSpacing = .08f
        root.addView(label)
        val title = text("Kelola akunmu", 26, -0xe4d8c3, true)
        root.addView(title)
        val desc = text(
            "Perbarui profil dan kendalikan keamanan akun dalam satu tempat.",
            13,
            -0x978f71,
            false
        )
        desc.setPadding(0, dp(8f), 0, dp(22f))
        root.addView(desc)
        item(
            root, "Profil dan detail pribadi", "Perbarui informasi profil"
        ) {
            startActivity(
                Intent(
                    this,
                    ProfileActivity::class.java
                )
            )
        }
        item(
            root, "Kata sandi & keamanan", "Buat atau ubah kata sandi"
        ) { this.changePassword() }
        item(
            root, "Nonaktifkan akun", "Sembunyikan profil sampai kamu masuk kembali"
        ) { confirmAction("deactivate") }
        item(
            root, "Hapus akun permanen", "Hapus akun, sertifikat, dan riwayat lamaran"
        ) { confirmAction("delete") }
        setContentView(scroll)
        FontEnforcer.apply(root, this)
        UiMotion.bindActions(root)
        UiMotion.revealChildren(root, 100, 65, 6)
    }

    private fun item(root: LinearLayout, title: String, sub: String, click: Runnable) {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(18f), dp(16f), dp(18f), dp(16f))
        card.background = bg(Color.WHITE, 20)
        card.elevation = dp(2f).toFloat()
        card.addView(text("$title   ›", 15, -0xe4d8c3, true))
        val detail = text(sub, 12, -0x978f71, false)
        detail.setPadding(0, dp(5f), 0, 0)
        card.addView(detail)
        val p = LinearLayout.LayoutParams(-1, -2)
        p.bottomMargin = dp(10f)
        root.addView(card, p)
        card.setOnClickListener { v: View? -> click.run() }
    }

    private fun passwordInput(hint: String): EditText {
        val e = EditText(this)
        e.hint = hint
        e.isSingleLine = true
        e.inputType =
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        e.typeface = AppFont.regular(this)
        return e
    }

    private fun changePassword() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20f), 0, dp(20f), 0)
        val pass = passwordInput("Kata sandi baru")
        val confirm = passwordInput("Ulangi kata sandi")
        box.addView(pass)
        val cp = LinearLayout.LayoutParams(-1, -2)
        cp.topMargin = dp(10f)
        box.addView(confirm, cp)
        PremiumDialog.Builder(this).setTitle("Kata sandi baru")
            .setMessage("Kata sandi untuk LokerKu, bukan akun Google. Gunakan 8–72 karakter.")
            .setView(box).setNegativeButton("Batal", null).setPositiveButton(
                "Lanjutkan"
            ) { d: DialogInterface?, w: Int ->
                val n = pass.text.toString()
                if (n.length < 8 || n.length > 72 || n != confirm.text.toString()) {
                    toast("Pastikan password sama dan 8–72 karakter.")
                    return@setPositiveButton
                }
                verifyAndRun("change_password", n)
            }.show()
    }

    private fun confirmAction(action: String) {
        val delete = "delete" == action
        PremiumDialog.Builder(this)
            .setTitle(if (delete) "Hapus akun permanen?" else "Nonaktifkan akun?")
            .setMessage(if (delete) "Akun, sertifikat, foto, dan riwayat lamaran akan dihapus permanen. Tindakan ini tidak dapat dibatalkan." else "Profil dan sertifikat publik akan disembunyikan. Masuk kembali untuk mengaktifkan akun.")
            .setNegativeButton("Batal", null).setPositiveButton(
                if (delete) "Hapus akun" else "Nonaktifkan"
            ) { d: DialogInterface?, w: Int -> verifyAndRun(action, null) }.show()
    }

    private fun verifyAndRun(action: String, newPassword: String?) {
        PremiumDialog.Builder(this).setTitle("Verifikasi pemilik akun").setItems(
            arrayOf("Gunakan password LokerKu", "Gunakan akun Google")
        ) { d: DialogInterface?, which: Int ->
            if (which == 0) {
                val field = passwordInput("Password LokerKu saat ini")
                PremiumDialog.Builder(this).setTitle("Masukkan password")
                    .setView(field).setNegativeButton("Batal", null).setPositiveButton(
                        "Verifikasi"
                    ) { x: DialogInterface?, w: Int ->
                        val p: MutableMap<String, String> =
                            HashMap()
                        p["password"] = field.text.toString()
                        send(action, newPassword, p)
                    }.show()
            } else GoogleSignInFlow.fresh(this, object : FreshCredential {
                override fun fail(message: String) {
                    toast(message)
                }

                override fun ready(token: String, nonce: String) {
                    val p: MutableMap<String, String> =
                        HashMap()
                    p["id_token"] = token
                    p["nonce"] = nonce
                    send(action, newPassword, p)
                }
            })
        }.setNegativeButton("Batal", null).show()
    }

    private fun send(action: String, newPassword: String?, data: MutableMap<String, String>) {
        data["action"] = action
        if (newPassword != null) data["new_password"] = newPassword
        ApiClient.post(this, "auth/account.php", data, object : ApiClient.Result {
            override fun success(json: JSONObject) {
                toast(json.optString("message", "Berhasil"))
                SessionStore.clear(this@AccountCenterActivity)
                if ("delete" == action) {
                    getSharedPreferences(
                        FavoritesStore.name(this@AccountCenterActivity),
                        MODE_PRIVATE
                    ).edit().clear().apply()
                    getSharedPreferences(
                        "lokerku_notes_" + getSharedPreferences(
                            "lokerku_user",
                            MODE_PRIVATE
                        ).getInt("id", 0), MODE_PRIVATE
                    ).edit().clear().apply()
                }
                getSharedPreferences("lokerku_user", MODE_PRIVATE).edit().clear().apply()
                val i = Intent(
                    this@AccountCenterActivity,
                    LoginActivity::class.java
                )
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                startActivity(i)
                finish()
            }

            override fun fail(message: String) {
                toast(message)
            }
        })
    }

    private fun toast(m: String) {
        Toast.makeText(this, m, Toast.LENGTH_LONG).show()
    }
}
