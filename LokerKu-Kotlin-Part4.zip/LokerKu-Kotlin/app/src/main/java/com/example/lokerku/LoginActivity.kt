package com.example.lokerku

import android.animation.ObjectAnimator
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.DefaultRetryPolicy
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.lokerku.AppFont.regular
import com.example.lokerku.AppFont.semibold
import com.example.lokerku.AuthGlass.card
import com.example.lokerku.AuthGlass.field
import com.example.lokerku.FontEnforcer.apply
import org.json.JSONObject
import java.nio.charset.StandardCharsets

class LoginActivity : AppCompatActivity() {
    private val NAVY = Color.rgb(21, 26, 61)
    private val TEAL = Color.rgb(0, 0, 255)
    private val BG = Color.rgb(247, 248, 255)
    private val MUTED = Color.rgb(104, 112, 143)
    private val WHITE = Color.WHITE

    private var etIdentity: EditText? = null
    private var etPassword: EditText? = null
    private var btnLogin: Button? = null
    private var progressBar: ProgressBar? = null
    private var tvRegister: TextView? = null
    private var tvForgotPassword: TextView? = null

    private var requestQueue: RequestQueue? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = -0xebd27d
        window.navigationBarColor = -0xd1b84b
        if (Build.VERSION.SDK_INT >= 23) {
            window.decorView.systemUiVisibility = 0
        }

        requestQueue = Volley.newRequestQueue(applicationContext)

        buildLoginScreen()
    }

    private fun buildLoginScreen() {
        val scrollView = ScrollView(this)
        scrollView.isFillViewport = true
        scrollView.setBackgroundColor(Color.TRANSPARENT)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setPadding(dp(22), dp(24), dp(22), dp(26))

        scrollView.addView(root)

        val brand = TextView(this)
        brand.text = "✦   LOKERKU"
        brand.setTextColor(-0x1a1001)
        brand.textSize = 13f
        brand.letterSpacing = .12f
        brand.typeface = semibold(this)
        brand.gravity = Gravity.CENTER
        brand.setPadding(0, dp(8), 0, dp(16))
        root.addView(brand, matchWrap())
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(24), dp(28), dp(24), dp(26))
        val cardBackground = card(this)
        card.background = cardBackground
        card.elevation = dp(3).toFloat()

        root.addView(card, matchWrap())

        val title = TextView(this)
        title.text = "Selamat datang kembali"
        title.setTextColor(WHITE)
        title.textSize = 25f
        title.typeface = semibold(this)
        card.addView(title, matchWrap())

        val description = TextView(this)
        description.text = "Masuk ke akunmu untuk menemukan pekerjaan."
        description.setTextColor(-0x1d1401)
        description.textSize = 14f

        val descParams = matchWrap()
        descParams.topMargin = dp(8)
        descParams.bottomMargin = dp(25)
        card.addView(description, descParams)

        addLabel(card, "Email atau Username")

        etIdentity = createEditText(
            "Masukkan email atau username",
            false
        )

        card.addView(etIdentity, matchWrap())

        val passwordLabelParams = matchWrap()
        passwordLabelParams.topMargin = dp(20)
        card.addView(createLabel("Password"), passwordLabelParams)

        etPassword = createEditText("Masukkan password", true)
        card.addView(etPassword, matchWrap())

        tvForgotPassword = TextView(this)
        tvForgotPassword!!.text = "Lupa password?"
        tvForgotPassword!!.setTextColor(-0x1d1001)
        tvForgotPassword!!.textSize = 14f
        tvForgotPassword!!.gravity = Gravity.END
        tvForgotPassword!!.setPadding(0, dp(14), 0, dp(14))

        val forgotParams = matchWrap()
        forgotParams.topMargin = dp(2)
        card.addView(tvForgotPassword, forgotParams)

        tvForgotPassword!!.setOnClickListener { v: View? ->
            startActivity(
                Intent(
                    this@LoginActivity,
                    ForgotPasswordActivity::class.java
                )
            )
        }

        btnLogin = Button(this)
        btnLogin!!.text = "Masuk"
        btnLogin!!.setTextColor(WHITE)
        btnLogin!!.textSize = 16f
        btnLogin!!.isAllCaps = false
        btnLogin!!.typeface = semibold(this)
        val loginButton = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.rgb(0, 0, 204), TEAL)
        )
        loginButton.cornerRadius = dp(18).toFloat()
        btnLogin!!.backgroundTintList = null
        btnLogin!!.stateListAnimator = null
        btnLogin!!.background = loginButton
        btnLogin!!.minHeight = dp(54)
        btnLogin!!.elevation = dp(2).toFloat()

        val buttonParams = matchWrap()
        buttonParams.topMargin = dp(8)
        card.addView(btnLogin, buttonParams)
        val separator = TextView(this)
        separator.text = "ATAU LANJUTKAN DENGAN"
        separator.setTextColor(-0x281a01)
        separator.textSize = 10f
        separator.letterSpacing = .08f
        separator.gravity = Gravity.CENTER
        separator.setPadding(0, dp(16), 0, 0)
        card.addView(separator)
        GoogleDesign.addTo(card, this, "Masuk dengan Google")

        progressBar = ProgressBar(this)
        progressBar!!.isIndeterminate = true
        progressBar!!.visibility = View.GONE

        val progressParams = LinearLayout.LayoutParams(
            dp(36),
            dp(36)
        )
        progressParams.gravity = Gravity.CENTER
        progressParams.topMargin = dp(16)
        card.addView(progressBar, progressParams)

        val registerRow = LinearLayout(this)
        registerRow.gravity = Gravity.CENTER
        registerRow.orientation = LinearLayout.HORIZONTAL

        val registerParams = matchWrap()
        registerParams.topMargin = dp(24)
        card.addView(registerRow, registerParams)

        val registerText = TextView(this)
        registerText.text = "Belum punya akun? "
        registerText.setTextColor(-0x1d1401)
        registerText.textSize = 14f
        registerRow.addView(registerText)

        tvRegister = TextView(this)
        tvRegister!!.text = "Daftar"
        tvRegister!!.setTextColor(WHITE)
        tvRegister!!.textSize = 14f
        tvRegister!!.setPadding(dp(8), dp(12), dp(8), dp(12))
        tvRegister!!.typeface = semibold(this)
        registerRow.addView(tvRegister)

        tvRegister!!.setOnClickListener { v: View? ->
            startActivity(
                Intent(
                    this@LoginActivity,
                    RegisterActivity::class.java
                )
            )
        }

        btnLogin!!.setOnClickListener { v: View? -> loginUser() }

        val scene = FrameLayout(this)
        scene.addView(AuthAmbientView(this), FrameLayout.LayoutParams(-1, -1))
        scene.addView(scrollView, FrameLayout.LayoutParams(-1, -1))
        setContentView(scene)
        apply(scrollView, this)
        UiMotion.styleButtons(scrollView)
        UiMotion.bindActions(scrollView)
        UiMotion.bindPress(tvRegister!!)
        UiMotion.bindPress(tvForgotPassword!!)
        UiMotion.reveal(card, 180)
        UiMotion.revealChildren(card, 260, 55, 12)
    }

    override fun onPause() {
        UiMotion.finishReveals(window.decorView)
        super.onPause()
    }

    private fun addLabel(parent: LinearLayout, text: String) {
        parent.addView(createLabel(text), matchWrap())
    }

    private fun createLabel(text: String): TextView {
        val label = TextView(this)
        label.text = text
        label.setTextColor(WHITE)
        label.textSize = 14f
        label.typeface = semibold(this)
        return label
    }

    private fun createEditText(hint: String, password: Boolean): EditText {
        val editText = EditText(this)
        editText.isSingleLine = true
        editText.setTextColor(WHITE)
        editText.setHintTextColor(-0x37280b)
        editText.textSize = 14f
        editText.hint = hint
        editText.setPadding(dp(15), dp(12), dp(15), dp(12))
        val inputBackground = field(this, false)
        editText.backgroundTintList = null
        editText.background = inputBackground
        editText.onFocusChangeListener =
            View.OnFocusChangeListener { field: View, focused: Boolean ->
                inputBackground.setStroke(
                    dp(if (focused) 2 else 1),
                    if (focused) -0x2b1101 else -0x66392301
                )
                val lift =
                    ObjectAnimator.ofFloat(
                        field, View.TRANSLATION_Z, if (focused) dp(3).toFloat() else 0f
                    )
                lift.setDuration(220)
                lift.start()
            }
        editText.minHeight = dp(52)

        if (password) {
            editText.inputType = (InputType.TYPE_CLASS_TEXT
                    or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        } else {
            editText.inputType = (InputType.TYPE_CLASS_TEXT
                    or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
        }

        // InputType may reset password fields to monospace; keep the project's Poppins font.
        editText.typeface = regular(this)
        return editText
    }

    private fun loginUser() {
        val identity = etIdentity!!.text.toString().trim { it <= ' ' }
        val password = etPassword!!.text.toString()

        if (identity.isEmpty()) {
            etIdentity!!.error = "Email atau username wajib diisi"
            etIdentity!!.requestFocus()
            return
        }

        if (password.isEmpty()) {
            etPassword!!.error = "Password wajib diisi"
            etPassword!!.requestFocus()
            return
        }

        hideKeyboard()
        setLoading(true)

        val request: StringRequest = object : StringRequest(
            Method.POST,
            URL_LOGIN,
            Response.Listener<String> { responseText: String? ->
                setLoading(false)
                try {
                    val response = JSONObject(responseText)
                    val success = response.optBoolean("success", false)

                    if (!success) {
                        val message = response.optString(
                            "message",
                            "Login gagal"
                        )

                        Toast.makeText(
                            this@LoginActivity,
                            message,
                            Toast.LENGTH_LONG
                        ).show()
                        return@Listener
                    }

                    var user = response.optJSONObject("user")

                    if (user == null) {
                        user = response.optJSONObject("data")
                    }

                    if (user == null) {
                        Toast.makeText(
                            this@LoginActivity,
                            "Data pengguna tidak ditemukan",
                            Toast.LENGTH_LONG
                        ).show()
                        return@Listener
                    }

                    val userId = user.optInt("id", 0)

                    if (userId <= 0) {
                        Toast.makeText(
                            this@LoginActivity,
                            "ID pengguna tidak valid",
                            Toast.LENGTH_LONG
                        ).show()
                        return@Listener
                    }

                    val username =
                        if (user.isNull("username")) "" else user.optString("username", "")
                    val sessionToken = response.optString("session_token", "")
                    GoogleSignInFlow.saveUser(this@LoginActivity, user, sessionToken)

                    Toast.makeText(
                        this@LoginActivity,
                        "Login berhasil",
                        Toast.LENGTH_SHORT
                    ).show()

                    val intent = Intent(
                        this@LoginActivity,
                        MainActivity::class.java
                    )

                    intent.putExtra("username", username)
                    intent.setFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK
                                or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    )

                    startActivity(intent)
                } catch (e: Exception) {
                    Toast.makeText(
                        this@LoginActivity,
                        "Respons server tidak valid",
                        Toast.LENGTH_LONG
                    ).show()
                }
            },
            Response.ErrorListener { error: VolleyError ->
                setLoading(false)
                var message = "Tidak dapat terhubung ke server"

                if (error.networkResponse != null && error.networkResponse.data != null) {
                    try {
                        val json =
                            JSONObject(String(error.networkResponse.data, StandardCharsets.UTF_8))
                        message = json.optString("message", message)
                    } catch (ignored: Exception) {
                    }
                }
                Toast.makeText(
                    this@LoginActivity,
                    message,
                    Toast.LENGTH_LONG
                ).show()
            }
        ) {
            override fun getParams(): Map<String, String>? {
                val params: MutableMap<String, String> = HashMap()
                params["username"] = identity
                params["password"] = password
                return params
            }
        }

        request.setShouldCache(false)
        request.setRetryPolicy(
            DefaultRetryPolicy(
                15000,
                1,
                1.0f
            )
        )

        requestQueue!!.add(request)
    }

    private fun setLoading(loading: Boolean) {
        btnLogin!!.isEnabled = !loading
        btnLogin!!.text = if (loading) "Memproses..." else "Masuk"
        progressBar!!.visibility =
            if (loading) View.VISIBLE else View.GONE
    }

    private fun hideKeyboard() {
        try {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager

            if (imm != null && currentFocus != null) {
                imm.hideSoftInputFromWindow(
                    currentFocus!!.windowToken,
                    0
                )
            }
        } catch (ignored: Exception) {
        }
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable {
        val drawable = GradientDrawable()
        drawable.setColor(color)
        drawable.cornerRadius = radius.toFloat()
        drawable.setStroke(dp(1), Color.rgb(226, 233, 241))
        return drawable
    }

    private fun matchWrap(): LinearLayout.LayoutParams {
        return LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
    }

    private fun dp(value: Int): Int {
        return (value * resources.displayMetrics.density + 0.5f
                ).toInt()
    }

    companion object {
        private const val URL_LOGIN = "https://ahannaja.cu.ma/lokerku_api/auth/login.php"

        private const val PREF_NAME = "lokerku_user"
    }
}
