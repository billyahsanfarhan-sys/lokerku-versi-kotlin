package com.example.lokerku

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.transition.ChangeBounds
import android.transition.Fade
import android.transition.TransitionManager
import android.transition.TransitionSet
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.PathInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.widget.ViewFlipper
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.DefaultRetryPolicy
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.ImageRequest
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.lokerku.ApiClient.post
import com.example.lokerku.AppFont.regular
import com.example.lokerku.AppFont.semibold
import com.example.lokerku.CertificateGallery.Companion.show
import com.example.lokerku.FavoritesStore.name
import com.example.lokerku.FontEnforcer.apply
import com.example.lokerku.JobDetailActivity
import com.example.lokerku.LoginActivity
import org.json.JSONObject
import java.util.Arrays
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {
    private var root: LinearLayout? = null
    private var content: LinearLayout? = null
    private var mainScroll: ScrollView? = null
    private var bottomNavigation: LinearLayout? = null
    private val navItems = arrayOfNulls<LinearLayout>(5)
    private val navIcons = arrayOfNulls<ImageView>(5)
    private val navLabels = arrayOfNulls<TextView>(5)
    private var lastNavPage: String? = null
    private var pageRendered = false
    private var searchInput: EditText? = null
    private var searchContainer: LinearLayout? = null
    private var sharedHeader: LinearLayout? = null
    private var headerEyebrow: TextView? = null
    private var headerTitle: TextView? = null
    private var headerSubtitle: TextView? = null

    private var userPrefs: SharedPreferences? = null
    private var favoritePrefs: SharedPreferences? = null

    private val jobs: MutableList<JSONObject> = ArrayList()
    private val favorites: MutableSet<String> = HashSet()

    private var username: String? = "Pengguna"
    private var email: String? = ""
    private var phone: String? = ""

    private var currentPage = "Beranda"
    private var selectedCategory: String? = "Semua"
    private var searchQuery = ""

    private var isLoading = false
    private var ignoreSearchChange = false

    private val bannerHandler = Handler(Looper.getMainLooper())
    private var bannerRunnable: Runnable? = null
    private var bannerFlipper: ViewFlipper? = null
    private var bannerTouchDownX = 0f
    private var bannerTouchDownY = 0f
    private var bannerIndicators: LinearLayout? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        userPrefs = getSharedPreferences(
            PREF_USER, MODE_PRIVATE
        )

        favoritePrefs = getSharedPreferences(
            name(this), MODE_PRIVATE
        )

        val saved = favoritePrefs!!.getStringSet(
            KEY_FAVORITES, HashSet()
        )

        if (saved != null) {
            favorites.addAll(saved)
        }

        val intentName = intent.getStringExtra("username")

        username = userPrefs!!.getString(
            "username",
            if (intentName == null || intentName.trim { it <= ' ' }.isEmpty())
                userPrefs!!.getString("nama", "Pengguna")
            else
                intentName
        )

        if (username == null || username!!.trim { it <= ' ' }.isEmpty()) username =
            userPrefs!!.getString("nama", "Pengguna")
        email = userPrefs!!.getString("email", "")

        phone = userPrefs!!.getString(
            "phone",
            userPrefs!!.getString("no_hp", "")
        )

        selectedCategory = userPrefs!!.getString(
            "category", "Semua"
        )

        buildScreen()
        loadJobs()
    }

    private fun buildScreen() {
        root = LinearLayout(this)
        root!!.orientation = LinearLayout.VERTICAL
        root!!.setBackgroundColor(BACKGROUND)

        val scrollView = ScrollView(this)
        mainScroll = scrollView
        scrollView.isFillViewport = false
        scrollView.isVerticalScrollBarEnabled = false
        scrollView.clipToPadding = false
        // The dock has its own area so it cannot cover the scrolling content.
        scrollView.setPadding(0, 0, 0, dp(12f))

        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL

        scrollView.addView(
            page,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        buildHeader(page)

        content = LinearLayout(this)
        content!!.orientation = LinearLayout.VERTICAL
        content!!.setPadding(
            dp(18f), dp(18f), dp(18f), dp(24f)
        )

        page.addView(
            content,
            LinearLayout.LayoutParams(
                -1, -2
            )
        )

        root!!.addView(
            scrollView,
            LinearLayout.LayoutParams(
                -1, 0, 1f
            )
        )

        bottomNavigation = LinearLayout(this)
        bottomNavigation!!.orientation = LinearLayout.HORIZONTAL
        bottomNavigation!!.gravity = Gravity.CENTER
        bottomNavigation!!.setPadding(
            dp(7f), dp(7f), dp(7f), dp(7f)
        )
        bottomNavigation!!.background = rounded(WHITE, 22)
        bottomNavigation!!.elevation = dp(9f).toFloat()

        val navParams = LinearLayout.LayoutParams(-1, -2)
        navParams.setMargins(dp(12f), dp(4f), dp(12f), dp(10f))
        root!!.addView(bottomNavigation, navParams)
        setContentView(root)

        renderPage("Beranda")
    }

    private fun buildHeader(parent: LinearLayout) {
        val header = LinearLayout(this)
        header.orientation = LinearLayout.VERTICAL
        sharedHeader = header
        header.setPadding(
            dp(22f), dp(26f), dp(22f), dp(24f)
        )
        header.background = gradient(BLUE_DARK, BLUE)

        val top = row()

        val brand = LinearLayout(this)
        brand.orientation = LinearLayout.VERTICAL

        headerEyebrow = text("LOKERKU  /  CAREER SPACE", 10, -0x231d01, true)
        headerTitle = text("Temukan karier terbaikmu", 21, WHITE, true)
        brand.addView(headerEyebrow)
        brand.addView(headerTitle)

        top.addView(
            brand,
            LinearLayout.LayoutParams(0, -2, 1f)
        )

        val notification = FrameLayout(this)
        notification.background = rounded(Color.rgb(50, 50, 255), 15)
        notification.isClickable = true
        notification.isFocusable = true
        notification.contentDescription = "Notifikasi"

        val notificationIcon = ImageView(this)
        notificationIcon.setImageResource(R.drawable.ic_notifications)
        notificationIcon.setColorFilter(WHITE)
        notificationIcon.scaleType = ImageView.ScaleType.FIT_CENTER
        val notificationIconParams =
            FrameLayout.LayoutParams(dp(24f), dp(24f), Gravity.CENTER)
        notification.addView(notificationIcon, notificationIconParams)

        top.addView(
            notification,
            LinearLayout.LayoutParams(dp(44f), dp(44f))
        )

        notification.setOnClickListener { v: View? -> showNotificationsDialog() }

        header.addView(top)

        val subtitle = text(
            "Peluang baru dimulai dari sini.",
            12, Color.rgb(226, 230, 255), false
        )

        headerSubtitle = subtitle
        val subParams =
            LinearLayout.LayoutParams(-1, -2)

        subParams.topMargin = dp(6f)
        header.addView(subtitle, subParams)

        searchContainer = row()
        searchContainer!!.gravity = Gravity.CENTER_VERTICAL
        searchContainer!!.setPadding(
            dp(13f), 0, dp(13f), 0
        )
        searchContainer!!.background = rounded(WHITE, 15)

        val searchIcon = text(
            "⌕", 26, BLUE, true
        )

        searchContainer!!.addView(
            searchIcon,
            LinearLayout.LayoutParams(
                dp(30f), dp(48f)
            )
        )

        searchInput = EditText(this)
        searchInput!!.isSingleLine = true
        searchInput!!.textSize = 13f
        searchInput!!.setTextColor(TEXT)
        searchInput!!.setHintTextColor(MUTED)
        searchInput!!.hint = "Cari posisi, perusahaan, atau lokasi"
        searchInput!!.setPadding(
            dp(5f), 0, dp(4f), 0
        )
        searchInput!!.setBackgroundColor(Color.TRANSPARENT)
        searchInput!!.typeface = regular(this)
        searchInput!!.setSelectAllOnFocus(false)

        searchContainer!!.addView(
            searchInput,
            LinearLayout.LayoutParams(0, dp(49f), 1f)
        )

        val searchParams =
            LinearLayout.LayoutParams(-1, dp(49f))

        searchParams.topMargin = dp(17f)
        header.addView(searchContainer, searchParams)

        searchInput!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(
                s: CharSequence, start: Int,
                count: Int, after: Int
            ) {
            }

            override fun onTextChanged(
                s: CharSequence, start: Int,
                before: Int, count: Int
            ) {
                if (ignoreSearchChange) return

                searchQuery = s.toString().trim { it <= ' ' }

                if (currentPage == "Beranda"
                    || currentPage == "Eksplorasi"
                ) {
                    renderPage(currentPage)
                }
            }

            override fun afterTextChanged(s: Editable) {}
        })

        parent.addView(header)
    }

    private fun renderPage(page: String) {
        val previousPage = currentPage
        val pageChanged = previousPage != null && previousPage != page
        currentPage = page
        if ("Beranda" != page) {
            stopBannerAutoSlide()
        }

        if (content == null) return

        UiMotion.finishReveals(content)
        content!!.removeAllViews()
        buildBottomNavigation()
        updatePageHeader(page)

        val showSearch =
            page == "Beranda"
                    || page == "Eksplorasi"

        // Sembunyikan seluruh wadah pencarian di halaman Favorit, Lamaran, dan Profil.
        // Ini mencegah kotak putih kosong tertinggal di header.
        if (searchContainer != null) {
            searchContainer!!.visibility =
                if (showSearch) View.VISIBLE else View.GONE
        }

        when (page) {
            "Beranda" -> homePage()
            "Eksplorasi" -> explorePage()
            "Favorit" -> favoritePage()
            "Lamaran" -> applicationPage()
            "Profil" -> profilePage()
            else -> homePage()
        }
        apply(root, this)

        if (pageChanged && mainScroll != null) mainScroll!!.post { mainScroll!!.scrollTo(0, 0) }
        UiMotion.styleButtons(content!!)
        UiMotion.bindActions(content!!)
        if (pageChanged || !pageRendered) {
            UiMotion.revealChildren(content!!, 70, 65, 9)
        }
        pageRendered = true
    }

    private fun updatePageHeader(page: String) {
        if (sharedHeader == null) return
        if ("Profil" == page) {
            sharedHeader!!.visibility = View.GONE
            return
        }
        sharedHeader!!.visibility = View.VISIBLE
        var a = -0xffff34
        var b = -0xd9d301
        var label = "CAREER SPACE"
        var title = "Temukan karier terbaikmu"
        var subtitle = "Peluang baru dimulai dari sini."
        if ("Eksplorasi" == page) {
            label = "TEMUKAN PELUANG"
            title = "Jelajahi pekerjaan"
            subtitle = "Temukan posisi yang sesuai dengan tujuanmu."
            a = -0xede39b
            b = -0xdab41b
        } else if ("Favorit" == page) {
            label = "PILIHANMU"
            title = "Peluang tersimpan"
            subtitle = "Semua lowongan pilihan dalam satu tempat."
            a = -0xe8e69e
            b = -0xb6bb2c
        } else if ("Lamaran" == page) {
            label = "PERJALANAN KARIER"
            title = "Langkah berikutnya"
            subtitle = "Pantau dan persiapkan perjalanan kariermu."
            a = -0xefdba7
            b = -0xe89638
        }
        sharedHeader!!.background = gradient(a, b)
        headerEyebrow!!.text = "LOKERKU  /  $label"
        headerTitle!!.text = title
        headerSubtitle!!.text = subtitle
    }

    private fun pageIndex(page: String): Int {
        if ("Beranda" == page) return 0
        if ("Eksplorasi" == page) return 1
        if ("Favorit" == page) return 2
        if ("Lamaran" == page) return 3
        if ("Profil" == page) return 4
        return 0
    }

    private fun buildBottomNavigation() {
        val labels = arrayOf("Beranda", "Eksplorasi", "Favorit", "Lamaran", "Profil")
        val icons = intArrayOf(
            R.drawable.ic_home, R.drawable.ic_search, R.drawable.ic_favorite,
            R.drawable.ic_work, R.drawable.ic_person
        )
        if (navItems[0] == null) {
            bottomNavigation!!.gravity = Gravity.CENTER
            bottomNavigation!!.orientation = LinearLayout.HORIZONTAL
            bottomNavigation!!.setPadding(dp(7f), dp(7f), dp(7f), dp(7f))
            val dock = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(-0x2ad5c79e, -0x3aede1c0, -0x2addcfa9)
            )
            dock.cornerRadius = dp(28f).toFloat()
            dock.setStroke(dp(1f), -0x66261a01)
            val reflection = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0x3affffff, 0x00ffffff)
            )
            reflection.cornerRadius = dp(26f).toFloat()
            val dockGlass = LayerDrawable(
                arrayOf<Drawable>(dock, reflection)
            )
            dockGlass.setLayerInset(1, dp(2f), dp(2f), dp(2f), dp(32f))
            bottomNavigation!!.background = dockGlass
            bottomNavigation!!.elevation = dp(10f).toFloat()
            for (i in labels.indices) {
                val label = labels[i]
                val item = LinearLayout(this)
                item.orientation = LinearLayout.HORIZONTAL
                item.gravity = Gravity.CENTER
                item.minimumHeight = dp(52f)
                item.setPadding(dp(3f), dp(8f), dp(3f), dp(8f))
                item.isClickable = true
                item.isFocusable = true
                val icon = ImageView(this)
                icon.setImageResource(icons[i])
                icon.scaleType = ImageView.ScaleType.CENTER_INSIDE
                icon.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                item.addView(icon, LinearLayout.LayoutParams(dp(24f), dp(24f)))
                val title = text(label, 11, BLUE, true)
                title.isSingleLine = true
                title.ellipsize = TextUtils.TruncateAt.END
                title.includeFontPadding = false
                title.gravity = Gravity.CENTER_VERTICAL
                val titleParams = LinearLayout.LayoutParams(-2, -2)
                titleParams.leftMargin = dp(6f)
                item.addView(title, titleParams)
                item.setOnClickListener { v: View? ->
                    if (currentPage != label) renderPage(
                        label
                    )
                }
                UiMotion.bindPress(item)
                val params = LinearLayout.LayoutParams(0, -2, 1f)
                params.setMargins(dp(1f), 0, dp(1f), 0)
                bottomNavigation!!.addView(item, params)
                navItems[i] = item
                navIcons[i] = icon
                navLabels[i] = title
            }
        }
        val changed = lastNavPage != null && lastNavPage != currentPage
        if (changed && bottomNavigation!!.isLaidOut) {
            val transition = TransitionSet()
            transition.addTransition(ChangeBounds())
            transition.addTransition(Fade())
            transition.setDuration(620)
            transition.setInterpolator(PathInterpolator(.22f, .75f, .25f, 1f))
            TransitionManager.beginDelayedTransition(bottomNavigation, transition)
        }
        for (i in labels.indices) {
            val active = currentPage == labels[i]
            val item = navItems[i]
            item!!.isSelected = active
            item.contentDescription = labels[i] + (if (active) ", halaman aktif" else "")
            if (active) {
                // A single LokerKu blue is shared by all destinations.
                val glossy = GradientDrawable(
                    GradientDrawable.Orientation.TL_BR,
                    intArrayOf(-0xe8c933, -0xac9210)
                )
                glossy.cornerRadius = dp(20f).toFloat()
                glossy.setStroke(dp(1f), -0x66000001)
                val sheen = GradientDrawable(
                    GradientDrawable.Orientation.TOP_BOTTOM,
                    intArrayOf(0x55ffffff, 0x08ffffff)
                )
                sheen.cornerRadius = dp(18f).toFloat()
                val glassDock = LayerDrawable(
                    arrayOf<Drawable>(glossy, sheen)
                )
                glassDock.setLayerInset(1, dp(2f), dp(2f), dp(2f), dp(27f))
                item.background = glassDock
                item.elevation = dp(3f).toFloat()
            } else {
                item.background = rounded(Color.TRANSPARENT, 20)
                item.elevation = 0f
            }
            navIcons[i]!!.setColorFilter(if (active) WHITE else -0x362b12)
            navLabels[i]!!.setTextColor(WHITE)
            navLabels[i]!!.visibility = if (active) View.VISIBLE else View.GONE
            if (changed && active) {
                val sx = ObjectAnimator.ofFloat(navIcons[i], View.SCALE_X, .83f, 1.14f, 1f)
                val sy = ObjectAnimator.ofFloat(navIcons[i], View.SCALE_Y, .83f, 1.14f, 1f)
                val set = AnimatorSet()
                set.playTogether(sx, sy)
                set.setDuration(460)
                set.start()
            }
            val params = item.layoutParams as LinearLayout.LayoutParams
            params.weight = if (active) 2.15f else 1f
            item.layoutParams = params
        }
        lastNavPage = currentPage
    }

    private fun homePage() {
        addText("Halo, $username", 23, TEXT, true)

        addText(
            "Temukan peluang yang sesuai dengan tujuanmu.",
            12, MUTED, false
        )

        addHeroBanner()

        val shortcuts = row()
        shortcuts.gravity = Gravity.CENTER
        shortcuts.isBaselineAligned = false
        shortcuts.clipChildren = false
        shortcuts.setPadding(0, dp(2f), 0, dp(2f))

        shortcuts.addView(
            shortcut(
                R.drawable.ic_search, "Cari kerja", "Jelajahi posisi"
            ) { renderPage("Eksplorasi") },
            shortcutCardLayoutParams()
        )

        shortcuts.addView(
            shortcut(
                R.drawable.ic_favorite, "Favorit", "Tersimpan"
            ) { renderPage("Favorit") },
            shortcutCardLayoutParams()
        )

        shortcuts.addView(
            shortcut(
                R.drawable.ic_work, "Lamaran", "Pantau lamaran"
            ) { renderPage("Lamaran") },
            shortcutCardLayoutParams()
        )

        val shortcutRowParams =
            LinearLayout.LayoutParams(-1, -2)
        shortcutRowParams.setMargins(dp(1f), dp(5f), dp(1f), dp(13f))
        content!!.addView(shortcuts, shortcutRowParams)

        section(
            "Kategori pekerjaan",
            "Lihat semua",
            Runnable { renderPage("Eksplorasi") }
        )

        addCategories()

        section(
            "Lowongan terbaru",
            "Lihat semua",
            Runnable { renderPage("Eksplorasi") }
        )

        showJobs(false)

        section("Persiapan karier", null, null)

        addInfoCard(
            "Pembuat CV",
            "Susun CV profesional dengan data diri, pendidikan, pengalaman, dan keahlian.",
            "Mulai buat CV"
        ) {
            startActivity(
                Intent(
                    this@MainActivity,
                    CVBuilderActivity::class.java
                )
            )
        }

        addInfoCard(
            "Tips wawancara",
            "Pelajari strategi, contoh jawaban, dan persiapan sebelum bertemu perekrut.",
            "Mulai belajar"
        ) {
            startActivity(
                Intent(
                    this@MainActivity,
                    InterviewTipsActivity::class.java
                )
            )
        }
    }

    private class BannerFrame(context: Context) : FrameLayout(context) {
        override fun performClick(): Boolean {
            return super.performClick()
        }
    }

    private fun addHeroBanner() {
        stopBannerAutoSlide()

        val bannerImages = intArrayOf(
            R.drawable.banner_1,
            R.drawable.banner_2,
            R.drawable.banner_3,
            R.drawable.banner_4,
            R.drawable.banner_5
        )

        val bannerFrame = BannerFrame(this)
        bannerFrame.background = rounded(WHITE, 20)
        bannerFrame.clipToOutline = true
        bannerFrame.elevation = dp(4f).toFloat()

        bannerFlipper = ViewFlipper(this)
        bannerFlipper!!.isAutoStart = false
        bannerFlipper!!.flipInterval = 5000
        bannerFlipper!!.setInAnimation(this, R.anim.slide_in_right)
        bannerFlipper!!.setOutAnimation(this, R.anim.slide_out_left)
        bannerFlipper!!.measureAllChildren = false

        for (imageResource in bannerImages) {
            val image = ImageView(this)
            image.setImageResource(imageResource)
            // Banner sumber berasio 1440x640 (2.25:1); FIT_XY
            // mengisi frame penuh tanpa memotong sisi gambar.
            image.scaleType = ImageView.ScaleType.FIT_XY
            image.contentDescription = "Banner informasi karier LokerKu"
            image.setBackgroundColor(WHITE)
            bannerFlipper!!.addView(
                image,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
        }

        bannerFrame.addView(
            bannerFlipper,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        bannerIndicators = LinearLayout(this)
        bannerIndicators!!.orientation = LinearLayout.HORIZONTAL
        bannerIndicators!!.gravity = Gravity.CENTER
        bannerIndicators!!.setPadding(dp(6f), 0, dp(6f), 0)
        bannerIndicators!!.background = rounded(0x660b1656, 10)
        val indicatorParams =
            FrameLayout.LayoutParams(-2, dp(18f), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        indicatorParams.bottomMargin = dp(3f)
        bannerFrame.addView(bannerIndicators, indicatorParams)
        bannerIndicators!!.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        updateBannerIndicators()
        bannerFrame.setTag(R.id.ui_motion_skip_press, java.lang.Boolean.TRUE)
        bannerFrame.setOnClickListener { v: View? -> openBannerDestination() }
        bannerFrame.setOnTouchListener { v: View, event: MotionEvent ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    bannerTouchDownX = event.x
                    bannerTouchDownY = event.y
                    if (bannerRunnable != null) bannerHandler.removeCallbacks(bannerRunnable!!)
                    return@setOnTouchListener true
                }

                MotionEvent.ACTION_UP -> {
                    val deltaX = event.x - bannerTouchDownX
                    if (abs(deltaX.toDouble()) > dp(35f)) {
                        if (deltaX < 0) {
                            bannerFlipper!!.setInAnimation(
                                this,
                                R.anim.slide_in_right
                            )
                            bannerFlipper!!.setOutAnimation(
                                this,
                                R.anim.slide_out_left
                            )
                            bannerFlipper!!.showNext()
                        } else {
                            bannerFlipper!!.setInAnimation(
                                this,
                                R.anim.slide_in_left
                            )
                            bannerFlipper!!.setOutAnimation(
                                this,
                                R.anim.slide_out_right
                            )
                            bannerFlipper!!.showPrevious()
                        }
                        updateBannerIndicators()
                        restartBannerAutoSlide()
                    } else if (abs((event.y - bannerTouchDownY).toDouble()) < dp(25f)) {
                        v.performClick()
                    } else {
                        restartBannerAutoSlide()
                    }
                    return@setOnTouchListener true
                }

                MotionEvent.ACTION_CANCEL -> {
                    restartBannerAutoSlide()
                    return@setOnTouchListener true
                }
            }
            true
        }

        bannerFrame.isClickable = true
        bannerFrame.isFocusable = true
        bannerFrame.contentDescription =
            "Banner LokerKu. Ketuk untuk membuka fitur yang ditampilkan, atau geser untuk melihat banner lain."

        val density = resources.displayMetrics.density
        val screenWidthDp = (resources.displayMetrics.widthPixels / density).toInt()
        val availableWidthDp = max(1.0, (screenWidthDp - 36).toDouble()).toInt()
        val bannerHeightDp = Math.round(availableWidthDp / 2.25f)
        val params =
            LinearLayout.LayoutParams(-1, dp(bannerHeightDp.toFloat()))
        params.setMargins(0, dp(15f), 0, dp(12f))
        content!!.addView(bannerFrame, params)

        bannerRunnable = object : Runnable {
            override fun run() {
                if (bannerFlipper == null || currentPage != "Beranda") {
                    return
                }
                bannerFlipper!!.setInAnimation(this@MainActivity, R.anim.slide_in_right)
                bannerFlipper!!.setOutAnimation(this@MainActivity, R.anim.slide_out_left)
                bannerFlipper!!.showNext()
                updateBannerIndicators()
                bannerHandler.postDelayed(this, 5000)
            }
        }
        bannerHandler.postDelayed(bannerRunnable!!, 5000)
    }


    private fun updateBannerIndicators() {
        if (bannerIndicators == null || bannerFlipper == null) return
        if (bannerIndicators!!.childCount == 0) {
            for (i in 0 until bannerFlipper!!.childCount) {
                val dot = View(this)
                dot.background = rounded(WHITE, 10)
                val p = LinearLayout.LayoutParams(dp(6f), dp(6f))
                p.setMargins(dp(3f), 0, dp(3f), 0)
                bannerIndicators!!.addView(dot, p)
            }
        } else {
            val transition = ChangeBounds()
            transition.setDuration(650)
            transition.setInterpolator(DecelerateInterpolator())
            TransitionManager.beginDelayedTransition(bannerIndicators, transition)
        }
        for (i in 0 until bannerIndicators!!.childCount) {
            val dot = bannerIndicators!!.getChildAt(i)
            val active = i == bannerFlipper!!.displayedChild
            val params = dot.layoutParams as LinearLayout.LayoutParams
            params.width = dp((if (active) 19 else 6).toFloat())
            dot.layoutParams = params
            dot.animate().alpha(if (active) 1f else .48f).setDuration(650).start()
        }
    }

    private fun openBannerDestination() {
        if (bannerFlipper == null) return

        when (bannerFlipper!!.displayedChild) {
            0, 1 -> renderPage("Eksplorasi")
            2 -> renderPage("Favorit")
            3 -> renderPage("Lamaran")
            4 -> renderPage("Profil")
            else -> renderPage("Eksplorasi")
        }
    }

    private fun restartBannerAutoSlide() {
        if (bannerRunnable == null) return
        bannerHandler.removeCallbacks(bannerRunnable!!)
        bannerHandler.postDelayed(bannerRunnable!!, 5000)
    }

    private fun stopBannerAutoSlide() {
        if (bannerRunnable != null) {
            bannerHandler.removeCallbacks(bannerRunnable!!)
            bannerRunnable = null
        }
        bannerFlipper = null
        bannerIndicators = null
    }

    override fun onDestroy() {
        stopBannerAutoSlide()
        super.onDestroy()
    }

    private fun shortcutCardLayoutParams(): LinearLayout.LayoutParams {
        val params =
            LinearLayout.LayoutParams(0, -1, 1f)
        params.setMargins(dp(5f), 0, dp(5f), 0)
        return params
    }

    private fun shortcut(
        iconResource: Int,
        title: String,
        subtitle: String,
        action: Runnable
    ): View {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.gravity = Gravity.CENTER
        card.setPadding(dp(7f), dp(15f), dp(7f), dp(15f))
        card.minimumHeight = dp(132f)
        card.background = rounded(WHITE, 18)
        card.elevation = dp(2f).toFloat()
        card.isClickable = true
        card.isFocusable = true

        val iconContainer = FrameLayout(this)
        iconContainer.background = rounded(BLUE_LIGHT, 15)
        iconContainer.clipToOutline = true

        val iconView = ImageView(this)
        iconView.setImageResource(iconResource)
        iconView.scaleType = ImageView.ScaleType.FIT_CENTER
        iconView.setColorFilter(BLUE)
        iconView.setPadding(dp(10f), dp(10f), dp(10f), dp(10f))
        iconContainer.addView(
            iconView, FrameLayout.LayoutParams(
                dp(46f), dp(46f), Gravity.CENTER
            )
        )

        val iconParams =
            LinearLayout.LayoutParams(dp(46f), dp(46f))
        iconParams.bottomMargin = dp(10f)
        card.addView(iconContainer, iconParams)

        val titleView = text(title, 11, TEXT, true)
        titleView.gravity = Gravity.CENTER
        titleView.maxLines = 2
        titleView.includeFontPadding = false
        card.addView(titleView, LinearLayout.LayoutParams(-1, -2))

        val subView = text(subtitle, 10, MUTED, false)
        subView.gravity = Gravity.CENTER
        subView.maxLines = 2
        subView.includeFontPadding = false
        val subParams =
            LinearLayout.LayoutParams(-1, -2)
        subParams.topMargin = dp(5f)
        card.addView(subView, subParams)

        UiMotion.bindPress(card)
        card.setOnClickListener { v: View? -> action.run() }

        return card
    }

    private fun addCategories() {
        val scroll = HorizontalScrollView(this)
        scroll.isHorizontalScrollBarEnabled = false

        val categories = row()

        val names = arrayOf(
            "Semua", "IT & Software",
            "Administrasi", "Marketing",
            "Keuangan", "Desain",
            "Pendidikan", "Kesehatan",
            "Customer Service"
        )

        for (name in names) {
            val category = text(
                name, 11,
                if (selectedCategory == name) WHITE else BLUE,
                true
            )

            category.gravity = Gravity.CENTER
            category.setPadding(
                dp(14f), dp(10f), dp(14f), dp(10f)
            )

            category.background = rounded(
                if (selectedCategory == name)
                    BLUE
                else
                    WHITE,
                22
            )

            category.setOnClickListener { v: View? ->
                selectedCategory = name
                userPrefs!!.edit()
                    .putString("category", name)
                    .apply()
                renderPage("Eksplorasi")
            }

            val params =
                LinearLayout.LayoutParams(-2, -2)

            params.setMargins(0, 0, dp(8f), 0)
            categories.addView(category, params)
        }

        scroll.addView(categories)

        val params =
            LinearLayout.LayoutParams(-1, -2)

        params.bottomMargin = dp(8f)
        content!!.addView(scroll, params)
    }

    private fun explorePage() {
        addPageIntro(
            "EKSPLORASI",
            "Eksplorasi pekerjaan",
            "Cari pekerjaan berdasarkan kategori dan kata kunci."
        )

        val filters = row()

        val all = chip("Semua kategori")
        all.setOnClickListener { v: View? ->
            selectedCategory = "Semua"
            userPrefs!!.edit()
                .putString("category", selectedCategory)
                .apply()
            renderPage("Eksplorasi")
        }

        val reset = chip("Reset pencarian")
        reset.setOnClickListener { v: View? ->
            selectedCategory = "Semua"
            searchQuery = ""

            ignoreSearchChange = true
            searchInput!!.setText("")
            ignoreSearchChange = false

            userPrefs!!.edit()
                .putString("category", selectedCategory)
                .apply()
            renderPage("Eksplorasi")
        }

        filters.addView(all)
        filters.addView(reset)
        content!!.addView(filters)

        section("Daftar lowongan", null, null)
        showJobs(true)
    }

    private fun showJobs(showAll: Boolean) {
        var shown = 0

        for (job in jobs) {
            val category = job.optString("kategori", "")

            val searchable = ((job.optString("judul", "") + " "
                    + job.optString("perusahaan", "") + " "
                    + job.optString("lokasi", "") + " "
                    + category)
                    ).lowercase()

            val categoryMatch =
                selectedCategory == "Semua"
                        || category.equals(selectedCategory, ignoreCase = true)

            val queryMatch =
                searchQuery.isEmpty()
                        || searchable.contains(
                    searchQuery.lowercase()
                )

            if (!categoryMatch || !queryMatch) continue

            content!!.addView(jobCard(job))
            shown++

            if (!showAll && shown >= 4) break
        }

        if (shown == 0) {
            addInfoCard(
                if (isLoading)
                    "Memuat lowongan..."
                else
                    if (jobs.isEmpty())
                        "Lowongan belum tersedia"
                    else
                        "Lowongan tidak ditemukan",
                if (jobs.isEmpty())
                    "Periksa koneksi internet atau endpoint API lowongan."
                else
                    "Coba kata kunci atau kategori lainnya.",
                "Muat ulang"
            ) { this.loadJobs() }
        }
    }

    private fun jobCard(job: JSONObject): View {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(
            dp(18f), dp(18f), dp(18f), dp(18f)
        )
        card.background = rounded(WHITE, 22)
        card.elevation = dp(2f).toFloat()

        val cardParams =
            LinearLayout.LayoutParams(-1, -2)

        cardParams.setMargins(0, 0, 0, dp(12f))
        card.layoutParams = cardParams

        val top = row()
        top.gravity = Gravity.CENTER_VERTICAL

        val company = job.optString("perusahaan", "Perusahaan")

        val logo = text(initials(company), 15, WHITE, true)
        logo.gravity = Gravity.CENTER
        logo.background = gradient(BLUE_DARK, BLUE)

        top.addView(
            logo,
            LinearLayout.LayoutParams(dp(47f), dp(47f))
        )

        val info = LinearLayout(this)
        info.orientation = LinearLayout.VERTICAL
        info.setPadding(dp(11f), 0, dp(5f), 0)

        info.addView(
            text(
                job.optString("judul", "Lowongan pekerjaan"),
                14, TEXT, true
            )
        )

        info.addView(text(company, 12, MUTED, false))

        top.addView(
            info,
            LinearLayout.LayoutParams(0, -2, 1f)
        )

        val id = job.optString("id")

        val favoriteButton = FrameLayout(this)
        favoriteButton.background = rounded(
            if (favorites.contains(id)) BLUE_LIGHT else BACKGROUND, 14
        )
        favoriteButton.isClickable = true
        favoriteButton.isFocusable = true
        favoriteButton.contentDescription =
            if (favorites.contains(id)) "Hapus dari favorit" else "Simpan ke favorit"

        val heart = ImageView(this)
        heart.setImageResource(R.drawable.ic_favorite)
        heart.setColorFilter(if (favorites.contains(id)) BLUE else MUTED)
        heart.scaleType = ImageView.ScaleType.FIT_CENTER
        val heartParams = FrameLayout.LayoutParams(
            dp(21f), dp(21f), Gravity.CENTER
        )
        favoriteButton.addView(heart, heartParams)

        val favoriteButtonParams =
            LinearLayout.LayoutParams(dp(48f), dp(48f))
        top.addView(favoriteButton, favoriteButtonParams)

        favoriteButton.setOnClickListener { v: View? -> toggleFavorite(id) }

        card.addView(top)

        val tags = row()
        tags.setPadding(0, dp(11f), 0, dp(9f))

        tags.addView(chip(job.optString("kategori", "Umum")))
        tags.addView(chip(job.optString("tipe", "Pekerjaan")))

        val tagScroll = HorizontalScrollView(this)
        tagScroll.isHorizontalScrollBarEnabled = false
        tagScroll.addView(tags)
        card.addView(tagScroll)

        card.addView(
            text(
                "Lokasi: " + job.optString(
                    "lokasi", "Tidak disebutkan"
                ),
                12, MUTED, false
            )
        )

        val salary = formatSalary(
            job.optString("gaji_min", ""),
            job.optString("gaji_max", "")
        )

        if (!salary.isEmpty()) {
            val salaryView = text(
                salary, 14, BLUE, true
            )

            val salaryParams =
                LinearLayout.LayoutParams(-1, -2)

            salaryParams.topMargin = dp(8f)
            card.addView(salaryView, salaryParams)
        }

        val detail = text(
            "Lihat detail lowongan  →",
            12, BLUE, true
        )

        val detailParams =
            LinearLayout.LayoutParams(-1, -2)

        detailParams.topMargin = dp(11f)
        card.addView(detail, detailParams)

        card.setOnClickListener { v: View? -> showJobDetail(job) }

        return card
    }

    private fun toggleFavorite(id: String?) {
        if (id == null || id.trim { it <= ' ' }.isEmpty()) {
            toast("ID lowongan tidak tersedia")
            return
        }

        if (favorites.contains(id)) {
            favorites.remove(id)
            toast("Dihapus dari favorit")
        } else {
            favorites.add(id)
            toast("Disimpan ke favorit")
        }

        favoritePrefs!!.edit()
            .putStringSet(
                KEY_FAVORITES,
                HashSet(favorites)
            )
            .apply()

        renderPage(currentPage)
    }

    private fun favoritePage() {
        addPageIntro("FAVORIT", "Lowongan favorit", "Kumpulan pekerjaan yang kamu simpan.")

        var count = 0

        for (job in jobs) {
            if (favorites.contains(job.optString("id"))) {
                content!!.addView(jobCard(job))
                count++
            }
        }

        if (count == 0) {
            addInfoCard(
                "Belum ada favorit",
                "Tekan ikon hati pada lowongan untuk menyimpannya.",
                "Cari lowongan"
            ) { renderPage("Eksplorasi") }
        }
    }

    private fun applicationPage() {
        addPageIntro("LAMARAN", "Lamaran saya", "Pantau perkembangan proses rekrutmenmu.")
        val records = LinearLayout(this)
        records.orientation = LinearLayout.VERTICAL
        val loading = text("Memuat riwayat lamaran…", 12, MUTED, false)
        records.addView(loading)
        content!!.addView(records)
        post(
            this,
            "profile/applications.php",
            HashMap<String, String>(),
            object : ApiClient.Result {
                override fun success(result: JSONObject) {
                    records.removeAllViews()
                    val a = result.optJSONArray("applications")
                    if (a == null || a.length() == 0) {
                        records.addView(
                            text(
                                "Belum ada riwayat lamaran di server.",
                                13,
                                MUTED,
                                false
                            )
                        )
                        return
                    }
                    for (i in 0 until a.length()) {
                        val r = a.optJSONObject(i) ?: continue
                        val card = LinearLayout(this@MainActivity)
                        card.orientation = LinearLayout.VERTICAL
                        card.setPadding(dp(17f), dp(16f), dp(17f), dp(16f))
                        card.background = rounded(WHITE, 20)
                        card.addView(text(r.optString("judul", "Lowongan"), 15, TEXT, true))
                        val company = text(
                            r.optString(
                                "perusahaan",
                                "Perusahaan"
                            ) + "  •  " + r.optString("lokasi", ""), 12, MUTED, false
                        )
                        company.setPadding(0, dp(5f), 0, dp(8f))
                        card.addView(company)
                        val state = text(
                            "STATUS  /  " + r.optString("status", "menunggu").uppercase(),
                            11,
                            BLUE_DARK,
                            true
                        )
                        card.addView(state)
                        val date = text(r.optString("created_at", ""), 11, MUTED, false)
                        date.setPadding(0, dp(5f), 0, 0)
                        card.addView(date)
                        val lp = LinearLayout.LayoutParams(-1, -2)
                        lp.bottomMargin = dp(10f)
                        records.addView(card, lp)
                    }
                    UiMotion.revealChildren(records, 40, 55, 6)
                }

                override fun fail(message: String) {
                    records.removeAllViews()
                    records.addView(text(message, 12, RED, false))
                }
            })
        addInfoCard(
            "Catatan tindak lanjut",
            "Buat catatan untuk membantu memantau proses rekrutmen.",
            "Buat catatan"
        ) { this.followUpNote() }
    }

    override fun onPause() {
        if (bannerRunnable != null) bannerHandler.removeCallbacks(bannerRunnable!!)
        UiMotion.finishReveals(root)
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (bannerRunnable != null && "Beranda" == currentPage) restartBannerAutoSlide()
        if (content != null && "Profil" == currentPage) {
            username = userPrefs!!.getString("username", userPrefs!!.getString("nama", username))
            if (username == null || username!!.trim { it <= ' ' }.isEmpty()) username =
                userPrefs!!.getString("nama", "Pengguna")
            email = userPrefs!!.getString("email", email)
            phone = userPrefs!!.getString("phone", userPrefs!!.getString("no_hp", phone))
            renderPage("Profil")
        } else if (content != null && "Lamaran" == currentPage) {
            renderPage("Lamaran")
        }
    }

    private fun profilePage() {
        val header = row()
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(0, dp(2f), 0, dp(16f))
        val menu = ImageView(this)
        menu.setImageResource(R.drawable.ic_lk_menu)
        menu.setColorFilter(BLUE_DARK)
        menu.setPadding(dp(12f), dp(12f), dp(12f), dp(12f))
        menu.background = rounded(WHITE, 15)
        menu.contentDescription = "Buka pusat akun"
        header.addView(menu, LinearLayout.LayoutParams(dp(48f), dp(48f)))
        menu.setOnClickListener { v: View? -> showProfileMenu() }
        val title = LinearLayout(this)
        title.orientation = LinearLayout.VERTICAL
        title.setPadding(dp(12f), 0, 0, 0)
        title.addView(text("RUANG KARIER", 10, BLUE_DARK, true))
        title.addView(text("Profil saya", 22, TEXT, true))
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        content!!.addView(header)

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(18f), dp(20f), dp(18f), dp(20f))
        card.background = rounded(WHITE, 24)
        card.elevation = dp(3f).toFloat()
        val identity = row()
        identity.gravity = Gravity.CENTER_VERTICAL
        val avatarRing = FrameLayout(this)
        val ring = rounded(BLUE_LIGHT, 100)
        ring.setStroke(dp(2f), BLUE)
        avatarRing.background = ring
        avatarRing.setPadding(dp(4f), dp(4f), dp(4f), dp(4f))
        val avatarFrame = FrameLayout(this)
        avatarFrame.background = rounded(WHITE, 100)
        avatarFrame.clipToOutline = true
        avatarRing.addView(avatarFrame, FrameLayout.LayoutParams(-1, -1))
        val avatar = ImageView(this)
        avatar.setImageResource(R.drawable.ic_lk_person)
        avatar.scaleType = ImageView.ScaleType.CENTER_CROP
        avatarFrame.addView(avatar, FrameLayout.LayoutParams(-1, -1))
        avatarRing.contentDescription = "Kelola foto profil"
        avatarRing.setOnClickListener { v: View? -> showPhotoActions() }
        loadProfilePhoto(avatar)
        identity.addView(avatarRing, LinearLayout.LayoutParams(dp(78f), dp(78f)))
        val stats = row()
        stats.gravity = Gravity.CENTER
        val sp = LinearLayout.LayoutParams(0, -2, 1f)
        sp.leftMargin = dp(12f)
        identity.addView(stats, sp)
        val applicationsCount = addProfileStat(
            stats, "—", "Lamaran"
        ) { renderPage("Lamaran") }
        post(this, "profile/stats.php", HashMap<String, String>(), object : ApiClient.Result {
            override fun success(result: JSONObject) {
                applicationsCount.text = result.optInt("applications_count", 0).toString()
            }

            override fun fail(message: String) {
                applicationsCount.text = "—"
            }
        })
        addProfileStat(stats, favorites.size.toString(), "Favorit") { renderPage("Favorit") }
        card.addView(identity)
        var displayName = userPrefs!!.getString("nama", "")
        if (displayName == null || displayName.trim { it <= ' ' }.isEmpty()) displayName = username
        if (displayName == null || displayName.trim { it <= ' ' }.isEmpty()) displayName =
            "Pengguna LokerKu"
        val name = text(displayName, 20, TEXT, true)
        name.maxLines = 3
        val np = LinearLayout.LayoutParams(-1, -2)
        np.topMargin = dp(16f)
        card.addView(name, np)
        val handleValue = userPrefs!!.getString("username", "")
        val handle = text(if (handleValue == null || handleValue.trim { it <= ' ' }
                .isEmpty()) "Lengkapi nama pengguna" else "@$handleValue", 12, MUTED, false)
        val hp = LinearLayout.LayoutParams(-1, -2)
        hp.topMargin = dp(3f)
        card.addView(handle, hp)
        val note =
            text("Ruang untuk menunjukkan perjalanan dan pencapaian kariermu.", 12, MUTED, false)
        note.setLineSpacing(dp(2f).toFloat(), 1f)
        val n = LinearLayout.LayoutParams(-1, -2)
        n.topMargin = dp(10f)
        card.addView(note, n)
        val actions = row()
        val ap = LinearLayout.LayoutParams(-1, -2)
        ap.topMargin = dp(16f)
        card.addView(actions, ap)
        val edit = text("Edit profil", 13, WHITE, true)
        edit.gravity = Gravity.CENTER
        edit.background = gradient(BLUE_DARK, BLUE)
        edit.setOnClickListener { v: View? -> openProfileEditor() }
        edit.minHeight = dp(48f)
        edit.setPadding(dp(6f), dp(8f), dp(6f), dp(8f))
        actions.addView(edit, LinearLayout.LayoutParams(0, -2, 1f))
        val photo = text("Kelola foto", 13, BLUE_DARK, true)
        photo.gravity = Gravity.CENTER
        photo.background = rounded(BLUE_LIGHT, 16)
        photo.setOnClickListener { v: View? -> showPhotoActions() }
        val pp = LinearLayout.LayoutParams(0, -2, 1f)
        photo.minHeight = dp(48f)
        photo.setPadding(dp(6f), dp(8f), dp(6f), dp(8f))
        pp.leftMargin = dp(9f)
        actions.addView(photo, pp)
        content!!.addView(card)

        section("Galeri sertifikat", null, null)
        val galleryHead = row()
        galleryHead.gravity = Gravity.CENTER_VERTICAL
        val galleryInfo = text("Pencapaian publik", 12, MUTED, false)
        galleryHead.addView(galleryInfo, LinearLayout.LayoutParams(0, -2, 1f))
        val galleryAdd = text("+ Tambah / kelola", 12, BLUE_DARK, true)
        galleryAdd.setPadding(dp(10f), dp(10f), dp(10f), dp(10f))
        galleryAdd.background = rounded(BLUE_LIGHT, 14)
        galleryAdd.setOnClickListener { v: View? ->
            startActivity(
                Intent(
                    this,
                    CertificatesActivity::class.java
                )
            )
        }
        galleryHead.addView(galleryAdd)
        content!!.addView(galleryHead)
        val gallery = LinearLayout(this)
        gallery.orientation = LinearLayout.VERTICAL
        val galleryParams = LinearLayout.LayoutParams(-1, -2)
        galleryParams.topMargin = dp(10f)
        content!!.addView(gallery, galleryParams)
        show(this, gallery)
        section("Informasi akun", null, null)
        val details = LinearLayout(this)
        details.orientation = LinearLayout.VERTICAL
        details.setPadding(dp(18f), dp(5f), dp(18f), dp(5f))
        details.background = rounded(WHITE, 22)
        addProfileDetail(
            details,
            "Email",
            (if (email!!.isEmpty()) "Belum diisi" else email)!!,
            R.drawable.ic_lk_mail
        )
        addProfileDetail(
            details, "Nomor telepon",
            (if (phone!!.isEmpty()) "Belum diisi" else phone)!!, R.drawable.ic_lk_phone
        )
        val detailsParams = LinearLayout.LayoutParams(-1, -2)
        detailsParams.bottomMargin = dp(16f)
        content!!.addView(details, detailsParams)
        addInfoCard(
            "Preferensi pekerjaan", "Atur kategori lowongan sesuai minatmu.", "Atur preferensi"
        ) { this.editPreferences() }
    }

    private fun addProfileStat(
        parent: LinearLayout,
        value: String,
        label: String,
        action: Runnable
    ): TextView {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        val number = text(value, 19, TEXT, true)
        number.gravity = Gravity.CENTER
        col.addView(number)
        val caption = text(label, 11, MUTED, false)
        caption.gravity = Gravity.CENTER
        col.addView(caption)
        col.contentDescription = "$label: $value"
        col.setOnClickListener { v: View? -> action.run() }
        parent.addView(col, LinearLayout.LayoutParams(0, dp(60f), 1f))
        return number
    }

    private fun addProfileDetail(parent: LinearLayout, label: String, value: String, symbol: Int) {
        val item = row()
        item.gravity = Gravity.CENTER_VERTICAL
        item.setPadding(0, dp(12f), 0, dp(12f))
        val icon = ImageView(this)
        icon.setImageResource(symbol)
        icon.setColorFilter(BLUE_DARK)
        icon.setPadding(dp(9f), dp(9f), dp(9f), dp(9f))
        icon.background = rounded(BLUE_LIGHT, 12)
        item.addView(icon, LinearLayout.LayoutParams(dp(40f), dp(40f)))
        val texts = LinearLayout(this)
        texts.orientation = LinearLayout.VERTICAL
        texts.setPadding(dp(12f), 0, 0, 0)
        texts.addView(text(label, 11, MUTED, false))
        val valueView = text(value, 14, TEXT, true)
        valueView.maxLines = 2
        val valueParams = LinearLayout.LayoutParams(-1, -2)
        valueParams.topMargin = dp(3f)
        texts.addView(valueView, valueParams)
        item.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        parent.addView(item)
        if ("Email" == label) {
            val line = View(this)
            line.setBackgroundColor(BORDER)
            parent.addView(line, LinearLayout.LayoutParams(-1, dp(1f)))
        }
    }

    private fun showProfileMenu() {
        val dialog = Dialog(this)
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(16f), dp(26f), dp(16f), dp(18f))
        panel.setBackgroundColor(WHITE)

        val heading = row()
        heading.gravity = Gravity.CENTER_VERTICAL
        val mark = text("L", 20, WHITE, true)
        mark.gravity = Gravity.CENTER
        mark.background = gradient(BLUE_DARK, BLUE)
        heading.addView(mark, LinearLayout.LayoutParams(dp(42f), dp(42f)))
        val brand = text("Pusat akun", 18, TEXT, true)
        brand.setPadding(dp(10f), 0, 0, 0)
        heading.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val close = text("×", 26, MUTED, false)
        close.gravity = Gravity.CENTER
        close.contentDescription = "Tutup menu"
        heading.addView(close, LinearLayout.LayoutParams(dp(42f), dp(48f)))
        close.setOnClickListener { v: View? -> dialog.dismiss() }
        panel.addView(heading)
        val descriptor = text("AKUN & INFORMASI", 10, MUTED, true)
        descriptor.letterSpacing = .08f
        val descriptorParams = LinearLayout.LayoutParams(-1, -2)
        descriptorParams.topMargin = dp(24f)
        descriptorParams.bottomMargin = dp(8f)
        panel.addView(descriptor, descriptorParams)

        val scroll = ScrollView(this)
        scroll.isFillViewport = false
        scroll.isVerticalScrollBarEnabled = false
        val items = LinearLayout(this)
        items.orientation = LinearLayout.VERTICAL
        scroll.addView(items)
        panel.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        addMenuOption(
            items,
            dialog,
            "Profil dan data pribadi",
            "Lihat dan ubah profil",
            R.drawable.ic_lk_person
        ) { this.openProfileEditor() }
        addMenuOption(
            items,
            dialog,
            "Pusat akun",
            "Keamanan dan pengelolaan akun",
            R.drawable.ic_lk_shield_check
        ) {
            startActivity(
                Intent(
                    this,
                    AccountCenterActivity::class.java
                )
            )
        }
        addMenuOption(
            items, dialog, "Sertifikat publik", "Kelola pencapaian", R.drawable.ic_lk_info_outline
        ) {
            startActivity(
                Intent(
                    this,
                    CertificatesActivity::class.java
                )
            )
        }
        addMenuOption(
            items, dialog, "Pusat bantuan", "Panduan aplikasi", R.drawable.ic_lk_help
        ) {
            showMessage(
                "Pusat bantuan",
                "Gunakan Beranda dan Eksplorasi untuk menemukan lowongan, Favorit untuk menyimpan pekerjaan, dan halaman Profil untuk mengelola data akun. Jika membutuhkan bantuan lebih lanjut, hubungi pengelola aplikasi."
            )
        }
        addMenuOption(
            items, dialog, "Tentang LokerKu", "Informasi aplikasi", R.drawable.ic_lk_info_outline
        ) {
            showMessage(
                "Tentang LokerKu",
                "LokerKu membantu kamu menemukan lowongan pekerjaan, menyimpan pekerjaan favorit, dan mempersiapkan karier."
            )
        }
        addMenuOption(
            panel, dialog, "Keluar akun", "Akhiri sesi", R.drawable.ic_logout
        ) { this.logout() }
        dialog.setContentView(panel)
        UiMotion.bindActions(panel)
        if (dialog.window != null) {
            dialog.window!!.setGravity(Gravity.LEFT or Gravity.TOP)
            dialog.window!!.setWindowAnimations(R.style.LokerkuDrawerAnimations)
        }
        dialog.show()
        val window = dialog.window
        if (window != null) {
            window.setBackgroundDrawableResource(android.R.color.transparent)
            window.setGravity(Gravity.LEFT or Gravity.TOP)
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            val attrs = window.attributes
            attrs.dimAmount = .48f
            window.attributes = attrs
            window.setWindowAnimations(R.style.LokerkuDrawerAnimations)
            window.setLayout(
                min(
                    (resources.displayMetrics.widthPixels * .60f).toInt().toDouble(),
                    dp(310f).toDouble()
                )
                    .toInt(), ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        UiMotion.revealChildren(items, 80, 70, 3)
    }

    private fun addMenuOption(
        panel: LinearLayout,
        dialog: Dialog,
        title: String,
        description: String,
        symbol: Int,
        action: Runnable
    ) {
        val item = row()
        item.gravity = Gravity.CENTER_VERTICAL
        item.setPadding(dp(10f), dp(10f), dp(8f), dp(10f))
        item.background = rounded(BACKGROUND, 16)
        val icon = ImageView(this)
        icon.setImageResource(symbol)
        icon.setColorFilter(BLUE_DARK)
        icon.setPadding(dp(10f), dp(10f), dp(10f), dp(10f))
        icon.background = rounded(BLUE_LIGHT, 12)
        item.addView(icon, LinearLayout.LayoutParams(dp(42f), dp(42f)))
        val copy = LinearLayout(this)
        copy.orientation = LinearLayout.VERTICAL
        copy.setPadding(dp(10f), 0, 0, 0)
        copy.addView(text(title, 13, TEXT, true))
        val sub = text(description, 10, MUTED, false)
        sub.maxLines = 2
        copy.addView(sub)
        item.addView(copy, LinearLayout.LayoutParams(0, -2, 1f))
        val itemParams = LinearLayout.LayoutParams(-1, -2)
        itemParams.topMargin = dp(8f)
        panel.addView(item, itemParams)
        item.setOnClickListener { v: View? ->
            dialog.dismiss()
            action.run()
        }
    }

    private fun openProfileEditor() {
        val intent = Intent(
            this,
            ProfileActivity::class.java
        )
        startActivity(intent)
    }

    private fun showPhotoActions() {
        val options = arrayOf("Ganti / unggah foto", "Hapus foto profil", "Batal")
        PremiumDialog.Builder(this)
            .setTitle("Foto profil")
            .setItems(
                options
            ) { dialog: DialogInterface?, which: Int ->
                if (which == 0) {
                    openProfileEditor()
                } else if (which == 1) {
                    post(
                        this,
                        "auth/delete_photo.php",
                        HashMap(),
                        object : ApiClient.Result {
                            override fun success(json: JSONObject) {
                                userPrefs!!.edit().remove("foto").apply()
                                renderPage("Profil")
                                toast("Foto profil dihapus.")
                            }

                            override fun fail(message: String) {
                                toast(message)
                            }
                        })
                }
            }
            .show()
    }

    private fun loadProfilePhoto(avatar: ImageView) {
        val photo = userPrefs!!.getString("foto", "")
        if (photo == null || photo.trim { it <= ' ' }.isEmpty()) return
        if (photo.startsWith("https://") || photo.startsWith("http://")) {
            val request = ImageRequest(
                photo,
                { bitmap: Bitmap? -> avatar.setImageBitmap(bitmap) },
                256,
                256,
                ImageView.ScaleType.CENTER_CROP,
                Bitmap.Config.RGB_565,
                { error: VolleyError? -> }
            )
            Volley.newRequestQueue(applicationContext).add(request)
        } else {
            try {
                avatar.setImageURI(Uri.parse(photo))
            } catch (ignored: Exception) {
            }
        }
    }

    private fun editProfile() {
        val form = LinearLayout(this)
        form.orientation = LinearLayout.VERTICAL
        form.setPadding(dp(4f), dp(5f), dp(4f), dp(4f))

        val nameInput = createInput("Nama pengguna")
        nameInput.setText(username)

        val emailInput = createInput("Email")
        emailInput.inputType = (InputType.TYPE_CLASS_TEXT
                or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
        emailInput.setText(email)

        val phoneInput = createInput("Nomor HP")
        phoneInput.inputType = InputType.TYPE_CLASS_PHONE
        phoneInput.setText(phone)

        form.addView(nameInput)
        form.addView(emailInput)
        form.addView(phoneInput)

        PremiumDialog.Builder(this)
            .setTitle("Edit profil")
            .setView(form)
            .setNegativeButton("Batal", null)
            .setPositiveButton("Simpan") { dialog: DialogInterface?, which: Int ->
                val newName = nameInput.text
                    .toString().trim { it <= ' ' }
                if (newName.isEmpty()) {
                    toast("Nama tidak boleh kosong")
                    return@setPositiveButton
                }

                username = newName
                email = emailInput.text
                    .toString().trim { it <= ' ' }
                phone = phoneInput.text
                    .toString().trim { it <= ' ' }

                userPrefs!!.edit()
                    .putString("username", username)
                    .putString("nama", username)
                    .putString("email", email)
                    .putString("phone", phone)
                    .putString("no_hp", phone)
                    .apply()

                renderPage("Profil")
                toast("Profil disimpan di perangkat")
            }
            .show()
    }

    private fun editPreferences() {
        val options = arrayOf(
            "Semua",
            "IT & Software",
            "Administrasi",
            "Marketing",
            "Keuangan",
            "Desain",
            "Pendidikan",
            "Kesehatan",
            "Customer Service"
        )

        PremiumDialog.Builder(this)
            .setTitle("Preferensi pekerjaan")
            .setSingleChoiceItems(
                options,
                max(0, Arrays.asList(*options).indexOf(selectedCategory)),
                DialogInterface.OnClickListener { dialog: DialogInterface, which: Int ->
                    selectedCategory =
                        options[which]
                    userPrefs!!.edit()
                        .putString(
                            "category",
                            selectedCategory
                        )
                        .apply()

                    dialog.dismiss()
                    renderPage("Eksplorasi")
                }
            )
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun followUpNote() {
        val input = createInput("Tulis catatan tindak lanjut")
        input.isSingleLine = false
        input.minLines = 3
        input.gravity = Gravity.TOP or Gravity.START
        val noteForm = LinearLayout(this)
        noteForm.orientation = LinearLayout.VERTICAL
        noteForm.setPadding(dp(20f), dp(6f), dp(20f), dp(4f))
        noteForm.addView(input, LinearLayout.LayoutParams(-1, dp(110f)))

        PremiumDialog.Builder(this)
            .setTitle("Catatan tindak lanjut")
            .setMessage("Catatan ini disimpan di perangkatmu.")
            .setView(noteForm)
            .setNegativeButton("Batal", null)
            .setPositiveButton("Simpan") { dialog: DialogInterface?, which: Int ->
                val note = input.text.toString().trim { it <= ' ' }
                if (note.isEmpty()) {
                    toast("Catatan masih kosong")
                    return@setPositiveButton
                }

                val notes = getSharedPreferences(
                    "lokerku_notes_" + userPrefs!!.getInt("id", 0), MODE_PRIVATE
                )

                val oldNotes = notes.getString("notes", "")

                val updated = if (oldNotes!!.isEmpty())
                    note
                else
                    """
                    $oldNotes
                    
                    $note
                    """.trimIndent()

                notes.edit().putString("notes", updated).apply()
                toast("Catatan tersimpan di perangkat")
            }
            .show()
    }

    private fun logout() {
        PremiumDialog.Builder(this)
            .setTitle("Keluar akun")
            .setMessage("Apakah kamu yakin ingin keluar dari LokerKu?")
            .setNegativeButton("Batal", null)
            .setPositiveButton("Keluar") { dialog: DialogInterface?, which: Int ->
                post(
                    this,
                    "auth/logout.php",
                    HashMap(),
                    object : ApiClient.Result {
                        override fun success(ignored: JSONObject) {}
                        override fun fail(ignored: String) {}
                    })
                SessionStore.clear(this)
                userPrefs!!.edit().clear().apply()
                val login = Intent(this, LoginActivity::class.java)
                login.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                startActivity(login)
                finish()
            }
            .show()
    }

    private fun loadJobs() {
        if (isLoading) return

        isLoading = true

        val request = StringRequest(
            Request.Method.GET,
            API_JOBS,
            Response.Listener { response: String? ->
                isLoading = false
                try {
                    val result = JSONObject(response)

                    if (!result.optBoolean("success", false)) {
                        toast(
                            result.optString(
                                "message",
                                "Data lowongan gagal dimuat"
                            )
                        )

                        renderPage(currentPage)
                        return@Listener
                    }

                    var data = result.optJSONArray("data")

                    if (data == null) {
                        val nested = result.optJSONObject("data")

                        if (nested != null) {
                            data = nested.optJSONArray("jobs")
                        }
                    }

                    jobs.clear()

                    if (data != null) {
                        for (i in 0 until data.length()) {
                            val item = data.optJSONObject(i)

                            if (item != null) {
                                jobs.add(item)
                            }
                        }
                    }

                    renderPage(currentPage)
                } catch (e: Exception) {
                    renderPage(currentPage)
                    toast("Format respons API tidak sesuai")
                }
            }
        ) { error: VolleyError? ->
            isLoading = false
            renderPage(currentPage)
            toast("Koneksi lowongan gagal. Periksa internet dan API.")
        }

        request.setShouldCache(false)

        request.setRetryPolicy(
            DefaultRetryPolicy(
                15000,
                1,
                1.0f
            )
        )

        Volley.newRequestQueue(applicationContext).add(request)
    }

    private fun showJobDetail(job: JSONObject) {
        val intent = Intent(
            this,
            JobDetailActivity::class.java
        )
        intent.putExtra("job_json", job.toString())
        startActivity(intent)
        overridePendingTransition(R.anim.screen_enter, R.anim.screen_exit)
    }

    private fun addPageIntro(eyebrow: String, title: String, description: String) {
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(20f), dp(20f), dp(20f), dp(19f))
        var introStart = -0xffff34
        var introEnd = -0xd9d301
        if ("EKSPLORASI" == eyebrow) {
            introStart = -0xeed599
            introEnd = -0xd79b19
        } else if ("FAVORIT" == eyebrow) {
            introStart = -0xdbdf8f
            introEnd = -0xa6ae26
        } else if ("LAMARAN" == eyebrow) {
            introStart = -0xe9c9a9
            introEnd = -0xe58d37
        }
        panel.background = gradient(introStart, introEnd)
        val label = text("$eyebrow  /  LOKERKU", 10, Color.rgb(213, 224, 255), true)
        label.letterSpacing = 0.08f
        panel.addView(label)
        val heading = text(title, 22, WHITE, true)
        val hp = LinearLayout.LayoutParams(-1, -2)
        hp.topMargin = dp(8f)
        panel.addView(heading, hp)
        val detail = text(description, 12, Color.rgb(231, 235, 255), false)
        detail.setLineSpacing(dp(2f).toFloat(), 1f)
        val detailParams = LinearLayout.LayoutParams(-1, -2)
        detailParams.topMargin = dp(7f)
        panel.addView(detail, detailParams)
        val outer = LinearLayout.LayoutParams(-1, -2)
        outer.bottomMargin = dp(18f)
        content!!.addView(panel, outer)
    }

    private fun addInfoCard(
        title: String,
        description: String,
        actionLabel: String,
        action: Runnable
    ) {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(
            dp(16f), dp(15f), dp(16f), dp(15f)
        )
        card.background = rounded(WHITE, 18)
        card.elevation = dp(2f).toFloat()

        val params =
            LinearLayout.LayoutParams(-1, -2)

        params.setMargins(0, 0, 0, dp(11f))
        card.layoutParams = params

        card.addView(text(title, 14, TEXT, true))

        val descriptionView = text(
            description, 11, MUTED, false
        )

        val descriptionParams =
            LinearLayout.LayoutParams(-1, -2)

        descriptionParams.topMargin = dp(5f)
        card.addView(descriptionView, descriptionParams)

        val actionView = text(
            "$actionLabel  →", 12, BLUE, true
        )

        val actionParams =
            LinearLayout.LayoutParams(-1, -2)

        actionParams.topMargin = dp(10f)
        card.addView(actionView, actionParams)

        card.setOnClickListener { v: View? -> action.run() }

        content!!.addView(card)
    }

    private fun section(
        title: String,
        actionLabel: String?,
        action: Runnable?
    ) {
        val header = row()
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(0, dp(20f), 0, dp(12f))

        val titleView = text(title, 16, TEXT, true)

        header.addView(
            titleView,
            LinearLayout.LayoutParams(0, -2, 1f)
        )

        if (actionLabel != null && action != null) {
            val actionView = text(
                actionLabel, 11, BLUE, true
            )

            header.addView(actionView)
            actionView.setOnClickListener { v: View? -> action.run() }
        }

        content!!.addView(header)
    }

    private fun addText(
        value: String,
        size: Int,
        color: Int,
        bold: Boolean
    ) {
        val view = text(value, size, color, bold)

        val params =
            LinearLayout.LayoutParams(-1, -2)

        params.bottomMargin = dp(5f)

        content!!.addView(view, params)
    }

    private fun chip(label: String): TextView {
        val view = text(label, 10, BLUE, true)
        view.gravity = Gravity.CENTER
        view.setPadding(
            dp(11f), dp(8f), dp(11f), dp(8f)
        )
        view.background = rounded(BLUE_LIGHT, 20)

        val params =
            LinearLayout.LayoutParams(-2, -2)

        params.setMargins(0, 0, dp(7f), 0)
        view.layoutParams = params

        return view
    }

    private fun createInput(hint: String): EditText {
        val input = EditText(this)

        input.hint = hint
        input.isSingleLine = true
        input.textSize = 13f
        input.setTextColor(TEXT)
        input.setHintTextColor(MUTED)
        input.typeface = regular(this)
        input.setPadding(
            dp(12f), dp(8f), dp(12f), dp(8f)
        )
        input.background = rounded(BACKGROUND, 12)

        val params =
            LinearLayout.LayoutParams(-1, -2)
        input.minHeight = dp(48f)

        params.setMargins(0, dp(5f), 0, dp(7f))
        input.layoutParams = params

        return input
    }

    private fun text(
        value: String,
        size: Int,
        color: Int,
        bold: Boolean
    ): TextView {
        val view = TextView(this)

        view.text = value
        view.textSize = size.toFloat()
        view.setTextColor(color)
        view.includeFontPadding = false
        view.typeface = if (bold)
            semibold(this)
        else
            regular(this)

        return view
    }

    private fun row(): LinearLayout {
        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.HORIZONTAL
        layout.gravity = Gravity.CENTER_VERTICAL
        return layout
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable {
        val drawable = GradientDrawable()
        drawable.setColor(color)
        if (color == WHITE) drawable.setStroke(dp(1f), BORDER)
        drawable.cornerRadius = dp(radius.toFloat()).toFloat()
        return drawable
    }

    private fun gradient(start: Int, end: Int): GradientDrawable {
        val drawable = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(start, end)
        )

        drawable.cornerRadius = dp(22f).toFloat()
        return drawable
    }

    private fun dp(value: Float): Int {
        return (value * resources
            .displayMetrics.density + 0.5f
                ).toInt()
    }

    private fun initials(name: String?): String {
        if (name == null || name.trim { it <= ' ' }.isEmpty()) {
            return "LK"
        }

        val parts = name.trim { it <= ' ' }.split("\\s+".toRegex()).dropLastWhile { it.isEmpty() }
            .toTypedArray()

        if (parts.size == 1) {
            return parts[0].substring(
                0, min(2.0, parts[0].length.toDouble()).toInt()
            ).uppercase()
        }

        return (parts[0].substring(0, 1)
                + parts[1].substring(0, 1)
                ).uppercase()
    }

    private fun formatSalary(minimum: String?, maximum: String?): String {
        if ((minimum == null || minimum.isEmpty())
            && (maximum == null || maximum.isEmpty())
        ) {
            return ""
        }

        try {
            val min = if (minimum == null || minimum.isEmpty())
                0
            else minimum.toLong()

            val max = if (maximum == null || maximum.isEmpty())
                0
            else maximum.toLong()

            if (min > 0 && max > 0) {
                return "Rp " + String.format(
                    Locale.US, "%,d", min
                ).replace(',', '.') + " - Rp " + String.format(
                    Locale.US, "%,d", max
                ).replace(',', '.')
            }

            val value = if (min > 0) min else max

            return "Mulai Rp " + String.format(
                Locale.US, "%,d", value
            ).replace(',', '.')
        } catch (e: Exception) {
            return ""
        }
    }

    private fun showNotificationsDialog() {
        val dialog = Dialog(this)

        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.background = rounded(WHITE, 26)
        panel.clipToOutline = true

        // Header premium dengan gradasi biru khas LokerKu.
        val hero = LinearLayout(this)
        hero.orientation = LinearLayout.VERTICAL
        hero.setPadding(dp(22f), dp(22f), dp(22f), dp(22f))
        hero.background = gradient(BLUE_DARK, BLUE)

        val heroTop = row()
        val bellBubble = FrameLayout(this)
        bellBubble.background = rounded(Color.rgb(66, 66, 255), 16)
        val bell = ImageView(this)
        bell.setImageResource(R.drawable.ic_notifications)
        bell.setColorFilter(WHITE)
        bell.scaleType = ImageView.ScaleType.FIT_CENTER
        val bellParams = FrameLayout.LayoutParams(
            dp(25f), dp(25f), Gravity.CENTER
        )
        bellBubble.addView(bell, bellParams)
        heroTop.addView(bellBubble, LinearLayout.LayoutParams(dp(48f), dp(48f)))

        val titleBlock = LinearLayout(this)
        titleBlock.orientation = LinearLayout.VERTICAL
        titleBlock.setPadding(dp(12f), 0, 0, 0)
        titleBlock.addView(text("Notifikasi", 21, WHITE, true))
        val subtitle = text(
            "Pusat informasi aktivitasmu", 12,
            Color.rgb(224, 229, 255), false
        )
        val subtitleParams = LinearLayout.LayoutParams(-2, -2)
        subtitleParams.topMargin = dp(5f)
        titleBlock.addView(subtitle, subtitleParams)
        heroTop.addView(titleBlock, LinearLayout.LayoutParams(0, -2, 1f))

        val close = text("×", 28, WHITE, false)
        close.gravity = Gravity.CENTER
        close.background = rounded(Color.rgb(66, 66, 255), 13)
        heroTop.addView(close, LinearLayout.LayoutParams(dp(38f), dp(38f)))
        close.setOnClickListener { v: View? -> dialog.dismiss() }
        hero.addView(heroTop)

        val overview = text(
            "Semua informasi penting LokerKu akan tampil di sini.",
            13, Color.rgb(235, 238, 255), false
        )
        val overviewParams = LinearLayout.LayoutParams(-1, -2)
        overviewParams.topMargin = dp(18f)
        hero.addView(overview, overviewParams)
        panel.addView(hero)

        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(dp(18f), dp(18f), dp(18f), dp(20f))
        body.addView(text("Pembaruan terbaru", 16, TEXT, true))

        addNotificationItem(
            body, "✦", "Rekomendasi pekerjaan",
            "Jelajahi lowongan yang sesuai dengan minat dan kategori pilihanmu.",
            Color.rgb(235, 239, 255)
        )
        addNotificationItem(
            body, "✓", "Aktivitas lamaran",
            "Pantau proses rekrutmen dari halaman Lamaran saya.",
            Color.rgb(230, 248, 240)
        )
        addNotificationItem(
            body, "♥", "Pekerjaan favorit",
            "Simpan lowongan dengan ikon hati agar mudah ditemukan kembali.",
            Color.rgb(255, 238, 242)
        )

        val note = text(
            "Belum ada notifikasi baru dari server.",
            12, MUTED, false
        )
        note.gravity = Gravity.CENTER
        note.setPadding(0, dp(8f), 0, dp(14f))
        body.addView(note)

        val explore = text("Jelajahi Lowongan  →", 14, WHITE, true)
        explore.gravity = Gravity.CENTER
        explore.setPadding(dp(14f), dp(15f), dp(14f), dp(15f))
        explore.background = rounded(BLUE, 15)
        body.addView(explore, LinearLayout.LayoutParams(-1, -2))
        explore.setOnClickListener { v: View? ->
            dialog.dismiss()
            renderPage("Eksplorasi")
        }

        panel.addView(body)
        val panelScroll = ScrollView(this)
        panelScroll.addView(panel)
        dialog.setContentView(panelScroll)
        if (dialog.window != null) {
            dialog.window!!.setBackgroundDrawableResource(android.R.color.transparent)
            dialog.window!!.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        UiMotion.styleButtons(panel)
        UiMotion.bindActions(panel)
        dialog.show()
        UiMotion.revealChildren(body, 40, 65, 6)
        if (dialog.window != null) {
            dialog.window!!.setBackgroundDrawableResource(android.R.color.transparent)
            dialog.window!!.setLayout(
                resources.displayMetrics.widthPixels - dp(32f),
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
    }

    private fun addNotificationItem(
        parent: LinearLayout,
        symbol: String,
        title: String,
        description: String,
        iconBackground: Int
    ) {
        val item = row()
        item.gravity = Gravity.TOP
        item.setPadding(dp(12f), dp(13f), dp(12f), dp(13f))
        item.background = rounded(BACKGROUND, 17)

        if ("♥" == symbol || "♡" == symbol) {
            val icon = ImageView(this)
            icon.setImageResource(R.drawable.ic_favorite)
            icon.setColorFilter(BLUE)
            icon.scaleType = ImageView.ScaleType.CENTER_INSIDE
            icon.setPadding(dp(11f), dp(11f), dp(11f), dp(11f))
            icon.background = rounded(iconBackground, 13)
            item.addView(icon, LinearLayout.LayoutParams(dp(42f), dp(42f)))
        } else {
            val icon = text(symbol, 19, BLUE, true)
            icon.gravity = Gravity.CENTER
            icon.background = rounded(iconBackground, 13)
            item.addView(icon, LinearLayout.LayoutParams(dp(42f), dp(42f)))
        }

        val words = LinearLayout(this)
        words.orientation = LinearLayout.VERTICAL
        words.setPadding(dp(11f), 0, 0, 0)
        words.addView(text(title, 13, TEXT, true))
        val detail = text(description, 11, MUTED, false)
        detail.setLineSpacing(dp(2f).toFloat(), 1f)
        val detailParams = LinearLayout.LayoutParams(-1, -2)
        detailParams.topMargin = dp(5f)
        words.addView(detail, detailParams)
        item.addView(words, LinearLayout.LayoutParams(0, -2, 1f))

        val itemParams = LinearLayout.LayoutParams(-1, -2)
        itemParams.topMargin = dp(11f)
        parent.addView(item, itemParams)
    }

    private fun showMessage(title: String, message: String) {
        val dialog = Dialog(this)
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(22f), dp(22f), dp(22f), dp(20f))
        panel.background = rounded(WHITE, 24)
        val icon = ImageView(this)
        icon.setImageResource(R.drawable.ic_lk_info_outline)
        icon.setPadding(dp(11f), dp(11f), dp(11f), dp(11f))
        icon.background = rounded(BLUE_LIGHT, 16)
        panel.addView(icon, LinearLayout.LayoutParams(dp(48f), dp(48f)))
        val heading = text(title, 20, TEXT, true)
        val hp = LinearLayout.LayoutParams(-1, -2)
        hp.topMargin = dp(15f)
        panel.addView(heading, hp)
        val body = text(message, 14, MUTED, false)
        body.setLineSpacing(dp(4f).toFloat(), 1f)
        val bp = LinearLayout.LayoutParams(-1, -2)
        bp.topMargin = dp(10f)
        panel.addView(body, bp)
        val ok = text("Mengerti", 14, WHITE, true)
        ok.gravity = Gravity.CENTER
        ok.background = rounded(BLUE, 15)
        ok.setOnClickListener { v: View? -> dialog.dismiss() }
        val op = LinearLayout.LayoutParams(-1, dp(50f))
        op.topMargin = dp(20f)
        panel.addView(ok, op)
        val scroll = ScrollView(this)
        scroll.addView(panel)
        dialog.setContentView(scroll)
        dialog.show()
        if (dialog.window != null) {
            dialog.window!!.setBackgroundDrawableResource(android.R.color.transparent)
            dialog.window!!.setLayout(
                min(
                    (resources.displayMetrics.widthPixels - dp(36f)).toDouble(),
                    dp(400f).toDouble()
                )
                    .toInt(), -2
            )
        }
        UiMotion.bindActions(panel)
        UiMotion.revealChildren(panel, 40, 60, 4)
    }

    private fun toast(message: String) {
        Toast.makeText(
            this,
            message,
            Toast.LENGTH_SHORT
        ).show()
    }

    companion object {
        private const val API_JOBS = "https://ahannaja.cu.ma/lokerku_api/jobs/list.php"

        private const val PREF_USER = "lokerku_user"
        private const val PREF_FAVORITES = "lokerku_favorites"
        private const val KEY_FAVORITES = "job_ids"

        private val BLUE = Color.rgb(0, 0, 255)
        private val BLUE_DARK = Color.rgb(0, 0, 204)
        private val BLUE_LIGHT = Color.rgb(232, 232, 255)
        private val BACKGROUND = Color.rgb(247, 248, 255)
        private const val WHITE = Color.WHITE
        private val TEXT = Color.rgb(27, 39, 61)
        private val MUTED = Color.rgb(104, 112, 143)
        private val BORDER = Color.rgb(221, 224, 255)
        private val RED = Color.rgb(220, 65, 80)
        private val GREEN = Color.rgb(28, 150, 100)
    }
}
