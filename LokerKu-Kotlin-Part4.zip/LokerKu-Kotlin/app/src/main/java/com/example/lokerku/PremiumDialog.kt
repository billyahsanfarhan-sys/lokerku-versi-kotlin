package com.example.lokerku

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog
import com.example.lokerku.AppFont.semibold
import com.example.lokerku.FontEnforcer.apply
import kotlin.math.min

/** Shared light surfaces for LokerKu-owned confirmation and form dialogs.  */
object PremiumDialog {
    private fun dp(c: Context, v: Float): Int {
        return (v * c.resources.displayMetrics.density + .5f).toInt()
    }

    private fun rounded(c: Context, color: Int, radius: Int, stroke: Int): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = dp(c, radius.toFloat()).toFloat()
        if (stroke != 0) d.setStroke(dp(c, 1f), stroke)
        return d
    }

    private fun styleFields(view: View, c: Context) {
        if (view is EditText) {
            val field = view
            field.setTextColor(-0xe7dec3)
            field.setHintTextColor(-0x877c65)
            field.backgroundTintList = null
            field.background = rounded(c, -0xa0801, 14, -0x231c06)
            field.setPadding(dp(c, 14f), dp(c, 12f), dp(c, 14f), dp(c, 12f))
            field.minHeight = dp(c, 52f)
        }
        if (view is ViewGroup) {
            val group = view
            for (i in 0 until group.childCount) styleFields(group.getChildAt(i), c)
        }
    }

    private fun arrangeButtons(dialog: AlertDialog, c: Context) {
        val positive = dialog.getButton(AlertDialog.BUTTON_POSITIVE)
        val negative = dialog.getButton(AlertDialog.BUTTON_NEGATIVE)
        val neutral = dialog.getButton(AlertDialog.BUTTON_NEUTRAL)
        val first = if (positive != null && positive.parent != null) positive else negative
        if (first == null || first.parent !is ViewGroup) return
        val old = first.parent as ViewGroup
        if (old.parent !is ViewGroup) return
        val host = old.parent as ViewGroup
        val index = host.indexOfChild(old)
        val existing = old.layoutParams
        val column = LinearLayout(c)
        column.orientation = LinearLayout.VERTICAL
        column.setPadding(dp(c, 20f), dp(c, 8f), dp(c, 20f), dp(c, 20f))
        val order = arrayOf(positive, neutral, negative)
        for (b in order) if (b != null && b.visibility == View.VISIBLE) {
            if (b.parent is ViewGroup) (b.parent as ViewGroup).removeView(b)
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.topMargin = dp(c, 8f)
            column.addView(b, lp)
        }
        host.removeViewAt(index)
        host.addView(column, index, existing)
    }

    private fun styleButton(button: Button?, primary: Boolean, c: Context) {
        if (button == null) return
        button.isAllCaps = false
        button.isSingleLine = false
        button.maxLines = 2
        button.letterSpacing = 0f
        button.setTextColor(if (primary) Color.WHITE else -0xcec22f)
        button.typeface = semibold(c)
        button.textSize = 13f
        button.minHeight = dp(c, 48f)
        button.setPadding(dp(c, 16f), dp(c, 8f), dp(c, 16f), dp(c, 8f))
        button.backgroundTintList = null
        button.elevation = 0f
        button.stateListAnimator = null
        val bg = rounded(c, if (primary) -0xcfc215 else -0x110e01, 14, 0)
        button.background = RippleDrawable(
            ColorStateList.valueOf(if (primary) 0x33ffffff else 0x22303deb),
            bg,
            null
        )
        UiMotion.bindPress(button)
    }

    class Builder(private val source: Context) :
        AlertDialog.Builder(source, R.style.LokerkuPremiumDialog) {
        override fun show(): AlertDialog {
            val dialog = super.show()
            val window = dialog.window
            if (window != null) {
                window.setWindowAnimations(R.style.LokerkuPremiumDialogAnimation)
                val decor = window.decorView
                styleFields(decor, source)
                apply(decor, source)
            }
            styleButton(dialog.getButton(AlertDialog.BUTTON_NEGATIVE), false, source)
            styleButton(dialog.getButton(AlertDialog.BUTTON_NEUTRAL), false, source)
            styleButton(dialog.getButton(AlertDialog.BUTTON_POSITIVE), true, source)
            arrangeButtons(dialog, source)
            window?.setLayout(
                min(
                    (source.resources.displayMetrics.widthPixels - dp(
                        source,
                        32f
                    )).toDouble(),
                    dp(source, 440f).toDouble()
                ).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT
            )
            return dialog
        }
    }
}
