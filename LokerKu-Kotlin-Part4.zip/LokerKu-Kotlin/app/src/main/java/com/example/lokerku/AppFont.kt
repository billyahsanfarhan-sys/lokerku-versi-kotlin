package com.example.lokerku

import android.content.Context
import android.graphics.Typeface
import androidx.core.content.res.ResourcesCompat

object AppFont {
    @JvmStatic
    fun regular(context: Context): Typeface {
        val font = ResourcesCompat.getFont(
            context,
            R.font.poppins_regular
        )

        checkNotNull(font) { "Font Poppins Regular tidak ditemukan" }

        return font
    }

    @JvmStatic
    fun semibold(context: Context): Typeface {
        val font = ResourcesCompat.getFont(
            context,
            R.font.poppins_semibold
        )

        checkNotNull(font) { "Font Poppins SemiBold tidak ditemukan" }

        return font
    }
}