package com.example.lokerku

import android.content.DialogInterface
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts.GetContent
import androidx.activity.result.ActivityResultLauncher
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.AuthFailureError
import com.android.volley.DefaultRetryPolicy
import com.android.volley.NetworkResponse
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.HttpHeaderParser
import com.android.volley.toolbox.ImageRequest
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.lokerku.ApiClient.post
import com.example.lokerku.AppFont.regular
import com.example.lokerku.AppFont.semibold
import com.example.lokerku.FontEnforcer.apply
import com.example.lokerku.LoginActivity
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.nio.charset.StandardCharsets
import kotlin.math.max
import kotlin.math.min

class ProfileActivity : AppCompatActivity() {
    private var pref: SharedPreferences? = null
    private var queue: RequestQueue? = null
    private var imgFoto: ImageView? = null
    private var etNama: EditText? = null
    private var etUsername: EditText? = null
    private var etEmail: EditText? = null
    private var etNoHp: EditText? = null
    private var etLokasi: EditText? = null
    private var etHeadline: EditText? = null
    private var etBio: EditText? = null
    private var etLinkedin: EditText? = null
    private var etPortfolio: EditText? = null
    private var btnFoto: Button? = null
    private var btnHapusFoto: Button? = null
    private var btnSimpan: Button? = null
    private var btnKeluar: Button? = null
    private var fotoTerpilih: Uri? = null
    private var pilihFoto: ActivityResultLauncher<String>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        if (Build.VERSION.SDK_INT >= 23) {
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                    or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        }
        pref = getSharedPreferences("lokerku_user", MODE_PRIVATE)
        queue = Volley.newRequestQueue(applicationContext)

        buatTampilan()
        isiProfil()
        etEmail!!.isEnabled = false // Email changes require ownership verification.

        pilihFoto = registerForActivityResult<String, Uri>(
            GetContent()
        ) { uri: Uri? ->
            if (uri == null) return@registerForActivityResult
            try {
                val bitmap = decodeBounded(uri, 1024)
                if (bitmap != null) {
                    fotoTerpilih = uri
                    imgFoto!!.setImageBitmap(bitmap)
                } else Toast.makeText(
                    this,
                    "Foto tidak dapat dibuka",
                    Toast.LENGTH_SHORT
                ).show()
            } catch (e: Exception) {
                Toast.makeText(
                    this,
                    "Foto gagal dibuka",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        btnFoto!!.setOnClickListener { v: View? -> pilihFoto!!.launch("image/*") }
        btnHapusFoto!!.setOnClickListener { v: View? ->
            PremiumDialog.Builder(this)
                .setTitle("Hapus foto profil?").setMessage("Foto profil akan dihapus dari server.")
                .setNegativeButton("Batal", null).setPositiveButton(
                    "Hapus Foto"
                ) { dialog: DialogInterface?, which: Int ->
                    post(
                        this,
                        "auth/delete_photo.php",
                        HashMap(),
                        object : ApiClient.Result {
                            override fun success(json: JSONObject) {
                                fotoTerpilih = null
                                pref!!.edit().remove("foto").apply()
                                imgFoto!!.setImageResource(R.drawable.ic_lk_person)
                                Toast.makeText(
                                    this@ProfileActivity,
                                    "Foto dihapus",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }

                            override fun fail(message: String) {
                                Toast.makeText(
                                    this@ProfileActivity,
                                    message,
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        })
                }.show()
        }
        btnSimpan!!.setOnClickListener { v: View? -> simpanProfil() }
        btnKeluar!!.setOnClickListener { v: View? ->
            PremiumDialog.Builder(this)
                .setTitle("Keluar dari LokerKu?")
                .setMessage("Kamu perlu login kembali untuk membuka akun ini.")
                .setNegativeButton("Batal", null)
                .setPositiveButton("Keluar") { d: DialogInterface?, w: Int ->
                    post(
                        this@ProfileActivity,
                        "auth/logout.php",
                        HashMap(),
                        object : ApiClient.Result {
                            override fun success(ignored: JSONObject) {}
                            override fun fail(ignored: String) {}
                        })
                    SessionStore.clear(this@ProfileActivity)
                    pref!!.edit().clear().apply()
                    val intent = Intent(
                        this@ProfileActivity,
                        LoginActivity::class.java
                    )
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                    startActivity(intent)
                    finish()
                }.show()
        }
    }

    private fun buatTampilan() {
        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.setBackgroundColor(BG)
        scroll.clipToPadding = false
        scroll.isVerticalScrollBarEnabled = false
        scroll.overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16f), dp(12f), dp(16f), dp(40f))
        root.clipChildren = false
        root.clipToPadding = false
        scroll.addView(
            root, FrameLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        // Header gradient dengan sudut bawah membulat.
        val header = LinearLayout(this)
        header.orientation = LinearLayout.VERTICAL
        header.setPadding(dp(20f), dp(18f), dp(20f), dp(20f))
        header.background = organicHeaderBg(
            Color.rgb(22, 43, 115), Color.rgb(51, 79, 170)
        )
        if (Build.VERSION.SDK_INT >= 21) header.elevation = dp(5f).toFloat()
        val headerParams = LinearLayout.LayoutParams(-1, -2)
        headerParams.leftMargin = 0
        headerParams.rightMargin = 0
        root.addView(header, headerParams)

        val back = TextView(this)
        back.text = "‹   Kembali"
        back.textSize = 14f
        back.setTextColor(Color.WHITE)
        back.gravity = Gravity.CENTER
        back.setPadding(dp(15f), dp(8f), dp(18f), dp(8f))
        back.background = roundBg(0x2AFFFFFF, dp(28f))
        back.setOnClickListener { v: View? -> finish() }
        val backParams = LinearLayout.LayoutParams(-2, dp(38f))
        backParams.bottomMargin = dp(12f)
        back.minHeight = dp(48f)
        backParams.height = -2
        header.addView(back, backParams)

        val title = TextView(this)
        title.text = "Edit Profil"
        title.textSize = 25f
        title.typeface = semibold(this)
        title.letterSpacing = -0.015f
        title.setTextColor(Color.WHITE)
        header.addView(title, wrap())

        val subtitle = TextView(this)
        subtitle.text = "Kelola informasi akun dan data diri kamu di sini."
        subtitle.textSize = 14f
        subtitle.setLineSpacing(dp(3f).toFloat(), 1.0f)
        subtitle.setTextColor(Color.rgb(224, 244, 249))
        val subtitleParams = wrap()
        subtitleParams.topMargin = dp(5f)
        header.addView(subtitle, subtitleParams)

        // Kartu profil utama.
        val hero = card(root)
        hero.orientation = LinearLayout.VERTICAL
        hero.setPadding(dp(18f), dp(20f), dp(18f), dp(20f))
        hero.background = roundBg(Color.WHITE, dp(24f))
        if (Build.VERSION.SDK_INT >= 21) hero.elevation = dp(2f).toFloat()
        val heroParams = hero.layoutParams as LinearLayout.LayoutParams
        heroParams.topMargin = dp(16f)
        heroParams.leftMargin = dp(2f)
        heroParams.rightMargin = dp(2f)
        hero.layoutParams = heroParams

        val identity = LinearLayout(this)
        identity.orientation = LinearLayout.HORIZONTAL
        identity.gravity = Gravity.CENTER_VERTICAL
        hero.addView(identity, wrap())

        imgFoto = ImageView(this)
        imgFoto!!.setImageResource(R.drawable.ic_lk_person)
        imgFoto!!.scaleType = ImageView.ScaleType.CENTER_CROP
        val avatarBg = roundBg(Color.rgb(232, 232, 255), dp(60f))
        avatarBg.setStroke(dp(3f), Color.WHITE)
        imgFoto!!.background = avatarBg
        imgFoto!!.clipToOutline = true
        val imageParams = LinearLayout.LayoutParams(dp(68f), dp(68f))
        imageParams.rightMargin = dp(12f)
        identity.addView(imgFoto, imageParams)

        val identityText = LinearLayout(this)
        identityText.orientation = LinearLayout.VERTICAL
        identityText.gravity = Gravity.CENTER_VERTICAL
        identity.addView(identityText, LinearLayout.LayoutParams(0, -2, 1f))

        val namePreview = TextView(this)
        val namaAwal = pref!!.getString("nama", "Pengguna LokerKu")
        namePreview.text = if (namaAwal == null || namaAwal.trim { it <= ' ' }
                .isEmpty()) "Pengguna LokerKu" else namaAwal
        namePreview.textSize = 18f
        namePreview.typeface = semibold(this)
        namePreview.setTextColor(NAVY)
        namePreview.maxLines = 2
        identityText.addView(namePreview, wrap())

        val usernamePreview = TextView(this)
        usernamePreview.text = "@" + pref!!.getString("username", "username")
        usernamePreview.textSize = 13f
        usernamePreview.setTextColor(MUTED)
        usernamePreview.maxLines = 2

        val usernameParams = wrap()
        usernameParams.topMargin = dp(3f)
        identityText.addView(usernamePreview, usernameParams)

        val emailPreview = TextView(this)
        emailPreview.text = pref!!.getString("email", "Email belum diisi")
        emailPreview.textSize = 12f
        emailPreview.setTextColor(MUTED)
        emailPreview.maxLines = 3

        val emailParams = wrap()
        emailParams.topMargin = dp(5f)
        identityText.addView(emailPreview, emailParams)

        btnFoto = pillButton("Unggah / Ganti Foto", Color.rgb(0, 0, 255), Color.WHITE)
        val photoButtonParams = LinearLayout.LayoutParams(-1, -2)
        photoButtonParams.topMargin = dp(16f)
        hero.addView(btnFoto, photoButtonParams)

        btnHapusFoto =
            pillButton("Hapus Foto Profil", Color.rgb(239, 244, 255), Color.rgb(31, 55, 105))
        val removePhotoParams = LinearLayout.LayoutParams(-1, -2)
        removePhotoParams.topMargin = dp(8f)
        hero.addView(btnHapusFoto, removePhotoParams)

        tambahSection(root, "Informasi Pribadi", "Informasi utama akun kamu")
        val basic = card(root)
        etNama = tambahInput(basic, "Nama lengkap", "Masukkan nama lengkap", false, false)
        etUsername = tambahInput(basic, "Username", "Nama pengguna", false, false)
        etEmail = tambahInput(basic, "Alamat email", "nama@email.com", false, false)
        etNoHp = tambahInput(basic, "Nomor HP", "Contoh: 081234567890", false, true)

        tambahSection(
            root,
            "Informasi Karier",
            "Lengkapi agar profilmu lebih menarik bagi perusahaan"
        )
        val career = card(root)
        etHeadline = tambahInput(career, "Headline profesional", "Bidang atau profesi", false, true)
        etLokasi = tambahInput(career, "Lokasi / domisili", "Kota tempat tinggal", false, true)
        etBio = tambahInput(
            career,
            "Tentang saya",
            "Ceritakan minat, keahlian, dan tujuan kariermu",
            true,
            true
        )
        etLinkedin = tambahInput(career, "LinkedIn", "https://linkedin.com/in/namamu", false, true)
        etPortfolio =
            tambahInput(career, "Portofolio / website", "https://website-kamu.com", false, true)

        val note = TextView(this)
        note.text =
            "Info bertanda Opsional boleh dikosongkan. Simpan perubahan untuk memperbarui profil di LokerKu."
        note.setTextColor(MUTED)
        note.textSize = 12f
        note.setPadding(dp(5f), dp(14f), dp(5f), dp(14f))
        note.setLineSpacing(dp(3f).toFloat(), 1.0f)
        root.addView(note, wrap())

        btnSimpan = pillButton("Simpan Perubahan", Color.rgb(0, 0, 255), Color.WHITE)
        btnSimpan!!.textSize = 15f
        val saveParams = LinearLayout.LayoutParams(-1, -2)
        saveParams.topMargin = dp(4f)
        root.addView(btnSimpan, saveParams)

        btnKeluar = pillButton("Keluar dari Akun", Color.rgb(255, 235, 238), Color.rgb(190, 47, 67))
        val logoutParams = LinearLayout.LayoutParams(-1, -2)
        logoutParams.topMargin = dp(12f)
        root.addView(btnKeluar, logoutParams)

        setContentView(scroll)
        apply(scroll, this)
        UiMotion.styleButtons(scroll)
        UiMotion.bindActions(scroll)
        UiMotion.bindPress(back)
        UiMotion.revealChildren(root, 40, 75, 10)
    }

    override fun onPause() {
        UiMotion.finishReveals(window.decorView)
        super.onPause()
    }

    private fun tambahStat(parent: LinearLayout, icon: Int, title: String, sub: String, tint: Int) {
        val tile = LinearLayout(this)
        tile.orientation = LinearLayout.VERTICAL
        tile.gravity = Gravity.CENTER
        tile.setPadding(dp(5f), dp(13f), dp(5f), dp(13f))
        tile.minimumHeight = dp(132f)
        if (Build.VERSION.SDK_INT >= 21) tile.elevation = dp(3f).toFloat()
        tile.background = roundBg(Color.WHITE, dp(22f))
        val p = LinearLayout.LayoutParams(0, -2, 1f)
        p.setMargins(dp(4f), 0, dp(4f), 0)
        parent.addView(tile, p)

        val symbol = ImageView(this)
        symbol.setImageResource(icon)
        symbol.setColorFilter(Color.rgb(0, 0, 204))
        symbol.setPadding(dp(10f), dp(10f), dp(10f), dp(10f))
        symbol.background = roundBg(tint, dp(30f))
        symbol.contentDescription = null
        tile.addView(symbol, LinearLayout.LayoutParams(dp(42f), dp(42f)))

        val label = TextView(this)
        label.text = title
        label.setTextColor(NAVY)
        label.textSize = 13f
        label.typeface = semibold(this)
        label.gravity = Gravity.CENTER
        val labelP = wrap()
        labelP.topMargin = dp(7f)
        tile.addView(label, labelP)

        val desc = TextView(this)
        desc.text = sub
        desc.setTextColor(MUTED)
        desc.textSize = 10f
        desc.gravity = Gravity.CENTER
        desc.maxLines = 2
        desc.gravity = Gravity.CENTER

        val descP = wrap()
        descP.topMargin = dp(2f)
        tile.addView(desc, descP)
    }

    private fun tambahSection(root: LinearLayout, title: String, subtitle: String) {
        val heading = TextView(this)
        heading.text = title
        heading.setTextColor(NAVY)
        heading.textSize = 19f
        heading.typeface = semibold(this)
        val hp = wrap()
        hp.topMargin = dp(25f)
        root.addView(heading, hp)

        val sub = TextView(this)
        sub.text = subtitle
        sub.setTextColor(MUTED)
        sub.textSize = 13f
        val sp = wrap()
        sp.topMargin = dp(4f)
        sp.bottomMargin = dp(12f)
        root.addView(sub, sp)
    }

    private fun card(parent: LinearLayout?): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(17f), dp(12f), dp(17f), dp(22f))
        if (Build.VERSION.SDK_INT >= 21) box.elevation = dp(3f).toFloat()
        box.background = roundBg(Color.WHITE, dp(24f))
        if (parent != null) {
            val p = LinearLayout.LayoutParams(-1, -2)
            parent.addView(box, p)
        }
        return box
    }

    private fun tambahInput(
        root: LinearLayout, label: String, hint: String,
        multiline: Boolean, optional: Boolean
    ): EditText {
        val labelRow = LinearLayout(this)
        labelRow.orientation = LinearLayout.HORIZONTAL
        labelRow.gravity = Gravity.CENTER_VERTICAL
        val rowParams = LinearLayout.LayoutParams(-1, -2)
        rowParams.topMargin = dp(15f)
        root.addView(labelRow, rowParams)

        val tv = TextView(this)
        tv.text = label
        tv.setTextColor(NAVY)
        tv.textSize = 13f
        tv.typeface = semibold(this)
        labelRow.addView(tv, LinearLayout.LayoutParams(0, -2, 1f))

        if (optional) {
            val badge = TextView(this)
            badge.text = "(opsional)"
            badge.setTextColor(Color.rgb(87, 119, 151))
            badge.textSize = 10f
            badge.setPadding(dp(5f), dp(3f), dp(5f), dp(3f))
            badge.background = roundBg(Color.rgb(235, 242, 248), dp(20f))
            val badgeParams = LinearLayout.LayoutParams(-2, -2)
            badgeParams.leftMargin = dp(8f)
            labelRow.addView(badge, badgeParams)
        }

        val edit = EditText(this)
        edit.hint = hint
        edit.setHintTextColor(Color.rgb(148, 164, 181))
        edit.setTextColor(NAVY)
        edit.textSize = 14f
        edit.setPadding(dp(16f), dp(12f), dp(16f), dp(12f))
        val inputBg = roundBg(Color.rgb(247, 248, 255), dp(18f))
        inputBg.setStroke(dp(1f), Color.rgb(221, 224, 255))
        edit.background = inputBg
        edit.setSelectAllOnFocus(false)
        edit.isSingleLine = !multiline
        if (label.lowercase().contains("email")) {
            edit.inputType = (InputType.TYPE_CLASS_TEXT
                    or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
        } else if (label.lowercase().contains("hp")) {
            edit.inputType = InputType.TYPE_CLASS_PHONE
        } else if (label.lowercase().contains("linkedin")
            || label.lowercase().contains("portofolio")
        ) {
            edit.inputType = (InputType.TYPE_CLASS_TEXT
                    or InputType.TYPE_TEXT_VARIATION_URI)
        }
        if (multiline) {
            edit.minLines = 3
            edit.maxLines = 6
            edit.gravity = Gravity.TOP or Gravity.START
            edit.inputType = (InputType.TYPE_CLASS_TEXT
                    or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                    or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
        }
        edit.typeface = regular(this)
        edit.minHeight = if (multiline) dp(132f) else dp(56f)
        val editParams = LinearLayout.LayoutParams(-1, -2)
        editParams.topMargin = dp(9f)
        root.addView(edit, editParams)
        return edit
    }

    private fun pillButton(text: String, backgroundColor: Int, textColor: Int): Button {
        val button = Button(this)
        button.text = text
        button.isAllCaps = false
        button.textSize = 14f
        button.typeface = semibold(this)
        button.setTextColor(textColor)
        button.gravity = Gravity.CENTER
        button.setPadding(dp(20f), 0, dp(20f), 0)
        button.letterSpacing = 0.01f
        button.includeFontPadding = false
        button.minHeight = dp(48f)
        val buttonBg = roundBg(backgroundColor, dp(16f))
        buttonBg.setStroke(
            dp(1f), if (backgroundColor == Color.rgb(255, 235, 238))
                Color.rgb(255, 207, 214)
            else
                backgroundColor
        )
        if (Build.VERSION.SDK_INT >= 21) {
            val ripple = RippleDrawable(
                ColorStateList.valueOf(0x22FFFFFF), buttonBg, null
            )
            button.background = ripple
            button.elevation = dp(2f).toFloat()
        } else {
            button.background = buttonBg
        }
        button.stateListAnimator = null
        return button
    }

    private fun organicHeaderBg(start: Int, end: Int): GradientDrawable {
        val d = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(start, -0xdac06f, end)
        )
        // Bagian atas lembut, sudut bawah lebih lebar agar header tidak tampak kotak.
        d.cornerRadii = floatArrayOf(
            dp(30f).toFloat(), dp(30f).toFloat(), dp(30f).toFloat(), dp(30f).toFloat(),
            dp(26f).toFloat(), dp(26f).toFloat(), dp(26f).toFloat(), dp(26f).toFloat()
        )
        return d
    }


    private fun isiProfil() {
        etNama!!.setText(pref!!.getString("nama", ""))
        etUsername!!.setText(pref!!.getString("username", ""))
        etEmail!!.setText(pref!!.getString("email", ""))
        etNoHp!!.setText(pref!!.getString("phone", pref!!.getString("no_hp", "")))
        etHeadline!!.setText(pref!!.getString("profile_headline", ""))
        etLokasi!!.setText(pref!!.getString("profile_lokasi", ""))
        etBio!!.setText(pref!!.getString("profile_bio", ""))
        etLinkedin!!.setText(pref!!.getString("profile_linkedin", ""))
        etPortfolio!!.setText(pref!!.getString("profile_portfolio", ""))

        val foto = pref!!.getString("foto", "")
        if (foto != null && (foto.startsWith("https://") || foto.startsWith("http://"))) {
            val imageRequest =
                ImageRequest(foto,
                    { bitmap: Bitmap? -> imgFoto!!.setImageBitmap(bitmap) }, dp(300f), dp(300f),
                    ImageView.ScaleType.CENTER_CROP, Bitmap.Config.RGB_565,
                    { error: VolleyError? -> })
            queue!!.add(imageRequest)
        }
    }

    private fun simpanProfil() {
        val id = pref!!.getInt("id", 0).toString()
        val nama = etNama!!.text.toString().trim { it <= ' ' }
        val username = etUsername!!.text.toString().trim { it <= ' ' }
        val email = etEmail!!.text.toString().trim { it <= ' ' }
        val noHp = etNoHp!!.text.toString().trim { it <= ' ' }
        val headline = etHeadline!!.text.toString().trim { it <= ' ' }
        val lokasi = etLokasi!!.text.toString().trim { it <= ' ' }
        val bio = etBio!!.text.toString().trim { it <= ' ' }
        val linkedin = etLinkedin!!.text.toString().trim { it <= ' ' }
        val portfolio = etPortfolio!!.text.toString().trim { it <= ' ' }

        if (nama.isEmpty() || email.isEmpty()) {
            Toast.makeText(this, "Nama dan email wajib diisi", Toast.LENGTH_SHORT).show()
            return
        }
        if (id == "0") {
            Toast.makeText(
                this,
                "ID akun tidak ditemukan. Silakan login kembali.",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        btnSimpan!!.isEnabled = false
        val request: StringRequest = object : StringRequest(
            Method.POST, BASE + "auth/update_profile.php",
            Response.Listener<String> { response: String? ->
                try {
                    val json = JSONObject(response)
                    if (json.optBoolean("success")) {
                        pref!!.edit()
                            .putString("nama", nama)
                            .putString("username", username)
                            .putString("email", email)
                            .putString("phone", noHp)
                            .putString("profile_headline", headline)
                            .putString("profile_lokasi", lokasi)
                            .putString("profile_bio", bio)
                            .putString("profile_linkedin", linkedin)
                            .putString("profile_portfolio", portfolio)
                            .apply()
                        if (fotoTerpilih != null) uploadFoto(id)
                        else {
                            btnSimpan!!.isEnabled = true
                            Toast.makeText(this, "Profil berhasil diperbarui", Toast.LENGTH_SHORT)
                                .show()
                            finish()
                        }
                    } else {
                        btnSimpan!!.isEnabled = true
                        Toast.makeText(
                            this,
                            json.optString("message", "Profil gagal diperbarui"),
                            Toast.LENGTH_LONG
                        ).show()
                    }
                } catch (e: Exception) {
                    btnSimpan!!.isEnabled = true
                    Toast.makeText(
                        this,
                        "Respons profil dari server tidak valid",
                        Toast.LENGTH_LONG
                    ).show()
                }
            },
            Response.ErrorListener { error: VolleyError ->
                btnSimpan!!.isEnabled = true
                Toast.makeText(this, errorMessage(error, "menyimpan profil"), Toast.LENGTH_LONG)
                    .show()
            }) {
            override fun getParams(): Map<String, String>? {
                val p: MutableMap<String, String> = HashMap()
                p["id"] = id
                p["session_token"] = SessionStore.get(this@ProfileActivity)
                p["nama"] = nama
                p["username"] = username
                p["email"] = email
                p["no_hp"] = noHp
                p["profile_headline"] = headline
                p["profile_lokasi"] = lokasi
                p["profile_bio"] = bio
                p["profile_linkedin"] = linkedin
                p["profile_portfolio"] = portfolio
                return p
            }
        }
        request.setRetryPolicy(DefaultRetryPolicy(20000, 0, 1f))
        request.setShouldCache(false)
        queue!!.add(request)
    }

    private fun errorMessage(error: VolleyError, task: String): String {
        if (error.networkResponse != null) {
            val status = error.networkResponse.statusCode
            try {
                val body = JSONObject(String(error.networkResponse.data, StandardCharsets.UTF_8))
                val message = body.optString("message", "").trim { it <= ' ' }
                if (!message.isEmpty() && status < 500) return "$message (HTTP $status)"
            } catch (ignored: Exception) {
            }
            return "Server gagal saat $task (HTTP $status)."
        }
        return "Tidak dapat terhubung saat $task. Periksa internet dan coba lagi."
    }

    @Throws(Exception::class)
    private fun decodeBounded(uri: Uri, maxSide: Int): Bitmap? {
        val bounds = BitmapFactory.Options()
        bounds.inJustDecodeBounds = true
        contentResolver.openInputStream(uri).use { `in` ->
            if (`in` == null) throw Exception("Foto tidak tersedia")
            BitmapFactory.decodeStream(`in`, null, bounds)
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw Exception("Foto tidak valid")
        val options = BitmapFactory.Options()
        options.inSampleSize = 1
        while (max(
                bounds.outWidth.toDouble(),
                bounds.outHeight.toDouble()
            ) / options.inSampleSize > maxSide * 2
        ) options.inSampleSize *= 2
        contentResolver.openInputStream(uri).use { `in` ->
            if (`in` == null) throw Exception("Foto tidak tersedia")
            return BitmapFactory.decodeStream(`in`, null, options)
        }
    }

    private fun uploadFoto(id: String) {
        try {
            val bitmap = decodeBounded(fotoTerpilih!!, 1024) ?: throw Exception("Foto tidak valid")

            val max = 1024
            val width = bitmap.width
            val height = bitmap.height
            val scale =
                min(
                    1.0,
                    min((max / width.toFloat()).toDouble(), (max / height.toFloat()).toDouble())
                )
                    .toFloat()
            val resized = Bitmap.createScaledBitmap(
                bitmap,
                max(1.0, Math.round(width * scale).toDouble()).toInt(),
                max(1.0, Math.round(height * scale).toDouble()).toInt(), true
            )
            val output = ByteArrayOutputStream()
            resized.compress(Bitmap.CompressFormat.JPEG, 82, output)
            val bytes = output.toByteArray()

            val request: VolleyMultipartRequest = object : VolleyMultipartRequest(
                Method.POST,
                BASE + "auth/upload_photo.php",
                Response.Listener<NetworkResponse> { response: NetworkResponse ->
                    btnSimpan!!.isEnabled = true
                    try {
                        val json = JSONObject(String(response.data, charset("UTF-8")))
                        if (json.optBoolean("success")) {
                            val url = json.optString("foto", "")
                            pref!!.edit().putString("foto", url).apply()
                            Toast.makeText(
                                this,
                                "Profil dan foto berhasil disimpan",
                                Toast.LENGTH_SHORT
                            ).show()
                            finish()
                        } else {
                            Toast.makeText(
                                this,
                                "Profil tersimpan; " + json.optString(
                                    "message",
                                    "foto gagal diunggah"
                                ),
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    } catch (e: Exception) {
                        Toast.makeText(
                            this,
                            "Profil tersimpan, tetapi respons unggah foto tidak valid.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                },
                Response.ErrorListener { error: VolleyError ->
                    btnSimpan!!.isEnabled = true
                    Toast.makeText(
                        this,
                        "Profil tersimpan. " + errorMessage(error, "mengunggah foto"),
                        Toast.LENGTH_LONG
                    ).show()
                }) {
                override fun getParams(): Map<String, String>? {
                    val params: MutableMap<String, String> = HashMap()
                    params["id"] = id
                    params["session_token"] = SessionStore.get(this@ProfileActivity)
                    return params
                }

                override val byteData: Map<String, DataPart>
                    get() {
                        val files: MutableMap<String, DataPart> = HashMap()
                        files["foto"] = DataPart("profil.jpg", bytes, "image/jpeg")
                        return files
                    }
            }
            request.setRetryPolicy(DefaultRetryPolicy(30000, 0, 1f))
            request.setShouldCache(false)
            queue!!.add(request)
        } catch (e: Exception) {
            btnSimpan!!.isEnabled = true
            Toast.makeText(this, "Profil tersimpan, tetapi foto gagal diproses.", Toast.LENGTH_LONG)
                .show()
        }
    }

    private fun roundBg(color: Int, radius: Int): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        if (color == Color.WHITE) d.setStroke(dp(1f), Color.rgb(221, 224, 255))
        d.cornerRadius = radius.toFloat()
        return d
    }

    private fun wrap(): LinearLayout.LayoutParams {
        return LinearLayout.LayoutParams(-1, -2)
    }

    private fun dp(value: Float): Int {
        return (value * resources.displayMetrics.density + 0.5f).toInt()
    }

    abstract class VolleyMultipartRequest(
        method: Int, url: String?,
        private val listener: Response.Listener<NetworkResponse>,
        private val errorListener: Response.ErrorListener
    ) : Request<NetworkResponse>(method, url, errorListener) {
        private val boundary = "LokerKuBoundary" + System.currentTimeMillis()

        protected abstract val byteData: Map<String, DataPart>

        class DataPart(var fileName: String, var content: ByteArray, var type: String)

        override fun getBodyContentType(): String {
            return "multipart/form-data; boundary=$boundary"
        }

        @Throws(AuthFailureError::class)
        override fun getBody(): ByteArray {
            val out = ByteArrayOutputStream()
            try {
                val line = "\r\n"
                val twoHyphens = "--"
                for ((key, value) in params!!) {
                    out.write(
                        ((twoHyphens + boundary + line
                                + "Content-Disposition: form-data; name=\"" + key + "\"" + line + line
                                + value + line)).toByteArray(charset("UTF-8"))
                    )
                }
                for ((key, data) in byteData) {
                    out.write(
                        ((twoHyphens + boundary + line
                                + "Content-Disposition: form-data; name=\"" + key
                                + "\"; filename=\"" + data.fileName + "\"" + line
                                + "Content-Type: " + data.type + line + line)).toByteArray(charset("UTF-8"))
                    )
                    out.write(data.content)
                    out.write(line.toByteArray(charset("UTF-8")))
                }
                out.write((twoHyphens + boundary + twoHyphens + line).toByteArray(charset("UTF-8")))
            } catch (e: Exception) {
                val message = if (e.message == null) "Gagal menyiapkan upload foto" else e.message
                throw AuthFailureError(message)
            }
            return out.toByteArray()
        }

        override fun parseNetworkResponse(response: NetworkResponse): Response<NetworkResponse> {
            return Response.success(response, HttpHeaderParser.parseCacheHeaders(response))
        }

        override fun deliverResponse(response: NetworkResponse) {
            listener.onResponse(response)
        }
    }

    companion object {
        private const val BASE = "https://ahannaja.cu.ma/lokerku_api/"
        private val NAVY = Color.rgb(21, 26, 61)
        private val BLUE = Color.rgb(0, 0, 255)
        private val MUTED = Color.rgb(104, 112, 143)
        private val BG = Color.rgb(247, 248, 255)
    }
}
