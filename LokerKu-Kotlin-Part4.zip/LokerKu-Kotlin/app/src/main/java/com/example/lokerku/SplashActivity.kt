package com.example.lokerku

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {
    private var splashView: LokerKuSplashView? = null
    private var sudahPindah = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val window = window

        window.statusBarColor = Color.rgb(10, 35, 78)
        window.navigationBarColor = Color.rgb(10, 35, 78)

        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN

        splashView = LokerKuSplashView(this)

        splashView!!.setAnimationListener(LokerKuSplashView.AnimationListener {
            if (isFinishing || sudahPindah) {
                return@AnimationListener
            }
            sudahPindah = true

            val intent = Intent(
                this@SplashActivity,
                AuthChoiceActivity::class.java
            )

            startActivity(intent)

            overridePendingTransition(
                R.anim.screen_enter,
                R.anim.screen_exit
            )
            finish()
        })

        setContentView(splashView)
    }

    override fun onPause() {
        if (splashView != null) splashView!!.pauseAnimations()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (splashView != null) splashView!!.resumeAnimations()
    }

    override fun onDestroy() {
        if (splashView != null) {
            splashView!!.stopAnimations()
        }

        super.onDestroy()
    }
}
