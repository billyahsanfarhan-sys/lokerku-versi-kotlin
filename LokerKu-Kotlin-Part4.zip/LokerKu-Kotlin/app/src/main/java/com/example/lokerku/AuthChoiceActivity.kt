package com.example.lokerku

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/** Entry choice; existing login and registration flows remain unchanged.  */
class AuthChoiceActivity : AppCompatActivity() {
    private fun dp(n: Float): Int {
        return (resources.displayMetrics.density * n + .5f).toInt()
    }

    private fun label(value: String, size: Int, color: Int, bold: Boolean): TextView {
        val t = TextView(this)
        t.text = value
        t.textSize = size.toFloat()
        t.setTextColor(color)
        t.typeface =
            if (bold) AppFont.semibold(this) else AppFont.regular(this)
        t.gravity = Gravity.CENTER
        return t
    }

    private fun action(title: String, primary: Boolean): Button {
        val b = Button(this)
        b.text = title
        b.isAllCaps = false
        b.textSize = 15f
        b.setTextColor(Color.WHITE)
        b.typeface = AppFont.semibold(this)
        b.minHeight = dp(52f)
        b.setPadding(dp(16f), dp(10f), dp(16f), dp(10f))
        b.isSingleLine = false
        b.letterSpacing = 0f
        val bg = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            if (primary) intArrayOf(-0xd4b20e, -0xcca40b) else intArrayOf(0x4dffffff, 0x25202070)
        )
        bg.cornerRadius = dp(16f).toFloat()
        bg.setStroke(dp(1f), if (primary) -0x725501 else -0x66362201)
        b.backgroundTintList = null
        b.background = bg
        b.stateListAnimator = null
        return b
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        window.statusBarColor = -0xf6e4a8
        window.navigationBarColor = -0xe8d188
        window.decorView.systemUiVisibility = 0
        val frame = FrameLayout(this)
        frame.addView(AuthAmbientView(this), FrameLayout.LayoutParams(-1, -1))
        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.setBackgroundColor(Color.TRANSPARENT)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setPadding(dp(22f), dp(36f), dp(22f), dp(36f))
        scroll.addView(root)
        frame.addView(scroll)
        val brand = label("✦  LOKERKU", 13, -0x201401, true)
        brand.letterSpacing = .10f
        val brandp = LinearLayout.LayoutParams(-1, -2)
        brandp.bottomMargin = dp(20f)
        root.addView(brand, brandp)
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(22f), dp(28f), dp(22f), dp(24f))
        card.background = AuthGlass.card(this)
        root.addView(card, LinearLayout.LayoutParams(-1, -2))
        val title = label("Peluang baru,\nlangkah baru.", 26, Color.WHITE, true)
        title.setLineSpacing(dp(2f).toFloat(), 1f)
        card.addView(title)
        val description = label(
            "Temukan pekerjaan dan kelola perjalanan kariermu bersama LokerKu.",
            13,
            -0x1e1401,
            false
        )
        description.setLineSpacing(dp(3f).toFloat(), 1f)
        val d = LinearLayout.LayoutParams(-1, -2)
        d.topMargin = dp(12f)
        d.bottomMargin = dp(26f)
        card.addView(description, d)
        val login = action("Masuk", true)
        card.addView(login, LinearLayout.LayoutParams(-1, -2))
        val register = action("Daftar", false)
        val r = LinearLayout.LayoutParams(-1, -2)
        r.topMargin = dp(12f)
        card.addView(register, r)
        val hint = label("Pilih cara untuk melanjutkan", 11, -0x231701, false)
        val h = LinearLayout.LayoutParams(-1, -2)
        h.topMargin = dp(18f)
        card.addView(hint, h)
        login.setOnClickListener { v: View? ->
            startActivity(
                Intent(
                    this,
                    LoginActivity::class.java
                )
            )
        }
        register.setOnClickListener { v: View? ->
            startActivity(
                Intent(
                    this,
                    RegisterActivity::class.java
                )
            )
        }
        setContentView(frame)
        FontEnforcer.apply(frame, this)
        UiMotion.bindPress(login)
        UiMotion.bindPress(register)
        UiMotion.reveal(card, 100)
    }

    override fun onPause() {
        UiMotion.finishReveals(window.decorView)
        super.onPause()
    }
}
