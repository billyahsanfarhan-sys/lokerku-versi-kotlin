# LokerKu — Android Studio

Proyek ini mencakup antarmuka LokerKu, alur daftar dan masuk Google, profil, sertifikat, pencatatan lamaran, dan pusat akun. Warna biru dan font Poppins proyek dipertahankan. Dialog akun, catatan dan konfirmasi memakai permukaan terang, sudut membulat, tombol berwarna dan animasi; tata letak tombol favorit detail lowongan dirapikan. Login dan daftar memakai tampilan kaca berlapis dan latar animasi. Navigasi memakai satu warna aktif dengan lapisan kaca gelap transparan; login dan daftar memakai gaya kaca yang serupa. Pembuka menyatukan huruf LokerKu dari berbagai posisi secara bertahap sekitar 7 detik saat animasi sistem aktif. Garis pembuka mengikuti durasi animasi (bukan pengukuran proses jaringan). Halaman awal menawarkan pilihan Masuk atau Daftar. Edit profil disusun ulang; tombol dialog ditata vertikal dengan jarak dan label yang lebih ringkas. Sertifikat JPG/PNG dan halaman pertama PDF ditampilkan pada galeri profil jika dapat dimuat; ketuk untuk melihat atau membuka dokumen. Tampilan sistem seperti keyboard dan pemilih akun Google mengikuti pengaturan perangkat.

## Penting sebelum menjalankan
Fitur baru membutuhkan pemasangan API, dependensi PHP, dan migrasi database dari paket hosting yang sesuai. Backup database dan file server sebelum memasang. Jangan mengganti koneksi.php atau email_config.php lama. API versi baru menggunakan sesi; aplikasi lama dapat berhenti dapat mengubah profil setelah API diganti, jadi perbarui aplikasi dan API bersama.

Buka folder proyek ini di Android Studio, lakukan Gradle Sync, dan jalankan dengan SDK 34. Untuk uji Google gunakan komputer dan debug keystore yang SHA-1-nya didaftarkan di Google Cloud; build debug dari komputer lain memiliki SHA-1 berbeda. Untuk rilis, daftarkan juga sidik jari penandatanganan yang digunakan APK atau Google Play. Pastikan akun penguji tercantum ketika OAuth dalam mode pengujian.

## Perilaku
- Akun Google harus terlebih dahulu didaftarkan dari tombol daftar; alamat email yang sudah ada tidak otomatis digabungkan demi keamanan. Pengguna dapat melengkapi username, nomor HP dan kata sandi sesudahnya.
- Sertifikat yang diunggah ke profil dapat dilihat oleh semua orang yang memiliki tautannya. Jangan unggah data rahasia.
- Tombol lamaran hanya mencatat lamaran di LokerKu. Itu tidak mengirim lamaran, CV, atau notifikasi ke perusahaan.
- Penonaktifan menyembunyikan profil dan dapat dibatalkan dengan masuk lagi. Penghapusan akun bersifat permanen dan memerlukan konfirmasi serta autentikasi ulang.

## Status pengujian
Build debug untuk revisi ini berhasil. Sebelumnya pengujian API lokal dengan data simulasi berhasil. Login Google riil, tampilan dan animasi pada HP, pengiriman email, pemasangan pada hosting, dan perilaku API sebenarnya masih harus diuji langsung; keberhasilan build tidak menjamin fitur sudah berjalan di hosting.
