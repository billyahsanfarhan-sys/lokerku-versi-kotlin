package com.example.lokerku

import android.content.Context

internal object FavoritesStore {
    @JvmStatic
    fun name(c: Context): String {
        return "lokerku_favorites_" + c.getSharedPreferences("lokerku_user", Context.MODE_PRIVATE)
            .getInt("id", 0)
    }

    @JvmStatic
    fun migrate(c: Context, previousUser: Int, newUser: Int) {
        if (previousUser <= 0 || previousUser != newUser) return
        val old = c.getSharedPreferences("lokerku_favorites", Context.MODE_PRIVATE)
        val scoped = c.getSharedPreferences("lokerku_favorites_$newUser", Context.MODE_PRIVATE)
        val oldNotes = c.getSharedPreferences("lokerku_notes", Context.MODE_PRIVATE)
        val newNotes = c.getSharedPreferences("lokerku_notes_$newUser", Context.MODE_PRIVATE)
        if (!newNotes.contains("notes") && oldNotes.contains("notes")) {
            newNotes.edit().putString("notes", oldNotes.getString("notes", "")).apply()
            oldNotes.edit().clear().apply()
        }
        if (!scoped.contains("job_ids") && old.contains("job_ids")) {
            val values = old.getStringSet("job_ids", HashSet())!!
            scoped.edit().putStringSet("job_ids", HashSet(values)).apply()
            old.edit().clear().apply()
        }
    }
}
