package com.example.lokerku

import android.animation.ObjectAnimator
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.util.Patterns
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.DefaultRetryPolicy
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.lokerku.AppFont.regular
import com.example.lokerku.AppFont.semibold
import com.example.lokerku.AuthGlass.card
import com.example.lokerku.AuthGlass.field
import com.example.lokerku.FontEnforcer.apply
import com.example.lokerku.GoogleDesign.addTo
import com.example.lokerku.LoginActivity
import org.json.JSONObject

class RegisterActivity : AppCompatActivity() {
    private var etName: EditText? = null
    private var etUsername: EditText? = null
    private var etEmail: EditText? = null
    private var etPassword: EditText? = null
    private var etConfirmPassword: EditText? = null
    private var etPhone: EditText? = null

    private var btnRegister: Button? = null
    private var progressBar: ProgressBar? = null
    private var tvLogin: TextView? = null

    private var requestRunning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = -0xebd27d
        window.navigationBarColor = -0xd1b84b
        if (Build.VERSION.SDK_INT >= 23) {
            window.decorView.systemUiVisibility = 0
        }

        buatTampilan()
    }

    private fun buatTampilan() {
        val scrollView = ScrollView(this)
        scrollView.isFillViewport = true
        scrollView.setBackgroundColor(Color.TRANSPARENT)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(22f), dp(18f), dp(22f), dp(24f))
        root.setBackgroundColor(Color.TRANSPARENT)

        scrollView.addView(root)

        val tvBack = TextView(this)
        tvBack.text = "‹  Kembali"
        tvBack.textSize = 15f
        tvBack.setTextColor(WHITE)
        tvBack.typeface = semibold(this)
        tvBack.gravity = Gravity.CENTER_VERTICAL
        tvBack.setPadding(0, dp(6f), 0, dp(12f))

        root.addView(
            tvBack,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(42f)
            )
        )

        tvBack.setOnClickListener { v: View? -> finish() }

        val tvTitle = TextView(this)
        tvTitle.text = "Buat Akun Baru"
        tvTitle.textSize = 26f
        tvTitle.setTextColor(WHITE)
        tvTitle.typeface = semibold(this)

        val titleParams =
            LinearLayout.LayoutParams(-1, -2)
        titleParams.topMargin = dp(24f)

        root.addView(tvTitle, titleParams)

        val tvSubtitle = TextView(this)
        tvSubtitle.text = "Lengkapi data berikut untuk mulai mencari pekerjaan."
        tvSubtitle.textSize = 13f
        tvSubtitle.setTextColor(-0x1d1401)

        val subtitleParams =
            LinearLayout.LayoutParams(-1, -2)
        subtitleParams.topMargin = dp(7f)

        root.addView(tvSubtitle, subtitleParams)

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(22f), dp(24f), dp(22f), dp(24f))
        val cardBackground = card(this)
        card.background = cardBackground
        card.elevation = dp(3f).toFloat()

        val cardParams =
            LinearLayout.LayoutParams(-1, -2)
        cardParams.topMargin = dp(20f)

        root.addView(card, cardParams)

        addTo(card, this, "Daftar dengan Google")
        val separator = TextView(this)
        separator.text = "ATAU ISI DATA MANUAL"
        separator.textSize = 10f
        separator.setTextColor(-0x281a01)
        separator.letterSpacing = .08f
        separator.gravity = Gravity.CENTER
        separator.setPadding(0, dp(18f), 0, dp(14f))
        card.addView(separator)

        etName = tambahField(
            card,
            "Nama lengkap",
            "Masukkan nama lengkap",
            InputType.TYPE_CLASS_TEXT
                    or InputType.TYPE_TEXT_FLAG_CAP_WORDS,
            false
        )

        etUsername = tambahField(
            card,
            "Username",
            "Buat username",
            InputType.TYPE_CLASS_TEXT
                    or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS,
            false
        )

        etEmail = tambahField(
            card,
            "Email",
            "nama@email.com",
            InputType.TYPE_CLASS_TEXT
                    or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS,
            false
        )

        etPhone = tambahField(
            card,
            "Nomor HP",
            "Contoh: 08xxxxxxxxxx",
            InputType.TYPE_CLASS_PHONE,
            false
        )

        etPassword = tambahField(
            card,
            "Password",
            "Minimal 6 karakter",
            InputType.TYPE_CLASS_TEXT
                    or InputType.TYPE_TEXT_VARIATION_PASSWORD,
            false
        )

        etConfirmPassword = tambahField(
            card,
            "Konfirmasi password",
            "Ulangi password",
            InputType.TYPE_CLASS_TEXT
                    or InputType.TYPE_TEXT_VARIATION_PASSWORD,
            true
        )

        btnRegister = Button(this)
        btnRegister!!.text = "Daftar Sekarang"
        btnRegister!!.textSize = 15f
        btnRegister!!.setTextColor(WHITE)
        btnRegister!!.isAllCaps = false
        btnRegister!!.typeface = semibold(this)
        btnRegister!!.backgroundTintList = null
        btnRegister!!.background =
            gradientBackground(BLUE, TEAL, dp(18f))
        btnRegister!!.stateListAnimator = null

        val registerParams =
            LinearLayout.LayoutParams(-1, -2)
        btnRegister!!.minHeight = dp(52f)
        registerParams.topMargin = dp(22f)

        card.addView(btnRegister, registerParams)
        progressBar = ProgressBar(this)
        progressBar!!.isIndeterminate = true
        progressBar!!.indeterminateTintList = ColorStateList.valueOf(TEAL)
        progressBar!!.visibility = View.GONE

        val progressParams =
            LinearLayout.LayoutParams(dp(30f), dp(30f))
        progressParams.gravity = Gravity.CENTER_HORIZONTAL
        progressParams.topMargin = dp(12f)

        card.addView(progressBar, progressParams)

        val loginRow = LinearLayout(this)
        loginRow.orientation = LinearLayout.HORIZONTAL
        loginRow.gravity = Gravity.CENTER
        loginRow.setPadding(0, dp(20f), 0, 0)

        val tvHaveAccount = TextView(this)
        tvHaveAccount.text = "Sudah punya akun? "
        tvHaveAccount.setTextColor(-0x1d1401)
        tvHaveAccount.textSize = 13f

        loginRow.addView(tvHaveAccount)

        tvLogin = TextView(this)
        tvLogin!!.text = "Masuk"
        tvLogin!!.setTextColor(WHITE)
        tvLogin!!.textSize = 13f
        tvLogin!!.setPadding(dp(8f), dp(12f), dp(8f), dp(12f))
        tvLogin!!.typeface = semibold(this)

        loginRow.addView(tvLogin)

        root.addView(loginRow)

        val tvFooter = TextView(this)
        tvFooter.text = "MULAI LANGKAH BARUMU"
        tvFooter.setTextColor(-0x281a01)
        tvFooter.textSize = 10f
        tvFooter.gravity = Gravity.CENTER
        tvFooter.letterSpacing = 0.04f

        val footerParams =
            LinearLayout.LayoutParams(-1, -2)
        footerParams.topMargin = dp(22f)

        root.addView(tvFooter, footerParams)

        btnRegister!!.setOnClickListener { v: View? -> registerUser() }

        etConfirmPassword!!.setOnEditorActionListener { v: TextView?, actionId: Int, event: KeyEvent? ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                registerUser()
                return@setOnEditorActionListener true
            }
            false
        }

        tvLogin!!.setOnClickListener { v: View? -> bukaLogin() }

        val scene = FrameLayout(this)
        scene.addView(AuthAmbientView(this), FrameLayout.LayoutParams(-1, -1))
        scene.addView(scrollView, FrameLayout.LayoutParams(-1, -1))
        setContentView(scene)
        apply(scrollView, this)
        UiMotion.styleButtons(scrollView)
        UiMotion.bindActions(scrollView)
        UiMotion.bindPress(tvBack)
        UiMotion.bindPress(tvLogin!!)
        UiMotion.revealChildren(root, 60, 85, 7)
        UiMotion.revealChildren(card, 240, 45, 14)
    }

    override fun onPause() {
        UiMotion.finishReveals(window.decorView)
        super.onPause()
    }

    private fun tambahField(
        parent: LinearLayout,
        label: String,
        hint: String,
        inputType: Int,
        lastField: Boolean
    ): EditText {
        val tvLabel = TextView(this)
        tvLabel.text = label
        tvLabel.textSize = 13f
        tvLabel.setTextColor(WHITE)
        tvLabel.typeface = semibold(this)

        val labelParams =
            LinearLayout.LayoutParams(-1, -2)
        labelParams.topMargin = if (parent.childCount == 0)
            0
        else
            dp(15f)

        parent.addView(tvLabel, labelParams)

        val editText = EditText(this)
        editText.isSingleLine = true
        editText.textSize = 14f
        editText.setTextColor(WHITE)
        editText.setHintTextColor(-0x37280b)
        editText.hint = hint
        editText.inputType = inputType
        editText.typeface = regular(this)
        editText.setPadding(dp(13f), dp(10f), dp(13f), dp(10f))
        editText.minHeight = dp(52f)
        val inputBackground = field(this, false)
        editText.backgroundTintList = null
        editText.background = inputBackground
        editText.onFocusChangeListener =
            View.OnFocusChangeListener { field: View, focused: Boolean ->
                inputBackground.setStroke(
                    dp((if (focused) 2 else 1).toFloat()),
                    if (focused) -0x2b1101 else -0x66392301
                )
                val lift = ObjectAnimator.ofFloat(
                    field, View.TRANSLATION_Z, if (focused) dp(3f).toFloat() else 0f
                )
                lift.setDuration(220)
                lift.start()
            }
        editText.imeOptions = if (lastField)
            EditorInfo.IME_ACTION_DONE
        else
            EditorInfo.IME_ACTION_NEXT

        val inputParams =
            LinearLayout.LayoutParams(-1, -2)
        inputParams.topMargin = dp(7f)

        parent.addView(editText, inputParams)

        return editText
    }

    private fun registerUser() {
        if (requestRunning) {
            return
        }

        val nama =
            etName!!.text.toString().trim { it <= ' ' }
        val username =
            etUsername!!.text.toString().trim { it <= ' ' }
        val email =
            etEmail!!.text.toString().trim { it <= ' ' }
        val phone =
            etPhone!!.text.toString().trim { it <= ' ' }
        val password =
            etPassword!!.text.toString()
        val confirmPassword =
            etConfirmPassword!!.text.toString()

        if (nama.isEmpty()) {
            etName!!.error = "Nama lengkap wajib diisi"
            etName!!.requestFocus()
            return
        }

        if (username.length < 4) {
            etUsername!!.error = "Username minimal 4 karakter"
            etUsername!!.requestFocus()
            return
        }

        if (email.isEmpty()
            || !Patterns.EMAIL_ADDRESS.matcher(email).matches()
        ) {
            etEmail!!.error = "Masukkan alamat email yang valid"
            etEmail!!.requestFocus()
            return
        }

        if (phone.isEmpty()) {
            etPhone!!.error = "Nomor HP wajib diisi"
            etPhone!!.requestFocus()
            return
        }

        if (!phone.matches("[0-9+() -]{8,20}".toRegex())) {
            etPhone!!.error = "Periksa format nomor HP"
            etPhone!!.requestFocus()
            return
        }

        if (password.length < 6) {
            etPassword!!.error = "Password minimal 6 karakter"
            etPassword!!.requestFocus()
            return
        }

        if (password != confirmPassword) {
            etConfirmPassword!!.error = "Password tidak sama"
            etConfirmPassword!!.requestFocus()
            return
        }

        aturLoading(true)

        val request: StringRequest = object : StringRequest(
            Method.POST,
            URL_REGISTER,
            Response.Listener<String> { response: String? ->
                aturLoading(false)
                try {
                    val json = JSONObject(response)

                    val success = json.optBoolean(
                        "success",
                        false
                    )

                    val message = json.optString(
                        "message",
                        "Respons server tidak diketahui."
                    )

                    Toast.makeText(
                        this@RegisterActivity,
                        message,
                        Toast.LENGTH_LONG
                    ).show()

                    if (success) {
                        val intent = Intent(
                            this@RegisterActivity,
                            LoginActivity::class.java
                        )

                        intent.addFlags(
                            Intent.FLAG_ACTIVITY_CLEAR_TOP
                                    or Intent.FLAG_ACTIVITY_SINGLE_TOP
                        )

                        startActivity(intent)
                        finish()
                    }
                } catch (e: Exception) {
                    Toast.makeText(
                        this@RegisterActivity,
                        "Respons server tidak valid. Periksa JSON API.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            },
            Response.ErrorListener { error: VolleyError ->
                aturLoading(false)
                var message =
                    "Registrasi gagal terhubung ke server."

                if (error.networkResponse != null) {
                    message += (" HTTP "
                            + error.networkResponse.statusCode)
                } else if (error.message != null) {
                    message += " " + error.message
                }
                Toast.makeText(
                    this@RegisterActivity,
                    message,
                    Toast.LENGTH_LONG
                ).show()
            }
        ) {
            override fun getParams(): Map<String, String>? {
                val params: MutableMap<String, String> = HashMap()

                params["nama"] = nama
                params["username"] = username
                params["email"] = email
                params["password"] = password
                params["no_hp"] = phone

                return params
            }
        }

        request.setRetryPolicy(
            DefaultRetryPolicy(
                15000,
                1,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
            )
        )

        Volley.newRequestQueue(applicationContext).add(request)
    }

    private fun aturLoading(loading: Boolean) {
        requestRunning = loading

        progressBar!!.visibility =
            if (loading) View.VISIBLE else View.GONE

        btnRegister!!.isEnabled = !loading
        btnRegister!!.alpha = if (loading) 0.65f else 1.0f
        btnRegister!!.text = if (loading) "Mendaftarkan akun..." else "Daftar Sekarang"

        etName!!.isEnabled = !loading
        etUsername!!.isEnabled = !loading
        etEmail!!.isEnabled = !loading
        etPhone!!.isEnabled = !loading
        etPassword!!.isEnabled = !loading
        etConfirmPassword!!.isEnabled = !loading
        tvLogin!!.isEnabled = !loading
    }

    private fun bukaLogin() {
        val intent = Intent(
            this@RegisterActivity,
            LoginActivity::class.java
        )

        intent.addFlags(
            Intent.FLAG_ACTIVITY_CLEAR_TOP
                    or Intent.FLAG_ACTIVITY_SINGLE_TOP
        )

        startActivity(intent)
        finish()
    }

    private fun roundBackground(
        color: Int,
        radius: Int
    ): GradientDrawable {
        val drawable = GradientDrawable()
        drawable.setColor(color)
        drawable.cornerRadius = radius.toFloat()

        return drawable
    }

    private fun gradientBackground(
        startColor: Int,
        endColor: Int,
        radius: Int
    ): GradientDrawable {
        val drawable = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(startColor, endColor)
        )

        drawable.cornerRadius = radius.toFloat()

        return drawable
    }

    private fun dp(value: Float): Int {
        return (value * resources
            .displayMetrics.density + 0.5f
                ).toInt()
    }

    companion object {
        private const val URL_REGISTER = "https://ahannaja.cu.ma/lokerku_api/auth/register.php"

        private val NAVY = Color.rgb(21, 26, 61)
        private val BLUE = Color.rgb(0, 0, 204)
        private val TEAL = Color.rgb(0, 0, 255)
        private val BG = Color.rgb(247, 248, 255)
        private val TEXT = Color.rgb(21, 26, 61)
        private val MUTED = Color.rgb(104, 112, 143)
        private const val WHITE = Color.WHITE
    }
}
