package com.example.lokerku

import android.app.Activity
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.android.volley.VolleyError
import com.android.volley.toolbox.ImageRequest
import com.android.volley.toolbox.Volley
import com.example.lokerku.ApiClient.post
import com.example.lokerku.AppFont.regular
import com.example.lokerku.AppFont.semibold
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

/** Public certificate thumbnails shown on the user's own profile.  */
internal class CertificateGallery private constructor(
    private val activity: Activity,
    private val panel: LinearLayout
) {
    private val queue = Volley.newRequestQueue(activity.applicationContext)
    private fun dp(n: Float): Int {
        return (n * activity.resources.displayMetrics.density + .5f).toInt()
    }

    private fun text(s: String, size: Int, color: Int, bold: Boolean): TextView {
        val t = TextView(activity)
        t.text = s
        t.setTextColor(color)
        t.textSize = size.toFloat()
        t.typeface = if (bold) semibold(activity) else regular(activity)
        return t
    }

    private fun bg(color: Int, radius: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radius.toFloat()).toFloat()
        return g
    }

    private fun load() {
        panel.removeAllViews()
        val status = text("Memuat galeri…", 12, -0x978f71, false)
        status.setPadding(dp(14f), dp(16f), dp(14f), dp(16f))
        panel.addView(status)
        val params = HashMap<String, String>()
        params["action"] = "list"
        post(activity, "profile/certificates.php", params, object : ApiClient.Result {
            override fun success(json: JSONObject) {
                if (!panel.isAttachedToWindow) return
                panel.removeAllViews()
                val items = json.optJSONArray("certificates")
                if (items == null || items.length() == 0) {
                    empty()
                    return
                }
                var row: LinearLayout? = null
                var count = 0
                for (i in 0 until items.length()) {
                    val item = items.optJSONObject(i)
                    if (item == null || item.optLong("id", 0) <= 0) continue
                    if (count % 3 == 0) {
                        row = LinearLayout(activity)
                        row.orientation = LinearLayout.HORIZONTAL
                        panel.addView(row)
                    }
                    val p = LinearLayout.LayoutParams(0, -2, 1f)
                    p.setMargins(dp(2f), dp(2f), dp(2f), dp(2f))
                    row!!.addView(tile(item), p)
                    count++
                }
                if (count == 0) {
                    empty()
                    return
                }
                val rem = count % 3
                if (rem > 0) for (i in rem..2) {
                    val filler = View(activity)
                    val p = LinearLayout.LayoutParams(0, 1, 1f)
                    p.setMargins(dp(2f), 0, dp(2f), 0)
                    row!!.addView(filler, p)
                }
                UiMotion.revealChildren(panel, 30, 55, 3)
            }

            override fun fail(message: String) {
                if (!panel.isAttachedToWindow) return
                panel.removeAllViews()
                val err = text(
                    "Galeri belum dapat dimuat. Ketuk untuk mencoba lagi.",
                    12,
                    -0x948d75,
                    false
                )
                err.setPadding(dp(12f), dp(16f), dp(12f), dp(16f))
                err.setOnClickListener { v: View? -> load() }
                panel.addView(err)
            }
        })
    }

    private fun empty() {
        val empty = text(
            "Belum ada sertifikat. Ketuk + Tambah untuk menampilkan pencapaianmu di sini.",
            12,
            -0x978f71,
            false
        )
        empty.setLineSpacing(dp(3f).toFloat(), 1f)
        empty.setPadding(dp(16f), dp(24f), dp(16f), dp(24f))
        empty.gravity = Gravity.CENTER
        empty.background = bg(-0xe0b01, 16)
        panel.addView(empty)
    }

    private fun tile(item: JSONObject): View {
        val id = item.optLong("id")
        val label = item.optString("label", "Sertifikat")
        val pdf = "application/pdf" == item.optString("file_type")
        val tile = Square(activity)
        tile.background = bg(-0x161201, 12)
        tile.clipToOutline = true
        val image = ImageView(activity)
        image.scaleType =
            if (pdf) ImageView.ScaleType.FIT_CENTER else ImageView.ScaleType.CENTER_CROP
        tile.addView(image, FrameLayout.LayoutParams(-1, -1))
        val fallback = text(if (pdf) "PDF" else "✦", if (pdf) 14 else 24, -0xbcac38, true)
        fallback.gravity = Gravity.CENTER
        tile.addView(fallback, FrameLayout.LayoutParams(-1, -1))
        val name = text((if (pdf) "PDF  ·  " else "") + label, 10, Color.WHITE, true)
        name.maxLines = 1
        name.ellipsize = TextUtils.TruncateAt.END
        name.setPadding(dp(7f), dp(13f), dp(7f), dp(6f))
        val shade = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0x00131b48, -0x26e5debb)
        )
        name.background = shade
        val np = FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM)
        tile.addView(name, np)
        tile.contentDescription = "Lihat sertifikat: $label"
        tile.setOnClickListener { v: View? -> preview(item, image.drawable) }
        UiMotion.bindPress(tile)
        val url = ApiClient.BASE + "profile/certificate_file.php?id=" + id
        if (pdf) loadPdf(url, image, fallback) else {
            val request = ImageRequest(url,
                { bitmap: Bitmap? ->
                    image.setImageBitmap(bitmap)
                    fallback.visibility = View.GONE
                }, 450, 450, ImageView.ScaleType.CENTER_CROP, Bitmap.Config.RGB_565,
                { error: VolleyError? -> fallback.text = "Gambar" })
            request.setShouldCache(false)
            queue.add(request)
        }
        return tile
    }

    private fun preview(item: JSONObject, drawable: Drawable?) {
        val label = item.optString("label", "Sertifikat")
        val id = item.optLong("id")
        val body = LinearLayout(activity)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(dp(18f), dp(8f), dp(18f), dp(4f))
        val image = ImageView(activity)
        image.background = bg(-0xd0b01, 16)
        image.scaleType = ImageView.ScaleType.FIT_CENTER
        if (drawable != null) image.setImageDrawable(drawable) else image.setImageResource(R.drawable.ic_lk_info_outline)
        body.addView(image, LinearLayout.LayoutParams(-1, dp(250f)))
        val detail = text("Sertifikat ini bersifat publik.", 12, -0x978f71, false)
        detail.setPadding(0, dp(10f), 0, 0)
        body.addView(detail)
        PremiumDialog.Builder(activity).setTitle(label).setView(body)
            .setNegativeButton("Tutup", null).setPositiveButton(
                "Buka dokumen"
            ) { d: DialogInterface?, w: Int ->
                try {
                    activity.startActivity(
                        Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse(ApiClient.BASE + "profile/certificate_file.php?id=" + id)
                        )
                    )
                } catch (e: Exception) {
                    Toast.makeText(
                        activity,
                        "Tidak ada aplikasi untuk membuka dokumen.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }.show()
    }

    private fun loadPdf(url: String, image: ImageView, fallback: TextView) {
        PDF_WORKER.execute {
            var bitmap: Bitmap? = null
            var tmp: File? = null
            var conn: HttpURLConnection? = null
            try {
                conn = URL(url).openConnection() as HttpURLConnection
                conn!!.connectTimeout = 12000
                conn.readTimeout = 12000
                conn.instanceFollowRedirects = false
                if (conn.responseCode != 200) throw Exception("http")
                tmp = File.createTempFile("cert_preview_", ".pdf", activity.cacheDir)
                conn.inputStream.use { `in` ->
                    FileOutputStream(tmp).use { out ->
                        val b = ByteArray(8192)
                        var n: Int
                        var total = 0
                        while ((`in`.read(b).also { n = it }) != -1) {
                            total += n
                            if (total > 5 * 1024 * 1024) throw Exception("large")
                            out.write(b, 0, n)
                        }
                    }
                }
                ParcelFileDescriptor.open(
                    tmp,
                    ParcelFileDescriptor.MODE_READ_ONLY
                ).use { fd ->
                    PdfRenderer(fd).use { renderer ->
                        if (renderer.pageCount < 1) throw Exception("empty")
                        renderer.openPage(0).use { page ->
                            val w = 360
                            val h = max(
                                1.0,
                                min(
                                    600.0,
                                    (w.toLong() * page.height / max(
                                        1.0,
                                        page.width.toDouble()
                                    )).toInt().toDouble()
                                )
                            ).toInt()
                            bitmap = Bitmap.createBitmap(
                                w,
                                h,
                                Bitmap.Config.ARGB_8888
                            )
                            Canvas(bitmap!!)
                                .drawColor(Color.WHITE)
                            page.render(
                                bitmap!!,
                                null,
                                null,
                                PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY
                            )
                        }
                    }
                }
            } catch (ignored: Exception) {
            } finally {
                conn?.disconnect()
                tmp?.delete()
            }
            val result = bitmap
            activity.runOnUiThread {
                if (result != null && !activity.isFinishing && image.isAttachedToWindow) {
                    image.setImageBitmap(result)
                    fallback.visibility = View.GONE
                }
            }
        }
    }

    private class Square(a: Activity) : FrameLayout(a) {
        override fun onMeasure(w: Int, h: Int) {
            super.onMeasure(
                w,
                MeasureSpec.makeMeasureSpec(MeasureSpec.getSize(w), MeasureSpec.EXACTLY)
            )
        }
    }

    companion object {
        private val PDF_WORKER: ExecutorService = Executors.newFixedThreadPool(2)
        @JvmStatic
        fun show(a: Activity, panel: LinearLayout) {
            CertificateGallery(a, panel).load()
        }
    }
}
