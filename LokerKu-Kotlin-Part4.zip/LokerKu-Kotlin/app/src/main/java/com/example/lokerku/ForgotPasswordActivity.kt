package com.example.lokerku

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.text.TextUtils
import android.util.Patterns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.DefaultRetryPolicy
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.lokerku.AppFont.semibold
import com.example.lokerku.FontEnforcer.apply
import org.json.JSONObject

class ForgotPasswordActivity : AppCompatActivity() {
    private val NAVY = Color.rgb(21, 26, 61)
    private val TEAL = Color.rgb(0, 0, 255)
    private val BG = Color.rgb(247, 248, 255)
    private val TEXT = Color.rgb(21, 26, 61)
    private val MUTED = Color.rgb(104, 112, 143)
    private val WHITE = Color.WHITE

    private var etEmail: EditText? = null
    private var btnReset: Button? = null
    private var progressBar: ProgressBar? = null
    private var requestQueue: RequestQueue? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = BG
        window.navigationBarColor = BG

        if (Build.VERSION.SDK_INT >= 23) {
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                    or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        }

        requestQueue = Volley.newRequestQueue(
            applicationContext
        )

        tampilkanHalaman()
    }

    private fun tampilkanHalaman() {
        val scrollView = ScrollView(this)
        scrollView.isFillViewport = true
        scrollView.setBackgroundColor(BG)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(26f), dp(20f), dp(26f), dp(30f))
        root.gravity = Gravity.CENTER_VERTICAL

        scrollView.addView(root)
        setContentView(scrollView)
        apply(scrollView, this)

        val back = TextView(this)
        back.text = "‹  Kembali ke Login"
        back.textSize = 15f
        back.setTextColor(TEAL)
        back.typeface = semibold(this)
        back.setPadding(0, dp(8f), 0, dp(24f))
        back.setOnClickListener { v: View? -> finish() }
        root.addView(back)

        val logo = LinearLayout(this)
        logo.gravity = Gravity.CENTER
        logo.orientation = LinearLayout.HORIZONTAL
        logo.setPadding(dp(20f), dp(18f), dp(20f), dp(18f))
        val brandBg = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.rgb(0, 0, 204), Color.rgb(51, 51, 255))
        )
        brandBg.cornerRadius = dp(24f).toFloat()
        logo.background = brandBg

        val logoIcon = TextView(this)
        logoIcon.text = "L"
        logoIcon.setTextColor(WHITE)
        logoIcon.textSize = 28f
        logoIcon.typeface = semibold(this)
        logoIcon.gravity = Gravity.CENTER
        logo.addView(
            logoIcon,
            LinearLayout.LayoutParams(dp(38f), dp(38f))
        )

        val logoName = TextView(this)
        logoName.text = "LokerKu"
        logoName.setTextColor(WHITE)
        logoName.textSize = 22f
        logoName.typeface = semibold(this)

        val logoNameParams =
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )

        logoNameParams.leftMargin = dp(10f)
        logo.addView(logoName, logoNameParams)

        val logoParams =
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )

        logoParams.width = ViewGroup.LayoutParams.MATCH_PARENT
        logoParams.bottomMargin = dp(18f)
        root.addView(logo, logoParams)

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(22f), dp(24f), dp(22f), dp(24f))
        val cardBg = bulat(WHITE, 26)
        cardBg.setStroke(dp(1f), Color.rgb(221, 224, 255))
        card.background = cardBg
        card.elevation = dp(3f).toFloat()
        root.addView(card, LinearLayout.LayoutParams(-1, -2))

        val title = TextView(this)
        title.text = "Lupa Password?"
        title.setTextColor(NAVY)
        title.textSize = 30f
        title.typeface = semibold(this)
        card.addView(title)

        val subtitle = TextView(this)
        subtitle.text = "Masukkan email yang terdaftar pada akun LokerKu. " +
                "Kami akan mengirimkan tautan untuk membuat password baru."
        subtitle.setTextColor(MUTED)
        subtitle.textSize = 15f
        subtitle.setLineSpacing(dp(4f).toFloat(), 1f)

        val subtitleParams =
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )

        subtitleParams.topMargin = dp(10f)
        subtitleParams.bottomMargin = dp(28f)
        card.addView(subtitle, subtitleParams)

        val emailLabel = TextView(this)
        emailLabel.text = "Email terdaftar"
        emailLabel.setTextColor(TEXT)
        emailLabel.textSize = 14f
        emailLabel.typeface = semibold(this)
        card.addView(emailLabel)

        etEmail = EditText(this)
        etEmail!!.isSingleLine = true
        etEmail!!.hint = "nama@email.com"
        etEmail!!.setTextColor(TEXT)
        etEmail!!.setHintTextColor(MUTED)
        etEmail!!.textSize = 15f
        etEmail!!.inputType = (InputType.TYPE_CLASS_TEXT
                or InputType
            .TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
        etEmail!!.setPadding(dp(16f), 0, dp(16f), 0)
        etEmail!!.background = inputBackground()

        val emailParams =
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(56f)
            )

        emailParams.topMargin = dp(10f)
        emailParams.bottomMargin = dp(22f)
        card.addView(etEmail, emailParams)

        btnReset = Button(this)
        btnReset!!.text = "Kirim Tautan Reset"
        btnReset!!.setTextColor(WHITE)
        btnReset!!.textSize = 15f
        btnReset!!.typeface = semibold(this)
        btnReset!!.isAllCaps = false
        btnReset!!.background = bulat(TEAL, 14)
        btnReset!!.elevation = dp(3f).toFloat()

        card.addView(
            btnReset,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(54f)
            )
        )

        progressBar = ProgressBar(this)
        progressBar!!.isIndeterminate = true
        progressBar!!.visibility = View.GONE

        val progressParams =
            LinearLayout.LayoutParams(dp(30f), dp(30f))

        progressParams.gravity = Gravity.CENTER
        progressParams.topMargin = dp(16f)
        card.addView(progressBar, progressParams)

        val info = TextView(this)
        info.text = "Periksa kotak masuk dan folder spam setelah " +
                "meminta tautan pemulihan."
        info.setTextColor(MUTED)
        info.textSize = 12f
        info.gravity = Gravity.CENTER
        info.setLineSpacing(dp(3f).toFloat(), 1f)

        val infoParams =
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )

        infoParams.topMargin = dp(18f)
        card.addView(info, infoParams)

        btnReset!!.setOnClickListener { v: View? -> prosesPemulihan() }
        apply(scrollView, this)
        UiMotion.styleButtons(scrollView)
        UiMotion.bindActions(scrollView)
        UiMotion.bindPress(back)
        UiMotion.revealChildren(root, 60, 110, 4)
        UiMotion.revealChildren(card, 200, 55, 8)
    }

    override fun onPause() {
        UiMotion.finishReveals(window.decorView)
        super.onPause()
    }

    private fun prosesPemulihan() {
        val email = etEmail!!.text.toString().trim { it <= ' ' }

        if (TextUtils.isEmpty(email)) {
            etEmail!!.error = "Email wajib diisi"
            etEmail!!.requestFocus()
            return
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail!!.error = "Format email tidak valid"
            etEmail!!.requestFocus()
            return
        }

        sembunyikanKeyboard()
        setLoading(true)

        val request: StringRequest = object : StringRequest(
            Method.POST,
            URL_FORGOT_PASSWORD,

            Response.Listener { responseText: String? ->
                setLoading(false)
                try {
                    val response =
                        JSONObject(responseText)

                    val success =
                        response.optBoolean("success", false)

                    val message = response.optString(
                        "message",
                        "Respons server tidak lengkap."
                    )

                    Toast.makeText(
                        this@ForgotPasswordActivity,
                        message,
                        Toast.LENGTH_LONG
                    ).show()

                    if (success) {
                        etEmail!!.setText("")
                    }
                } catch (e: Exception) {
                    Toast.makeText(
                        this@ForgotPasswordActivity,
                        "Respons server tidak valid.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            },

            Response.ErrorListener { error: VolleyError ->
                setLoading(false)
                var message =
                    "Tidak dapat terhubung ke server."

                if (error.networkResponse != null) {
                    val statusCode =
                        error.networkResponse.statusCode

                    message += " (HTTP $statusCode)"

                    if (statusCode == 404) {
                        message +=
                            "\nPeriksa lokasi file PHP di hosting."
                    } else if (statusCode == 405) {
                        message +=
                            "\nServer menolak metode permintaan."
                    } else if (statusCode >= 500) {
                        message +=
                            "\nPeriksa konfigurasi PHP di server."
                    }
                }
                Toast.makeText(
                    this@ForgotPasswordActivity,
                    message,
                    Toast.LENGTH_LONG
                ).show()
            }
        ) {
            override fun getParams(): Map<String, String>? {
                val params: MutableMap<String, String> = HashMap()
                params["email"] = email
                return params
            }
        }

        request.setShouldCache(false)
        request.setRetryPolicy(
            DefaultRetryPolicy(
                20000,
                0,
                1.0f
            )
        )

        requestQueue!!.add(request)
    }

    private fun setLoading(loading: Boolean) {
        btnReset!!.isEnabled = !loading
        btnReset!!.text = if (loading) "Mengirim Permintaan..." else "Kirim Tautan Reset"

        btnReset!!.alpha = if (loading) 0.7f else 1f

        etEmail!!.isEnabled = !loading

        progressBar!!.visibility =
            if (loading) View.VISIBLE else View.GONE
    }

    private fun sembunyikanKeyboard() {
        try {
            val imm =
                getSystemService(
                    INPUT_METHOD_SERVICE
                ) as InputMethodManager

            val currentFocus = currentFocus

            if (imm != null && currentFocus != null) {
                imm.hideSoftInputFromWindow(
                    currentFocus.windowToken,
                    0
                )
            }
        } catch (ignored: Exception) {
        }
    }

    private fun bulat(warna: Int, radius: Int): GradientDrawable {
        val drawable = GradientDrawable()
        drawable.setColor(warna)
        drawable.cornerRadius = dp(radius.toFloat()).toFloat()
        return drawable
    }

    private fun inputBackground(): GradientDrawable {
        val drawable = GradientDrawable()
        drawable.setColor(WHITE)
        drawable.cornerRadius = dp(14f).toFloat()
        drawable.setStroke(
            dp(1f),
            Color.rgb(220, 228, 237)
        )
        return drawable
    }

    private fun dp(value: Float): Int {
        return (value * resources.displayMetrics.density
                + 0.5f
                ).toInt()
    }

    companion object {
        private const val URL_FORGOT_PASSWORD =
            "https://ahannaja.cu.ma/lokerku_api/auth/forgot_password.php"
    }
}
