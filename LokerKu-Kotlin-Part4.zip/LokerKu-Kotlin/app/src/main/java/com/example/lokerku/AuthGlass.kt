package com.example.lokerku

import android.content.Context
import android.graphics.drawable.GradientDrawable
import kotlin.math.max

/** Translucent layered surface. Not a real-time background blur.  */
internal object AuthGlass {
    @JvmStatic
    fun card(c: Context): GradientDrawable {
        val d = c.resources.displayMetrics.density
        val glass = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(-0x63dec98b, -0x53e7d59f, -0x4beddfb0)
        )
        glass.cornerRadius = 28 * d
        glass.setStroke(max(1, Math.round(d)), -0x66190c01)
        return glass
    }

    @JvmStatic
    fun field(c: Context, focused: Boolean): GradientDrawable {
        val d = c.resources.displayMetrics.density
        val glass = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0x54243260, 0x78202d56)
        )
        glass.cornerRadius = 14 * d
        glass.setStroke(
            max(1, Math.round((if (focused) 2 else 1) * d)),
            if (focused) -0x2b1101 else -0x66392301
        )
        return glass
    }
}
