package com.example.lokerku

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.Build
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.sin

/** Moving layers behind the glass cards; no account data is used here.  */
class AuthAmbientView(context: Context?) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var background: Shader? = null
    private var animator: ValueAnimator? = null
    private var phase = 0f

    init {
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    private fun dp(n: Float): Float {
        return n * resources.displayMetrics.density
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (w > 0 && h > 0) background = LinearGradient(
            0f,
            0f,
            w.toFloat(),
            h.toFloat(),
            intArrayOf(-0xf6e4a8, -0xe6c45b, -0xcfb650),
            null,
            Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0 || h <= 0) return
        paint.style = Paint.Style.FILL
        paint.setShader(background)
        canvas.drawPaint(paint)
        paint.setShader(null)
        val drift = sin(phase * Math.PI * 2).toFloat()
        val wave = cos(phase * Math.PI * 2).toFloat()
        glow(canvas, w * .85f + dp(26f) * drift, h * .13f + dp(14f) * wave, w * .66f, -0x4f992601)
        glow(canvas, w * .12f - dp(20f) * wave, h * .77f + dp(18f) * drift, w * .66f, -0x57776001)
        glow(canvas, w * .80f + dp(15f) * wave, h * .84f - dp(18f) * drift, w * .48f, -0x76ac4401)
        paint.setShader(null)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = dp(1f)
        paint.color = 0x55dceaff
        canvas.drawCircle(w * .85f + dp(26f) * drift, h * .13f + dp(14f) * wave, w * .36f, paint)
        canvas.drawCircle(w * .12f - dp(20f) * wave, h * .77f + dp(18f) * drift, w * .27f, paint)
        paint.style = Paint.Style.FILL
        for (i in 0..7) {
            val x = w * (.09f + .115f * i) + dp(4f) * cos((phase * 6.28f + i).toDouble()).toFloat()
            val y =
                h * (.13f + .105f * (i % 7)) + dp(9f) * sin((phase * 6.28f + i * .7f).toDouble()).toFloat()
            paint.color = if (i % 3 == 0) -0x441a0c01 else 0x70d6e7ff
            canvas.drawCircle(x, y, dp(if (i % 3 == 0) 1.8f else 1.1f), paint)
        }
    }

    private fun glow(c: Canvas, x: Float, y: Float, r: Float, color: Int) {
        if (r <= 0) return
        paint.setShader(
            RadialGradient(
                x,
                y,
                r,
                intArrayOf(color, 0x00000000),
                null,
                Shader.TileMode.CLAMP
            )
        )
        c.drawCircle(x, y, r, paint)
        paint.setShader(null)
    }

    private fun startMotion() {
        if (animator != null || (Build.VERSION.SDK_INT >= 26 && !ValueAnimator.areAnimatorsEnabled())) return
        animator = ValueAnimator.ofFloat(0f, 1f)
        animator!!.setDuration(14000)
        animator!!.setInterpolator(LinearInterpolator())
        animator!!.setRepeatCount(ValueAnimator.INFINITE)
        animator!!.addUpdateListener(ValueAnimator.AnimatorUpdateListener { a: ValueAnimator ->
            phase = a.animatedValue as Float
            invalidate()
        })
        animator!!.start()
    }

    private fun stopMotion() {
        if (animator != null) {
            animator!!.cancel()
            animator = null
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (windowVisibility == VISIBLE) startMotion()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE && isAttachedToWindow) startMotion() else stopMotion()
    }

    override fun onDetachedFromWindow() {
        stopMotion()
        super.onDetachedFromWindow()
    }
}
