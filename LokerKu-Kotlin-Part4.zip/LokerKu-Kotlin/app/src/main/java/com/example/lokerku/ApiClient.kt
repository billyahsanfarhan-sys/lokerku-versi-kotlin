package com.example.lokerku

import android.content.Context
import com.android.volley.DefaultRetryPolicy
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject
import java.nio.charset.StandardCharsets

internal object ApiClient {
    const val BASE: String = "https://ahannaja.cu.ma/lokerku_api/"
    fun post(c: Context, path: String, values: Map<String, String>, cb: Result) {
        val session = SessionStore.get(c)
        if (session.isEmpty()) {
            cb.fail("Sesi tidak tersedia. Masuk kembali.")
            return
        }
        val p: MutableMap<String, String> = HashMap(values)
        p["session_token"] = session
        val request: StringRequest = object : StringRequest(
            Method.POST, BASE + path,
            Response.Listener<String> { response: String? ->
                try {
                    val json = JSONObject(response)
                    if (json.optBoolean("success")) cb.success(json) else cb.fail(
                        json.optString(
                            "message",
                            "Permintaan gagal."
                        )
                    )
                } catch (e: Exception) {
                    cb.fail("Respons server tidak valid.")
                }
            },
            Response.ErrorListener { error: VolleyError ->
                var message = "Tidak dapat menghubungi server."
                if (error.networkResponse != null && error.networkResponse.data != null) try {
                    message = JSONObject(
                        String(
                            error.networkResponse.data,
                            StandardCharsets.UTF_8
                        )
                    ).optString("message", message)
                } catch (ignored: Exception) {
                }
                cb.fail(message)
            }) {
            override fun getParams(): Map<String, String>? {
                return p
            }
        }
        request.setRetryPolicy(DefaultRetryPolicy(20000, 0, 1f))
        Volley.newRequestQueue(c.applicationContext).add(request)
    }

    internal interface Result {
        fun success(json: JSONObject)
        fun fail(msg: String)
    }
}
